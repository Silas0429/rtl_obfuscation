"""
AST types: symbols, expressions, statements, types
"""
from __future__ import annotations
import collections.abc
import enum
import pyslang
import pyslang.syntax
import typing
__all__: list[str] = ['ASTContext', 'ASTFlags', 'AbortAssertionExpr', 'AnonymousProgramSymbol', 'ArbitrarySymbolExpression', 'ArgumentDirection', 'AssertionExpr', 'AssertionExprKind', 'AssertionInstanceExpression', 'AssertionKind', 'AssertionPortSymbol', 'AssignmentExpression', 'AssignmentPatternExpressionBase', 'AssociativeArrayType', 'AttributeSymbol', 'BinSelectWithFilterExpr', 'BinaryAssertionExpr', 'BinaryAssertionOperator', 'BinaryBinsSelectExpr', 'BinaryExpression', 'BinaryOperator', 'BinsSelectExpr', 'BinsSelectExprKind', 'BlockEventListControl', 'BlockStatement', 'BreakStatement', 'CHandleType', 'CallExpression', 'CaseAssertionExpr', 'CaseStatement', 'CaseStatementCondition', 'CheckerInstanceBodySymbol', 'CheckerInstanceSymbol', 'CheckerSymbol', 'ClassPropertySymbol', 'ClassType', 'ClockVarSymbol', 'ClockingAssertionExpr', 'ClockingBlockSymbol', 'ClockingEventExpression', 'ClockingSkew', 'Compilation', 'CompilationFlags', 'CompilationOptions', 'CompilationUnitSymbol', 'ConcatenationExpression', 'ConcurrentAssertionStatement', 'ConditionBinsSelectExpr', 'ConditionalAssertionExpr', 'ConditionalConstraint', 'ConditionalExpression', 'ConditionalStatement', 'ConfigBlockSymbol', 'ConstantPattern', 'Constraint', 'ConstraintBlockFlags', 'ConstraintBlockSymbol', 'ConstraintKind', 'ConstraintList', 'ContinueStatement', 'ContinuousAssignSymbol', 'ConversionExpression', 'ConversionKind', 'CopyClassExpression', 'CoverCrossBodySymbol', 'CoverCrossSymbol', 'CoverageBinSymbol', 'CoverageOptionSetter', 'CovergroupBodySymbol', 'CovergroupType', 'CoverpointSymbol', 'CrossIdBinsSelectExpr', 'CycleDelayControl', 'DPIOpenArrayType', 'DataTypeExpression', 'DeclaredType', 'DefParamSymbol', 'DefinitionKind', 'DefinitionSymbol', 'Delay3Control', 'DelayControl', 'DimensionKind', 'DisableForkStatement', 'DisableIffAssertionExpr', 'DisableSoftConstraint', 'DisableStatement', 'DistExpression', 'DoWhileLoopStatement', 'DynamicArrayType', 'EdgeKind', 'ElabSystemTaskKind', 'ElabSystemTaskSymbol', 'ElementSelectExpression', 'EmptyArgumentExpression', 'EmptyMemberSymbol', 'EmptyStatement', 'EnumType', 'EnumValueSymbol', 'ErrorType', 'EvalContext', 'EvalFlags', 'EvalResult', 'EvaluatedDimension', 'EventListControl', 'EventTriggerStatement', 'EventType', 'ExplicitImportSymbol', 'Expression', 'ExpressionConstraint', 'ExpressionKind', 'ExpressionStatement', 'FieldSymbol', 'FirstMatchAssertionExpr', 'FixedSizeUnpackedArrayType', 'FloatingType', 'ForLoopStatement', 'ForeachConstraint', 'ForeachLoopStatement', 'ForeverLoopStatement', 'FormalArgumentSymbol', 'ForwardTypeRestriction', 'ForwardingTypedefSymbol', 'GenerateBlockArraySymbol', 'GenerateBlockSymbol', 'GenerateBranchKind', 'GenericClassDefSymbol', 'GenvarSymbol', 'HierarchicalValueExpression', 'ImmediateAssertionStatement', 'ImplicationConstraint', 'ImplicitEventControl', 'InsideExpression', 'InstanceArraySymbol', 'InstanceBodySymbol', 'InstanceSymbol', 'InstanceSymbolBase', 'IntegerLiteral', 'IntegralFlags', 'IntegralType', 'InterfacePortSymbol', 'InvalidAssertionExpr', 'InvalidBinsSelectExpr', 'InvalidConstraint', 'InvalidExpression', 'InvalidPattern', 'InvalidStatement', 'InvalidTimingControl', 'IteratorSymbol', 'LValue', 'LValueReferenceExpression', 'LetDeclSymbol', 'LocalAssertionVarSymbol', 'Lookup', 'LookupFlags', 'LookupLocation', 'LookupResult', 'LookupResultFlags', 'MemberAccessExpression', 'MethodFlags', 'MethodPrototypeSymbol', 'MinTypMax', 'MinTypMaxExpression', 'ModportClockingSymbol', 'ModportPortSymbol', 'ModportSymbol', 'MultiPortSymbol', 'NamedValueExpression', 'NetAliasSymbol', 'NetSymbol', 'NetType', 'NewArrayExpression', 'NewClassExpression', 'NewCovergroupExpression', 'NonConstantFunction', 'NullLiteral', 'NullType', 'OneStepDelayControl', 'PackageSymbol', 'PackedArrayType', 'PackedStructType', 'PackedUnionType', 'ParameterSymbol', 'ParameterSymbolBase', 'Pattern', 'PatternCaseStatement', 'PatternKind', 'PatternVarSymbol', 'PortConnection', 'PortSymbol', 'PredefinedIntegerType', 'PrimitiveInstanceSymbol', 'PrimitivePortDirection', 'PrimitivePortSymbol', 'PrimitiveSymbol', 'ProceduralAssignStatement', 'ProceduralBlockKind', 'ProceduralBlockSymbol', 'ProceduralCheckerStatement', 'ProceduralDeassignStatement', 'PropertySymbol', 'PropertyType', 'PulseStyleKind', 'PulseStyleSymbol', 'QueueType', 'RandCaseStatement', 'RandMode', 'RandSeqProductionSymbol', 'RandSequenceStatement', 'RangeSelectExpression', 'RangeSelectionKind', 'RealLiteral', 'RepeatLoopStatement', 'RepeatedEventControl', 'ReplicatedAssignmentPatternExpression', 'ReplicationExpression', 'ReturnStatement', 'RootSymbol', 'ScalarType', 'Scope', 'ScriptSession', 'SequenceConcatExpr', 'SequenceRange', 'SequenceRepetition', 'SequenceSymbol', 'SequenceType', 'SequenceWithMatchExpr', 'SetExprBinsSelectExpr', 'SignalEventControl', 'SimpleAssertionExpr', 'SimpleAssignmentPatternExpression', 'SimpleSystemSubroutine', 'SolveBeforeConstraint', 'SpecifyBlockSymbol', 'SpecparamSymbol', 'Statement', 'StatementBlockKind', 'StatementBlockSymbol', 'StatementKind', 'StatementList', 'StreamingConcatenationExpression', 'StringLiteral', 'StringType', 'StrongWeakAssertionExpr', 'StructurePattern', 'StructuredAssignmentPatternExpression', 'SubroutineKind', 'SubroutineSymbol', 'Symbol', 'SymbolKind', 'SystemSubroutine', 'SystemTimingCheckKind', 'SystemTimingCheckSymbol', 'TaggedPattern', 'TaggedUnionExpression', 'TempVarSymbol', 'TimeLiteral', 'TimedStatement', 'TimingControl', 'TimingControlKind', 'TimingPathSymbol', 'TransparentMemberSymbol', 'Type', 'TypeAliasType', 'TypeParameterSymbol', 'TypePrinter', 'TypePrintingOptions', 'TypeRefType', 'TypeReferenceExpression', 'UnaryAssertionExpr', 'UnaryAssertionOperator', 'UnaryBinsSelectExpr', 'UnaryExpression', 'UnaryOperator', 'UnbasedUnsizedIntegerLiteral', 'UnboundedLiteral', 'UnboundedType', 'UnconnectedDrive', 'UninstantiatedDefSymbol', 'UniquePriorityCheck', 'UniquenessConstraint', 'UnpackedStructType', 'UnpackedUnionType', 'UntypedType', 'ValueExpressionBase', 'ValuePath', 'ValueRangeExpression', 'ValueRangeKind', 'ValueSymbol', 'VariableDeclStatement', 'VariableFlags', 'VariableLifetime', 'VariablePattern', 'VariableSymbol', 'VirtualInterfaceType', 'Visibility', 'VisitAction', 'VoidType', 'WaitForkStatement', 'WaitOrderStatement', 'WaitStatement', 'WhileLoopStatement', 'WildcardImportSymbol', 'WildcardPattern']
class ASTContext:
    def __init__(self, scope: ..., lookupLocation: ..., flags: ASTFlags = ...) -> None:
        ...
    def addAssertionBacktrace(self, diag: ...) -> None:
        ...
    @typing.overload
    def addDiag(self, code: ..., location: ...) -> ...:
        ...
    @typing.overload
    def addDiag(self, code: ..., sourceRange: ...) -> ...:
        ...
    def eval(self, expr: ..., extraFlags: EvalFlags = ...) -> ...:
        ...
    def evalDimension(self, syntax: ..., requireRange: bool, isPacked: bool) -> EvaluatedDimension:
        ...
    @typing.overload
    def evalInteger(self, syntax: ..., extraFlags: ASTFlags = ...) -> int | None:
        ...
    @typing.overload
    def evalInteger(self, expr: ..., extraFlags: EvalFlags = ...) -> int | None:
        ...
    @typing.overload
    def evalPackedDimension(self, syntax: ...) -> EvaluatedDimension:
        ...
    @typing.overload
    def evalPackedDimension(self, syntax: ...) -> EvaluatedDimension:
        ...
    def evalUnpackedDimension(self, syntax: ...) -> EvaluatedDimension:
        ...
    def getRandMode(self, symbol: ...) -> ...:
        ...
    def requireBooleanConvertible(self, expr: ...) -> bool:
        ...
    def requireGtZero(self, value: typing.SupportsInt | typing.SupportsIndex | None, range: ...) -> bool:
        ...
    @typing.overload
    def requireIntegral(self, expr: ...) -> bool:
        ...
    @typing.overload
    def requireIntegral(self, cv: ..., range: ...) -> bool:
        ...
    def requireNoUnknowns(self, value: ..., range: ...) -> bool:
        ...
    @typing.overload
    def requirePositive(self, value: ..., range: ...) -> bool:
        ...
    @typing.overload
    def requirePositive(self, value: typing.SupportsInt | typing.SupportsIndex | None, range: ...) -> bool:
        ...
    @typing.overload
    def requireSimpleExpr(self, expr: ...) -> ...:
        ...
    @typing.overload
    def requireSimpleExpr(self, expr: ..., code: ...) -> ...:
        ...
    @typing.overload
    def requireValidBitWidth(self, width: typing.SupportsInt | typing.SupportsIndex, range: ...) -> bool:
        ...
    @typing.overload
    def requireValidBitWidth(self, value: ..., range: ...) -> int | None:
        ...
    def resetFlags(self, addedFlags: ASTFlags) -> ASTContext:
        ...
    def tryEval(self, expr: ...) -> ...:
        ...
    @property
    def flags(self) -> ASTFlags:
        ...
    @property
    def getCompilation(self) -> ...:
        ...
    @property
    def getInstance(self) -> ...:
        ...
    @property
    def getLocation(self) -> ...:
        ...
    @property
    def getProceduralBlock(self) -> ...:
        ...
    @property
    def inAlwaysCombLatch(self) -> bool:
        ...
    @property
    def inUnevaluatedBranch(self) -> bool:
        ...
    @property
    def lookupIndex(self) -> ...:
        ...
    @property
    def scope(self) -> ...:
        ...
class ASTFlags(enum.Flag):
    AllowClockingBlock: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AllowClockingBlock: 131072>
    AllowCoverageSampleFormal: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AllowCoverageSampleFormal: 33554432>
    AllowCoverpoint: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AllowCoverpoint: 67108864>
    AllowDataType: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AllowDataType: 4>
    AllowInterconnect: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AllowInterconnect: 536870912>
    AllowNetType: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AllowNetType: 134217728>
    AllowTypeReferences: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AllowTypeReferences: 32768>
    AllowUnboundedLiteral: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AllowUnboundedLiteral: 512>
    AllowUnboundedLiteralArithmetic: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AllowUnboundedLiteralArithmetic: 1024>
    AssertionDefaultArg: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AssertionDefaultArg: 17179869184>
    AssertionDelayOrRepetition: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AssertionDelayOrRepetition: 524288>
    AssertionExpr: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AssertionExpr: 65536>
    AssertionInstanceArgCheck: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AssertionInstanceArgCheck: 262144>
    AssignmentAllowed: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AssignmentAllowed: 8>
    AssignmentDisallowed: typing.ClassVar[ASTFlags]  # value = <ASTFlags.AssignmentDisallowed: 16>
    BindInstantiation: typing.ClassVar[ASTFlags]  # value = <ASTFlags.BindInstantiation: 2199023255552>
    ConcurrentAssertActionBlock: typing.ClassVar[ASTFlags]  # value = <ASTFlags.ConcurrentAssertActionBlock: 16777216>
    ConfigParam: typing.ClassVar[ASTFlags]  # value = <ASTFlags.ConfigParam: 137438953472>
    DPIArg: typing.ClassVar[ASTFlags]  # value = <ASTFlags.DPIArg: 8589934592>
    DisallowUDNT: typing.ClassVar[ASTFlags]  # value = <ASTFlags.DisallowUDNT: 1099511627776>
    EventExpression: typing.ClassVar[ASTFlags]  # value = <ASTFlags.EventExpression: 16384>
    Final: typing.ClassVar[ASTFlags]  # value = <ASTFlags.Final: 4096>
    ForkJoinAnyNone: typing.ClassVar[ASTFlags]  # value = <ASTFlags.ForkJoinAnyNone: 549755813888>
    Function: typing.ClassVar[ASTFlags]  # value = <ASTFlags.Function: 2048>
    InsideConcatenation: typing.ClassVar[ASTFlags]  # value = <ASTFlags.InsideConcatenation: 1>
    LAndRValue: typing.ClassVar[ASTFlags]  # value = <ASTFlags.LAndRValue: 34359738368>
    LValue: typing.ClassVar[ASTFlags]  # value = <ASTFlags.LValue: 1048576>
    NoReference: typing.ClassVar[ASTFlags]  # value = <ASTFlags.NoReference: 68719476736>
    NonBlockingTimingControl: typing.ClassVar[ASTFlags]  # value = <ASTFlags.NonBlockingTimingControl: 8192>
    NonProcedural: typing.ClassVar[ASTFlags]  # value = <ASTFlags.NonProcedural: 32>
    OutputArg: typing.ClassVar[ASTFlags]  # value = <ASTFlags.OutputArg: 268435456>
    PropertyNegation: typing.ClassVar[ASTFlags]  # value = <ASTFlags.PropertyNegation: 2097152>
    PropertyTimeAdvance: typing.ClassVar[ASTFlags]  # value = <ASTFlags.PropertyTimeAdvance: 4194304>
    RecursivePropertyArg: typing.ClassVar[ASTFlags]  # value = <ASTFlags.RecursivePropertyArg: 8388608>
    SpecifyBlock: typing.ClassVar[ASTFlags]  # value = <ASTFlags.SpecifyBlock: 2147483648>
    SpecparamInitializer: typing.ClassVar[ASTFlags]  # value = <ASTFlags.SpecparamInitializer: 4294967296>
    StaticInitializer: typing.ClassVar[ASTFlags]  # value = <ASTFlags.StaticInitializer: 64>
    StreamingAllowed: typing.ClassVar[ASTFlags]  # value = <ASTFlags.StreamingAllowed: 128>
    StreamingWithRange: typing.ClassVar[ASTFlags]  # value = <ASTFlags.StreamingWithRange: 1073741824>
    TopLevelStatement: typing.ClassVar[ASTFlags]  # value = <ASTFlags.TopLevelStatement: 256>
    TypeOperator: typing.ClassVar[ASTFlags]  # value = <ASTFlags.TypeOperator: 274877906944>
    UnevaluatedBranch: typing.ClassVar[ASTFlags]  # value = <ASTFlags.UnevaluatedBranch: 2>
    WildcardPortConn: typing.ClassVar[ASTFlags]  # value = <ASTFlags.WildcardPortConn: 4398046511104>
class AbortAssertionExpr(AssertionExpr):
    class Action(enum.Enum):
        Accept: typing.ClassVar[AbortAssertionExpr.Action]  # value = <Action.Accept: 0>
        Reject: typing.ClassVar[AbortAssertionExpr.Action]  # value = <Action.Reject: 1>
    Accept: typing.ClassVar[AbortAssertionExpr.Action]  # value = <Action.Accept: 0>
    Reject: typing.ClassVar[AbortAssertionExpr.Action]  # value = <Action.Reject: 1>
    @property
    def action(self) -> ...:
        ...
    @property
    def condition(self) -> ...:
        ...
    @property
    def expr(self) -> AssertionExpr:
        ...
    @property
    def isSync(self) -> bool:
        ...
class AnonymousProgramSymbol(Symbol, Scope):
    pass
class ArbitrarySymbolExpression(Expression):
    @property
    def symbol(self) -> ...:
        ...
class ArgumentDirection(enum.Enum):
    In: typing.ClassVar[ArgumentDirection]  # value = <ArgumentDirection.In: 0>
    InOut: typing.ClassVar[ArgumentDirection]  # value = <ArgumentDirection.InOut: 2>
    Out: typing.ClassVar[ArgumentDirection]  # value = <ArgumentDirection.Out: 1>
    Ref: typing.ClassVar[ArgumentDirection]  # value = <ArgumentDirection.Ref: 3>
class AssertionExpr:
    def __repr__(self) -> str:
        ...
    def isEquivalentTo(self, other: AssertionExpr) -> bool:
        ...
    @property
    def bad(self) -> bool:
        ...
    @property
    def kind(self) -> AssertionExprKind:
        ...
    @property
    def syntax(self) -> ...:
        ...
class AssertionExprKind(enum.Enum):
    Abort: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.Abort: 9>
    Binary: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.Binary: 5>
    Case: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.Case: 11>
    Clocking: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.Clocking: 7>
    Conditional: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.Conditional: 10>
    DisableIff: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.DisableIff: 12>
    FirstMatch: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.FirstMatch: 6>
    Invalid: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.Invalid: 0>
    SequenceConcat: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.SequenceConcat: 2>
    SequenceWithMatch: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.SequenceWithMatch: 3>
    Simple: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.Simple: 1>
    StrongWeak: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.StrongWeak: 8>
    Unary: typing.ClassVar[AssertionExprKind]  # value = <AssertionExprKind.Unary: 4>
class AssertionInstanceExpression(Expression):
    @property
    def arguments(self) -> span[tuple[..., pyslang.ast.Expression | pyslang.ast.AssertionExpr | pyslang.ast.TimingControl]]:
        ...
    @property
    def body(self) -> AssertionExpr:
        ...
    @property
    def isRecursiveProperty(self) -> bool:
        ...
    @property
    def localVars(self) -> span[...]:
        ...
    @property
    def symbol(self) -> ...:
        ...
class AssertionKind(enum.Enum):
    Assert: typing.ClassVar[AssertionKind]  # value = <AssertionKind.Assert: 0>
    Assume: typing.ClassVar[AssertionKind]  # value = <AssertionKind.Assume: 1>
    CoverProperty: typing.ClassVar[AssertionKind]  # value = <AssertionKind.CoverProperty: 2>
    CoverSequence: typing.ClassVar[AssertionKind]  # value = <AssertionKind.CoverSequence: 3>
    Expect: typing.ClassVar[AssertionKind]  # value = <AssertionKind.Expect: 5>
    Restrict: typing.ClassVar[AssertionKind]  # value = <AssertionKind.Restrict: 4>
class AssertionPortSymbol(Symbol):
    @property
    def direction(self) -> pyslang.ast.ArgumentDirection | None:
        ...
    @property
    def isLocalVar(self) -> bool:
        ...
    @property
    def type(self) -> ...:
        ...
class AssignmentExpression(Expression):
    @property
    def isCompound(self) -> bool:
        ...
    @property
    def isLValueArg(self) -> bool:
        ...
    @property
    def isNonBlocking(self) -> bool:
        ...
    @property
    def left(self) -> Expression:
        ...
    @property
    def op(self) -> pyslang.ast.BinaryOperator | None:
        ...
    @property
    def right(self) -> Expression:
        ...
    @property
    def timingControl(self) -> TimingControl:
        ...
class AssignmentPatternExpressionBase(Expression):
    @property
    def elements(self) -> span[Expression]:
        ...
class AssociativeArrayType(Type):
    @property
    def elementType(self) -> Type:
        ...
    @property
    def indexType(self) -> Type:
        ...
class AttributeSymbol(Symbol):
    @property
    def value(self) -> pyslang.ConstantValue:
        ...
class BinSelectWithFilterExpr(BinsSelectExpr):
    @property
    def expr(self) -> BinsSelectExpr:
        ...
    @property
    def filter(self) -> ...:
        ...
    @property
    def matchesExpr(self) -> ...:
        ...
class BinaryAssertionExpr(AssertionExpr):
    @property
    def left(self) -> AssertionExpr:
        ...
    @property
    def op(self) -> BinaryAssertionOperator:
        ...
    @property
    def right(self) -> AssertionExpr:
        ...
class BinaryAssertionOperator(enum.Enum):
    And: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.And: 0>
    Iff: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.Iff: 5>
    Implies: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.Implies: 10>
    Intersect: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.Intersect: 2>
    NonOverlappedFollowedBy: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.NonOverlappedFollowedBy: 14>
    NonOverlappedImplication: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.NonOverlappedImplication: 12>
    Or: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.Or: 1>
    OverlappedFollowedBy: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.OverlappedFollowedBy: 13>
    OverlappedImplication: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.OverlappedImplication: 11>
    SUntil: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.SUntil: 7>
    SUntilWith: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.SUntilWith: 9>
    Throughout: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.Throughout: 3>
    Until: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.Until: 6>
    UntilWith: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.UntilWith: 8>
    Within: typing.ClassVar[BinaryAssertionOperator]  # value = <BinaryAssertionOperator.Within: 4>
class BinaryBinsSelectExpr(BinsSelectExpr):
    class Op(enum.Enum):
        And: typing.ClassVar[BinaryBinsSelectExpr.Op]  # value = <Op.And: 0>
        Or: typing.ClassVar[BinaryBinsSelectExpr.Op]  # value = <Op.Or: 1>
    And: typing.ClassVar[BinaryBinsSelectExpr.Op]  # value = <Op.And: 0>
    Or: typing.ClassVar[BinaryBinsSelectExpr.Op]  # value = <Op.Or: 1>
    @property
    def left(self) -> BinsSelectExpr:
        ...
    @property
    def op(self) -> ...:
        ...
    @property
    def right(self) -> BinsSelectExpr:
        ...
class BinaryExpression(Expression):
    @property
    def left(self) -> Expression:
        ...
    @property
    def op(self) -> BinaryOperator:
        ...
    @property
    def right(self) -> Expression:
        ...
class BinaryOperator(enum.Enum):
    Add: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.Add: 0>
    ArithmeticShiftLeft: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.ArithmeticShiftLeft: 25>
    ArithmeticShiftRight: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.ArithmeticShiftRight: 26>
    BinaryAnd: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.BinaryAnd: 5>
    BinaryOr: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.BinaryOr: 6>
    BinaryXnor: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.BinaryXnor: 8>
    BinaryXor: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.BinaryXor: 7>
    CaseEquality: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.CaseEquality: 11>
    CaseInequality: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.CaseInequality: 12>
    Divide: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.Divide: 3>
    Equality: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.Equality: 9>
    GreaterThan: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.GreaterThan: 14>
    GreaterThanEqual: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.GreaterThanEqual: 13>
    Inequality: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.Inequality: 10>
    LessThan: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.LessThan: 16>
    LessThanEqual: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.LessThanEqual: 15>
    LogicalAnd: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.LogicalAnd: 19>
    LogicalEquivalence: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.LogicalEquivalence: 22>
    LogicalImplication: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.LogicalImplication: 21>
    LogicalOr: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.LogicalOr: 20>
    LogicalShiftLeft: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.LogicalShiftLeft: 23>
    LogicalShiftRight: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.LogicalShiftRight: 24>
    Mod: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.Mod: 4>
    Multiply: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.Multiply: 2>
    Power: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.Power: 27>
    Subtract: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.Subtract: 1>
    WildcardEquality: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.WildcardEquality: 17>
    WildcardInequality: typing.ClassVar[BinaryOperator]  # value = <BinaryOperator.WildcardInequality: 18>
class BinsSelectExpr:
    def __repr__(self) -> str:
        ...
    @property
    def bad(self) -> bool:
        ...
    @property
    def kind(self) -> BinsSelectExprKind:
        ...
    @property
    def syntax(self) -> ...:
        ...
class BinsSelectExprKind(enum.Enum):
    Binary: typing.ClassVar[BinsSelectExprKind]  # value = <BinsSelectExprKind.Binary: 3>
    Condition: typing.ClassVar[BinsSelectExprKind]  # value = <BinsSelectExprKind.Condition: 1>
    CrossId: typing.ClassVar[BinsSelectExprKind]  # value = <BinsSelectExprKind.CrossId: 6>
    Invalid: typing.ClassVar[BinsSelectExprKind]  # value = <BinsSelectExprKind.Invalid: 0>
    SetExpr: typing.ClassVar[BinsSelectExprKind]  # value = <BinsSelectExprKind.SetExpr: 4>
    Unary: typing.ClassVar[BinsSelectExprKind]  # value = <BinsSelectExprKind.Unary: 2>
    WithFilter: typing.ClassVar[BinsSelectExprKind]  # value = <BinsSelectExprKind.WithFilter: 5>
class BlockEventListControl(TimingControl):
    class Event:
        @property
        def isBegin(self) -> bool:
            ...
        @property
        def target(self) -> ...:
            ...
    @property
    def events(self) -> span[...]:
        ...
class BlockStatement(Statement):
    @property
    def blockKind(self) -> StatementBlockKind:
        ...
    @property
    def blockSymbol(self) -> ...:
        ...
    @property
    def body(self) -> Statement:
        ...
class BreakStatement(Statement):
    pass
class CHandleType(Type):
    pass
class CallExpression(Expression):
    class IteratorCallInfo:
        @property
        def iterExpr(self) -> Expression:
            ...
        @property
        def iterVar(self) -> ...:
            ...
    class RandomizeCallInfo:
        @property
        def constraintRestrictions(self) -> span[str]:
            ...
        @property
        def inlineConstraints(self) -> Constraint:
            ...
    class SystemCallInfo:
        @property
        def extraInfo(self) -> None | pyslang.ast.CallExpression.IteratorCallInfo | pyslang.ast.CallExpression.RandomizeCallInfo:
            ...
        @property
        def scope(self) -> ...:
            ...
        @property
        def subroutine(self) -> SystemSubroutine:
            ...
    @property
    def arguments(self) -> span[Expression]:
        ...
    @property
    def isSystemCall(self) -> bool:
        ...
    @property
    def subroutine(self) -> ... | ...:
        ...
    @property
    def subroutineKind(self) -> SubroutineKind:
        ...
    @property
    def subroutineName(self) -> str:
        ...
    @property
    def thisClass(self) -> Expression:
        ...
class CaseAssertionExpr(AssertionExpr):
    class ItemGroup:
        @property
        def body(self) -> AssertionExpr:
            ...
        @property
        def expressions(self) -> span[...]:
            ...
    @property
    def defaultCase(self) -> AssertionExpr:
        ...
    @property
    def expr(self) -> ...:
        ...
    @property
    def items(self) -> span[...]:
        ...
class CaseStatement(Statement):
    class ItemGroup:
        @property
        def expressions(self) -> span[Expression]:
            ...
        @property
        def stmt(self) -> Statement:
            ...
    @property
    def check(self) -> UniquePriorityCheck:
        ...
    @property
    def condition(self) -> CaseStatementCondition:
        ...
    @property
    def defaultCase(self) -> Statement:
        ...
    @property
    def expr(self) -> Expression:
        ...
    @property
    def items(self) -> span[...]:
        ...
class CaseStatementCondition(enum.Enum):
    Inside: typing.ClassVar[CaseStatementCondition]  # value = <CaseStatementCondition.Inside: 3>
    Normal: typing.ClassVar[CaseStatementCondition]  # value = <CaseStatementCondition.Normal: 0>
    WildcardJustZ: typing.ClassVar[CaseStatementCondition]  # value = <CaseStatementCondition.WildcardJustZ: 2>
    WildcardXOrZ: typing.ClassVar[CaseStatementCondition]  # value = <CaseStatementCondition.WildcardXOrZ: 1>
class CheckerInstanceBodySymbol(Symbol, Scope):
    @property
    def checker(self) -> ...:
        ...
    @property
    def parentInstance(self) -> CheckerInstanceSymbol:
        ...
class CheckerInstanceSymbol(InstanceSymbolBase):
    class Connection:
        @property
        def actual(self) -> pyslang.ast.Expression | pyslang.ast.AssertionExpr | pyslang.ast.TimingControl:
            ...
        @property
        def attributes(self) -> span[AttributeSymbol]:
            ...
        @property
        def formal(self) -> Symbol:
            ...
        @property
        def outputInitialExpr(self) -> Expression:
            ...
    @property
    def body(self) -> ...:
        ...
    @property
    def portConnections(self) -> span[...]:
        ...
class CheckerSymbol(Symbol, Scope):
    @property
    def ports(self) -> span[AssertionPortSymbol]:
        ...
class ClassPropertySymbol(VariableSymbol):
    @property
    def randMode(self) -> RandMode:
        ...
    @property
    def visibility(self) -> Visibility:
        ...
class ClassType(Type, Scope):
    @property
    def baseClass(self) -> Type:
        ...
    @property
    def baseConstructorCall(self) -> Expression:
        ...
    @property
    def constructor(self) -> SubroutineSymbol:
        ...
    @property
    def firstForwardDecl(self) -> ForwardingTypedefSymbol:
        ...
    @property
    def genericClass(self) -> ...:
        ...
    @property
    def implementedInterfaces(self) -> span[Type]:
        ...
    @property
    def isAbstract(self) -> bool:
        ...
    @property
    def isFinal(self) -> bool:
        ...
    @property
    def isInterface(self) -> bool:
        ...
    @property
    def properties(self) -> list:
        ...
    @property
    def thisVar(self) -> VariableSymbol:
        ...
class ClockVarSymbol(VariableSymbol):
    @property
    def direction(self) -> ArgumentDirection:
        ...
    @property
    def inputSkew(self) -> ClockingSkew:
        ...
    @property
    def outputSkew(self) -> ClockingSkew:
        ...
class ClockingAssertionExpr(AssertionExpr):
    @property
    def clocking(self) -> TimingControl:
        ...
    @property
    def expr(self) -> AssertionExpr:
        ...
class ClockingBlockSymbol(Symbol, Scope):
    @property
    def defaultInputSkew(self) -> ClockingSkew:
        ...
    @property
    def defaultOutputSkew(self) -> ClockingSkew:
        ...
    @property
    def event(self) -> TimingControl:
        ...
class ClockingEventExpression(Expression):
    @property
    def timingControl(self) -> TimingControl:
        ...
class ClockingSkew:
    @property
    def delay(self) -> TimingControl:
        ...
    @property
    def edge(self) -> EdgeKind:
        ...
    @property
    def hasValue(self) -> bool:
        ...
class Compilation:
    class DPIExport:
        @property
        def cIdentifier(self) -> str:
            ...
        @property
        def subroutine(self) -> ...:
            ...
        @property
        def syntax(self) -> ...:
            ...
    class DefinitionLookupResult:
        configRoot: ...
        configRule: ...
        definition: ...
        def __init__(self) -> None:
            ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, options: ...) -> None:
        ...
    def addDiagnostics(self, diagnostics: ...) -> None:
        ...
    def addSyntaxTree(self, tree: ...) -> None:
        ...
    def addSystemMethod(self, typeKind: ..., method: ...) -> None:
        ...
    def addSystemSubroutine(self, subroutine: ...) -> None:
        ...
    def createScriptScope(self) -> ...:
        ...
    def freeze(self) -> None:
        ...
    def getAllDiagnostics(self) -> ...:
        ...
    @typing.overload
    def getAttributes(self, symbol: ...) -> span[...]:
        ...
    @typing.overload
    def getAttributes(self, stmt: ...) -> span[...]:
        ...
    @typing.overload
    def getAttributes(self, expr: ...) -> span[...]:
        ...
    @typing.overload
    def getAttributes(self, conn: ...) -> span[...]:
        ...
    def getCompilationUnit(self, syntax: ...) -> ...:
        ...
    def getCompilationUnits(self) -> span[...]:
        ...
    def getDPIExports(self) -> list:
        ...
    def getDefinitions(self) -> list[...]:
        ...
    def getGateType(self, name: str) -> ...:
        ...
    def getNetType(self, kind: ...) -> ...:
        ...
    def getPackage(self, name: str) -> ...:
        ...
    def getPackages(self) -> list[...]:
        ...
    def getParseDiagnostics(self) -> ...:
        ...
    def getRoot(self) -> ...:
        ...
    def getSemanticDiagnostics(self) -> ...:
        ...
    def getSourceLibrary(self, name: str) -> ...:
        ...
    def getStdPackage(self) -> ...:
        ...
    def getSyntaxTrees(self) -> span[...]:
        ...
    def getSystemMethod(self, typeKind: ..., name: str) -> ...:
        ...
    def getSystemSubroutine(self, name: str) -> ...:
        ...
    def getType(self, kind: ...) -> ...:
        ...
    def parseName(self, name: str) -> ...:
        ...
    def tryGetDefinition(self, name: str, scope: ...) -> ...:
        ...
    def tryParseName(self, name: str, diags: ...) -> ...:
        ...
    def unfreeze(self) -> None:
        ...
    @property
    def bitType(self) -> ...:
        ...
    @property
    def byteType(self) -> ...:
        ...
    @property
    def defaultLibrary(self) -> ...:
        ...
    @property
    def defaultTimeScale(self) -> ... | None:
        ...
    @property
    def errorType(self) -> ...:
        ...
    @property
    def hasFatalErrors(self) -> bool:
        ...
    @property
    def hasIssuedErrors(self) -> bool:
        ...
    @property
    def intType(self) -> ...:
        ...
    @property
    def integerType(self) -> ...:
        ...
    @property
    def isElaborated(self) -> bool:
        ...
    @property
    def isFinalized(self) -> bool:
        ...
    @property
    def logicType(self) -> ...:
        ...
    @property
    def nullType(self) -> ...:
        ...
    @property
    def options(self) -> CompilationOptions:
        ...
    @property
    def realType(self) -> ...:
        ...
    @property
    def shortRealType(self) -> ...:
        ...
    @property
    def sourceManager(self) -> ...:
        ...
    @property
    def stringType(self) -> ...:
        ...
    @property
    def typeRefType(self) -> ...:
        ...
    @property
    def unboundedType(self) -> ...:
        ...
    @property
    def unsignedIntType(self) -> ...:
        ...
    @property
    def voidType(self) -> ...:
        ...
    @property
    def wireNetType(self) -> ...:
        ...
class CompilationFlags(enum.Flag):
    AllowArrayConcatAssignPattern: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.AllowArrayConcatAssignPattern: 32768>
    AllowBareValParamAssignment: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.AllowBareValParamAssignment: 256>
    AllowHierarchicalConst: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.AllowHierarchicalConst: 1>
    AllowMergingAnsiPorts: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.AllowMergingAnsiPorts: 1024>
    AllowRecursiveImplicitCall: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.AllowRecursiveImplicitCall: 128>
    AllowSelfDeterminedStreamConcat: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.AllowSelfDeterminedStreamConcat: 512>
    AllowTopLevelIfacePorts: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.AllowTopLevelIfacePorts: 8>
    AllowUnnamedGenerate: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.AllowUnnamedGenerate: 8192>
    AllowUseBeforeDeclare: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.AllowUseBeforeDeclare: 4>
    AllowVirtualIfaceWithOverride: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.AllowVirtualIfaceWithOverride: 16384>
    DisableInstanceCaching: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.DisableInstanceCaching: 2048>
    DisallowRefsToUnknownInstances: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.DisallowRefsToUnknownInstances: 4096>
    IgnoreUnknownModules: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.IgnoreUnknownModules: 32>
    LintMode: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.LintMode: 16>
    RelaxEnumConversions: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.RelaxEnumConversions: 2>
    RelaxStringConversions: typing.ClassVar[CompilationFlags]  # value = <CompilationFlags.RelaxStringConversions: 64>
class CompilationOptions:
    defaultTimeScale: ... | None
    flags: CompilationFlags
    languageVersion: ...
    minTypMax: MinTypMax
    def __init__(self) -> None:
        ...
    @property
    def defaultLiblist(self) -> list[str]:
        ...
    @defaultLiblist.setter
    def defaultLiblist(self, arg0: collections.abc.Sequence[str]) -> None:
        ...
    @property
    def errorLimit(self) -> int:
        ...
    @errorLimit.setter
    def errorLimit(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxCheckerInstanceDepth(self) -> int:
        ...
    @maxCheckerInstanceDepth.setter
    def maxCheckerInstanceDepth(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxConstantSize(self) -> int:
        ...
    @maxConstantSize.setter
    def maxConstantSize(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxConstexprBacktrace(self) -> int:
        ...
    @maxConstexprBacktrace.setter
    def maxConstexprBacktrace(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxConstexprDepth(self) -> int:
        ...
    @maxConstexprDepth.setter
    def maxConstexprDepth(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxConstexprSteps(self) -> int:
        ...
    @maxConstexprSteps.setter
    def maxConstexprSteps(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxDefParamBlocks(self) -> int:
        ...
    @maxDefParamBlocks.setter
    def maxDefParamBlocks(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxDefParamSteps(self) -> int:
        ...
    @maxDefParamSteps.setter
    def maxDefParamSteps(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxEnumValues(self) -> int:
        ...
    @maxEnumValues.setter
    def maxEnumValues(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxGenerateSteps(self) -> int:
        ...
    @maxGenerateSteps.setter
    def maxGenerateSteps(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxInstanceArray(self) -> int:
        ...
    @maxInstanceArray.setter
    def maxInstanceArray(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxInstanceDepth(self) -> int:
        ...
    @maxInstanceDepth.setter
    def maxInstanceDepth(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxRecursiveClassSpecialization(self) -> int:
        ...
    @maxRecursiveClassSpecialization.setter
    def maxRecursiveClassSpecialization(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxUDPCoverageNotes(self) -> int:
        ...
    @maxUDPCoverageNotes.setter
    def maxUDPCoverageNotes(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def paramOverrides(self) -> list[str]:
        ...
    @paramOverrides.setter
    def paramOverrides(self, arg0: collections.abc.Sequence[str]) -> None:
        ...
    @property
    def topModules(self) -> set[str]:
        ...
    @topModules.setter
    def topModules(self, arg0: collections.abc.Set[str]) -> None:
        ...
    @property
    def typoCorrectionLimit(self) -> int:
        ...
    @typoCorrectionLimit.setter
    def typoCorrectionLimit(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
class CompilationUnitSymbol(Symbol, Scope):
    @property
    def timeScale(self) -> pyslang.TimeScale | None:
        ...
class ConcatenationExpression(Expression):
    @property
    def operands(self) -> span[Expression]:
        ...
class ConcurrentAssertionStatement(Statement):
    @property
    def assertionKind(self) -> AssertionKind:
        ...
    @property
    def ifFalse(self) -> Statement:
        ...
    @property
    def ifTrue(self) -> Statement:
        ...
    @property
    def propertySpec(self) -> AssertionExpr:
        ...
class ConditionBinsSelectExpr(BinsSelectExpr):
    @property
    def intersects(self) -> span[...]:
        ...
    @property
    def target(self) -> ...:
        ...
class ConditionalAssertionExpr(AssertionExpr):
    @property
    def condition(self) -> ...:
        ...
    @property
    def elseExpr(self) -> AssertionExpr:
        ...
    @property
    def ifExpr(self) -> AssertionExpr:
        ...
class ConditionalConstraint(Constraint):
    @property
    def elseBody(self) -> Constraint:
        ...
    @property
    def ifBody(self) -> Constraint:
        ...
    @property
    def predicate(self) -> ...:
        ...
class ConditionalExpression(Expression):
    class Condition:
        @property
        def expr(self) -> Expression:
            ...
        @property
        def pattern(self) -> Pattern:
            ...
    @property
    def conditions(self) -> span[...]:
        ...
    @property
    def left(self) -> Expression:
        ...
    @property
    def right(self) -> Expression:
        ...
class ConditionalStatement(Statement):
    class Condition:
        @property
        def expr(self) -> Expression:
            ...
        @property
        def pattern(self) -> Pattern:
            ...
    @property
    def check(self) -> UniquePriorityCheck:
        ...
    @property
    def conditions(self) -> span[...]:
        ...
    @property
    def ifFalse(self) -> Statement:
        ...
    @property
    def ifTrue(self) -> Statement:
        ...
class ConfigBlockSymbol(Symbol, Scope):
    pass
class ConstantPattern(Pattern):
    @property
    def expr(self) -> ...:
        ...
class Constraint:
    def __repr__(self) -> str:
        ...
    def isEquivalentTo(self, other: Constraint) -> bool:
        ...
    @property
    def bad(self) -> bool:
        ...
    @property
    def kind(self) -> ConstraintKind:
        ...
    @property
    def syntax(self) -> ...:
        ...
class ConstraintBlockFlags(enum.Flag):
    ExplicitExtern: typing.ClassVar[ConstraintBlockFlags]  # value = <ConstraintBlockFlags.ExplicitExtern: 16>
    Extends: typing.ClassVar[ConstraintBlockFlags]  # value = <ConstraintBlockFlags.Extends: 64>
    Extern: typing.ClassVar[ConstraintBlockFlags]  # value = <ConstraintBlockFlags.Extern: 8>
    Final: typing.ClassVar[ConstraintBlockFlags]  # value = <ConstraintBlockFlags.Final: 128>
    Initial: typing.ClassVar[ConstraintBlockFlags]  # value = <ConstraintBlockFlags.Initial: 32>
    Pure: typing.ClassVar[ConstraintBlockFlags]  # value = <ConstraintBlockFlags.Pure: 2>
    Static: typing.ClassVar[ConstraintBlockFlags]  # value = <ConstraintBlockFlags.Static: 4>
class ConstraintBlockSymbol(Symbol, Scope):
    @property
    def constraints(self) -> Constraint:
        ...
    @property
    def flags(self) -> ConstraintBlockFlags:
        ...
    @property
    def thisVar(self) -> VariableSymbol:
        ...
class ConstraintKind(enum.Enum):
    Conditional: typing.ClassVar[ConstraintKind]  # value = <ConstraintKind.Conditional: 4>
    DisableSoft: typing.ClassVar[ConstraintKind]  # value = <ConstraintKind.DisableSoft: 6>
    Expression: typing.ClassVar[ConstraintKind]  # value = <ConstraintKind.Expression: 2>
    Foreach: typing.ClassVar[ConstraintKind]  # value = <ConstraintKind.Foreach: 8>
    Implication: typing.ClassVar[ConstraintKind]  # value = <ConstraintKind.Implication: 3>
    Invalid: typing.ClassVar[ConstraintKind]  # value = <ConstraintKind.Invalid: 0>
    List: typing.ClassVar[ConstraintKind]  # value = <ConstraintKind.List: 1>
    SolveBefore: typing.ClassVar[ConstraintKind]  # value = <ConstraintKind.SolveBefore: 7>
    Uniqueness: typing.ClassVar[ConstraintKind]  # value = <ConstraintKind.Uniqueness: 5>
class ConstraintList(Constraint):
    @property
    def list(self) -> span[Constraint]:
        ...
class ContinueStatement(Statement):
    pass
class ContinuousAssignSymbol(Symbol):
    @property
    def assignment(self) -> Expression:
        ...
    @property
    def delay(self) -> TimingControl:
        ...
    @property
    def driveStrength(self) -> tuple[... | None, ... | None]:
        ...
class ConversionExpression(Expression):
    @property
    def conversionKind(self) -> ConversionKind:
        ...
    @property
    def isConstCast(self) -> bool:
        ...
    @property
    def isImplicit(self) -> bool:
        ...
    @property
    def operand(self) -> Expression:
        ...
class ConversionKind(enum.Enum):
    BitstreamCast: typing.ClassVar[ConversionKind]  # value = <ConversionKind.BitstreamCast: 4>
    Explicit: typing.ClassVar[ConversionKind]  # value = <ConversionKind.Explicit: 3>
    Implicit: typing.ClassVar[ConversionKind]  # value = <ConversionKind.Implicit: 0>
    Propagated: typing.ClassVar[ConversionKind]  # value = <ConversionKind.Propagated: 1>
    StreamingConcat: typing.ClassVar[ConversionKind]  # value = <ConversionKind.StreamingConcat: 2>
class CopyClassExpression(Expression):
    @property
    def sourceExpr(self) -> Expression:
        ...
class CoverCrossBodySymbol(Symbol, Scope):
    @property
    def crossQueueType(self) -> ...:
        ...
class CoverCrossSymbol(Symbol, Scope):
    @property
    def iffExpr(self) -> Expression:
        ...
    @property
    def options(self) -> span[CoverageOptionSetter]:
        ...
    @property
    def targets(self) -> span[CoverpointSymbol]:
        ...
class CoverageBinSymbol(Symbol):
    class BinKind(enum.Enum):
        Bins: typing.ClassVar[CoverageBinSymbol.BinKind]  # value = <BinKind.Bins: 0>
        IgnoreBins: typing.ClassVar[CoverageBinSymbol.BinKind]  # value = <BinKind.IgnoreBins: 2>
        IllegalBins: typing.ClassVar[CoverageBinSymbol.BinKind]  # value = <BinKind.IllegalBins: 1>
    class TransRangeList:
        class RepeatKind(enum.Enum):
            Consecutive: typing.ClassVar[CoverageBinSymbol.TransRangeList.RepeatKind]  # value = <RepeatKind.Consecutive: 1>
            GoTo: typing.ClassVar[CoverageBinSymbol.TransRangeList.RepeatKind]  # value = <RepeatKind.GoTo: 3>
            Nonconsecutive: typing.ClassVar[CoverageBinSymbol.TransRangeList.RepeatKind]  # value = <RepeatKind.Nonconsecutive: 2>
            None_: typing.ClassVar[CoverageBinSymbol.TransRangeList.RepeatKind]  # value = <RepeatKind.None_: 0>
        Consecutive: typing.ClassVar[CoverageBinSymbol.TransRangeList.RepeatKind]  # value = <RepeatKind.Consecutive: 1>
        GoTo: typing.ClassVar[CoverageBinSymbol.TransRangeList.RepeatKind]  # value = <RepeatKind.GoTo: 3>
        Nonconsecutive: typing.ClassVar[CoverageBinSymbol.TransRangeList.RepeatKind]  # value = <RepeatKind.Nonconsecutive: 2>
        None_: typing.ClassVar[CoverageBinSymbol.TransRangeList.RepeatKind]  # value = <RepeatKind.None_: 0>
        @property
        def items(self) -> span[Expression]:
            ...
        @property
        def repeatFrom(self) -> Expression:
            ...
        @property
        def repeatKind(self) -> ...:
            ...
        @property
        def repeatTo(self) -> Expression:
            ...
    Bins: typing.ClassVar[CoverageBinSymbol.BinKind]  # value = <BinKind.Bins: 0>
    IgnoreBins: typing.ClassVar[CoverageBinSymbol.BinKind]  # value = <BinKind.IgnoreBins: 2>
    IllegalBins: typing.ClassVar[CoverageBinSymbol.BinKind]  # value = <BinKind.IllegalBins: 1>
    @property
    def binsKind(self) -> ...:
        ...
    @property
    def crossSelectExpr(self) -> BinsSelectExpr:
        ...
    @property
    def iffExpr(self) -> Expression:
        ...
    @property
    def isArray(self) -> bool:
        ...
    @property
    def isDefault(self) -> bool:
        ...
    @property
    def isDefaultSequence(self) -> bool:
        ...
    @property
    def isWildcard(self) -> bool:
        ...
    @property
    def numberOfBinsExpr(self) -> Expression:
        ...
    @property
    def setCoverageExpr(self) -> Expression:
        ...
    @property
    def values(self) -> span[Expression]:
        ...
    @property
    def withExpr(self) -> Expression:
        ...
class CoverageOptionSetter:
    @property
    def expression(self) -> Expression:
        ...
    @property
    def isTypeOption(self) -> bool:
        ...
    @property
    def name(self) -> str:
        ...
class CovergroupBodySymbol(Symbol, Scope):
    @property
    def options(self) -> span[CoverageOptionSetter]:
        ...
class CovergroupType(Type, Scope):
    @property
    def arguments(self) -> span[FormalArgumentSymbol]:
        ...
    @property
    def baseGroup(self) -> Type:
        ...
    @property
    def body(self) -> CovergroupBodySymbol:
        ...
    @property
    def coverageEvent(self) -> TimingControl:
        ...
class CoverpointSymbol(Symbol, Scope):
    @property
    def coverageExpr(self) -> Expression:
        ...
    @property
    def iffExpr(self) -> Expression:
        ...
    @property
    def options(self) -> span[CoverageOptionSetter]:
        ...
    @property
    def type(self) -> ...:
        ...
class CrossIdBinsSelectExpr(BinsSelectExpr):
    pass
class CycleDelayControl(TimingControl):
    @property
    def expr(self) -> ...:
        ...
class DPIOpenArrayType(Type):
    @property
    def elementType(self) -> Type:
        ...
    @property
    def isPacked(self) -> bool:
        ...
class DataTypeExpression(Expression):
    pass
class DeclaredType:
    @property
    def initializer(self) -> Expression:
        ...
    @property
    def initializerLocation(self) -> pyslang.SourceLocation:
        ...
    @property
    def initializerSyntax(self) -> pyslang.syntax.ExpressionSyntax:
        ...
    @property
    def isEvaluating(self) -> bool:
        ...
    @property
    def resolvedDimensions(self) -> list[EvaluatedDimension]:
        ...
    @property
    def type(self) -> Type:
        ...
    @property
    def typeSyntax(self) -> pyslang.syntax.DataTypeSyntax:
        ...
class DefParamSymbol(Symbol):
    @property
    def initializer(self) -> Expression:
        ...
    @property
    def target(self) -> Symbol:
        ...
    @property
    def value(self) -> pyslang.ConstantValue:
        ...
class DefinitionKind(enum.Enum):
    Interface: typing.ClassVar[DefinitionKind]  # value = <DefinitionKind.Interface: 1>
    Module: typing.ClassVar[DefinitionKind]  # value = <DefinitionKind.Module: 0>
    Program: typing.ClassVar[DefinitionKind]  # value = <DefinitionKind.Program: 2>
class DefinitionSymbol(Symbol):
    def __repr__(self) -> str:
        ...
    def getArticleKindString(self) -> str:
        ...
    def getKindString(self) -> str:
        ...
    @property
    def cellDefine(self) -> bool:
        ...
    @property
    def defaultLifetime(self) -> VariableLifetime:
        ...
    @property
    def defaultNetType(self) -> ...:
        ...
    @property
    def definitionKind(self) -> DefinitionKind:
        ...
    @property
    def instanceCount(self) -> int:
        ...
    @property
    def timeScale(self) -> pyslang.TimeScale | None:
        ...
    @property
    def unconnectedDrive(self) -> UnconnectedDrive:
        ...
class Delay3Control(TimingControl):
    @property
    def expr1(self) -> ...:
        ...
    @property
    def expr2(self) -> ...:
        ...
    @property
    def expr3(self) -> ...:
        ...
class DelayControl(TimingControl):
    @property
    def expr(self) -> ...:
        ...
class DimensionKind(enum.Enum):
    AbbreviatedRange: typing.ClassVar[DimensionKind]  # value = <DimensionKind.AbbreviatedRange: 2>
    Associative: typing.ClassVar[DimensionKind]  # value = <DimensionKind.Associative: 4>
    DPIOpenArray: typing.ClassVar[DimensionKind]  # value = <DimensionKind.DPIOpenArray: 6>
    Dynamic: typing.ClassVar[DimensionKind]  # value = <DimensionKind.Dynamic: 3>
    Queue: typing.ClassVar[DimensionKind]  # value = <DimensionKind.Queue: 5>
    Range: typing.ClassVar[DimensionKind]  # value = <DimensionKind.Range: 1>
    Unknown: typing.ClassVar[DimensionKind]  # value = <DimensionKind.Unknown: 0>
class DisableForkStatement(Statement):
    pass
class DisableIffAssertionExpr(AssertionExpr):
    @property
    def condition(self) -> ...:
        ...
    @property
    def expr(self) -> AssertionExpr:
        ...
class DisableSoftConstraint(Constraint):
    @property
    def target(self) -> ...:
        ...
class DisableStatement(Statement):
    @property
    def target(self) -> Expression:
        ...
class DistExpression(Expression):
    class DistItem:
        @property
        def value(self) -> Expression:
            ...
        @property
        def weight(self) -> pyslang.ast.DistExpression.DistWeight | None:
            ...
    class DistWeight:
        class Kind(enum.Enum):
            PerRange: typing.ClassVar[DistExpression.DistWeight.Kind]  # value = <Kind.PerRange: 1>
            PerValue: typing.ClassVar[DistExpression.DistWeight.Kind]  # value = <Kind.PerValue: 0>
        PerRange: typing.ClassVar[DistExpression.DistWeight.Kind]  # value = <Kind.PerRange: 1>
        PerValue: typing.ClassVar[DistExpression.DistWeight.Kind]  # value = <Kind.PerValue: 0>
        @property
        def expr(self) -> Expression:
            ...
        @property
        def kind(self) -> ...:
            ...
    @property
    def defaultWeight(self) -> ...:
        ...
    @property
    def items(self) -> span[...]:
        ...
    @property
    def left(self) -> Expression:
        ...
class DoWhileLoopStatement(Statement):
    @property
    def body(self) -> Statement:
        ...
    @property
    def cond(self) -> Expression:
        ...
class DynamicArrayType(Type):
    @property
    def elementType(self) -> Type:
        ...
class EdgeKind(enum.Enum):
    BothEdges: typing.ClassVar[EdgeKind]  # value = <EdgeKind.BothEdges: 3>
    NegEdge: typing.ClassVar[EdgeKind]  # value = <EdgeKind.NegEdge: 2>
    None_: typing.ClassVar[EdgeKind]  # value = <EdgeKind.None_: 0>
    PosEdge: typing.ClassVar[EdgeKind]  # value = <EdgeKind.PosEdge: 1>
class ElabSystemTaskKind(enum.Enum):
    Error: typing.ClassVar[ElabSystemTaskKind]  # value = <ElabSystemTaskKind.Error: 1>
    Fatal: typing.ClassVar[ElabSystemTaskKind]  # value = <ElabSystemTaskKind.Fatal: 0>
    Info: typing.ClassVar[ElabSystemTaskKind]  # value = <ElabSystemTaskKind.Info: 3>
    StaticAssert: typing.ClassVar[ElabSystemTaskKind]  # value = <ElabSystemTaskKind.StaticAssert: 4>
    Warning: typing.ClassVar[ElabSystemTaskKind]  # value = <ElabSystemTaskKind.Warning: 2>
class ElabSystemTaskSymbol(Symbol):
    @property
    def assertCondition(self) -> Expression:
        ...
    @property
    def message(self) -> str | None:
        ...
    @property
    def taskKind(self) -> ElabSystemTaskKind:
        ...
class ElementSelectExpression(Expression):
    @property
    def selector(self) -> Expression:
        ...
    @property
    def value(self) -> Expression:
        ...
class EmptyArgumentExpression(Expression):
    pass
class EmptyMemberSymbol(Symbol):
    pass
class EmptyStatement(Statement):
    pass
class EnumType(IntegralType, Scope):
    @property
    def baseType(self) -> Type:
        ...
    @property
    def systemId(self) -> int:
        ...
class EnumValueSymbol(ValueSymbol):
    @property
    def value(self) -> pyslang.ConstantValue:
        ...
class ErrorType(Type):
    pass
class EvalContext:
    class Frame:
        @property
        def callLocation(self) -> ...:
            ...
        @property
        def lookupLocation(self) -> ...:
            ...
        @property
        def subroutine(self) -> ...:
            ...
        @property
        def temporaries(self) -> dict[..., ...]:
            ...
    queueTarget: ...
    @typing.overload
    def __init__(self, astCtx: ..., flags: EvalFlags = ...) -> None:
        ...
    @typing.overload
    def __init__(self, symbol: ..., flags: EvalFlags = ...) -> None:
        ...
    def createLocal(self, symbol: ..., value: ... = None) -> ...:
        ...
    def deleteLocal(self, symbol: ...) -> None:
        ...
    def dumpStack(self) -> str:
        ...
    def findLocal(self, symbol: ...) -> ...:
        ...
    def popFrame(self) -> None:
        ...
    def popLValue(self) -> None:
        ...
    def pushEmptyFrame(self) -> None:
        ...
    def pushFrame(self, subroutine: ..., callLocation: ..., lookupLocation: ...) -> bool:
        ...
    def pushLValue(self, lval: ...) -> None:
        ...
    def setDisableTarget(self, arg0: ..., arg1: ...) -> None:
        ...
    def step(self, loc: ...) -> bool:
        ...
    @property
    def cacheResults(self) -> bool:
        ...
    @property
    def diagnostics(self) -> ...:
        ...
    @property
    def disableRange(self) -> ...:
        ...
    @property
    def disableTarget(self) -> ...:
        ...
    @property
    def flags(self) -> EvalFlags:
        ...
    @property
    def inFunction(self) -> bool:
        ...
    @property
    def topFrame(self) -> ...:
        ...
    @property
    def topLValue(self) -> ...:
        ...
class EvalFlags(enum.Flag):
    AllowUnboundedPlaceholder: typing.ClassVar[EvalFlags]  # value = <EvalFlags.AllowUnboundedPlaceholder: 8>
    CacheResults: typing.ClassVar[EvalFlags]  # value = <EvalFlags.CacheResults: 2>
    IsScript: typing.ClassVar[EvalFlags]  # value = <EvalFlags.IsScript: 1>
    SpecparamsAllowed: typing.ClassVar[EvalFlags]  # value = <EvalFlags.SpecparamsAllowed: 4>
class EvalResult(enum.Enum):
    Break: typing.ClassVar[EvalResult]  # value = <EvalResult.Break: 3>
    Continue: typing.ClassVar[EvalResult]  # value = <EvalResult.Continue: 4>
    Disable: typing.ClassVar[EvalResult]  # value = <EvalResult.Disable: 5>
    Fail: typing.ClassVar[EvalResult]  # value = <EvalResult.Fail: 0>
    Return: typing.ClassVar[EvalResult]  # value = <EvalResult.Return: 2>
    Success: typing.ClassVar[EvalResult]  # value = <EvalResult.Success: 1>
class EvaluatedDimension:
    @property
    def associativeType(self) -> ...:
        ...
    @property
    def isRange(self) -> bool:
        ...
    @property
    def kind(self) -> DimensionKind:
        ...
    @property
    def leftExpr(self) -> ...:
        ...
    @property
    def queueMaxSize(self) -> int:
        ...
    @property
    def range(self) -> ...:
        ...
    @property
    def rightExpr(self) -> ...:
        ...
class EventListControl(TimingControl):
    @property
    def events(self) -> span[TimingControl]:
        ...
class EventTriggerStatement(Statement):
    @property
    def isNonBlocking(self) -> bool:
        ...
    @property
    def target(self) -> Expression:
        ...
    @property
    def timing(self) -> TimingControl:
        ...
class EventType(Type):
    pass
class ExplicitImportSymbol(Symbol):
    @property
    def importName(self) -> str:
        ...
    @property
    def importedSymbol(self) -> Symbol:
        ...
    @property
    def isFromExport(self) -> bool:
        ...
    @property
    def package(self) -> PackageSymbol:
        ...
    @property
    def packageName(self) -> str:
        ...
class Expression:
    def __repr__(self) -> str:
        ...
    def eval(self, context: EvalContext) -> ...:
        ...
    def evalLValue(self, context: EvalContext) -> LValue:
        ...
    def getSymbolReference(self, allowPacked: bool = True) -> ...:
        ...
    def isEquivalentTo(self, other: Expression) -> bool:
        ...
    def isImplicitlyAssignableTo(self, compilation: Compilation, type: ...) -> bool:
        ...
    def visit(self, f: typing.Any = None, lookup_table: typing.Any = None) -> None:
        """
        Visit a pyslang object with a callback function `f` or a `lookup_table` dict.
        
        At least one of `f` or `lookup_table` must be provided (both default to `None`). If both are provided, 'lookup_table' will be used to decide which callback to use.
        
        When `f` is provided without `lookup_table`, it is called for every node visited. The callback should take a single argument (the current node). Its return value controls traversal: `pyslang.VisitAction.Interrupt` aborts the visit, `pyslang.VisitAction.Skip` skips child nodes, and any other return value (including `pyslang.VisitAction.Advance` or `None`) continues normally.
        
        When `lookup_table` is provided, it should be a dict mapping node kind enum values to handler functions. The C++ side checks each node's kind before crossing the Python boundary, calling only the matching handler. Nodes not in the table are traversed without invoking Python. `f` is not called in this mode.
        """
    @property
    def bad(self) -> bool:
        ...
    @property
    def constant(self) -> ...:
        ...
    @property
    def effectiveWidth(self) -> int | None:
        ...
    @property
    def hasHierarchicalReference(self) -> bool:
        ...
    @property
    def isImplicitString(self) -> bool:
        ...
    @property
    def isUnsizedInteger(self) -> bool:
        ...
    @property
    def kind(self) -> ExpressionKind:
        ...
    @property
    def sourceRange(self) -> ...:
        ...
    @property
    def syntax(self) -> ...:
        ...
    @property
    def type(self) -> ...:
        ...
class ExpressionConstraint(Constraint):
    @property
    def expr(self) -> ...:
        ...
    @property
    def isSoft(self) -> bool:
        ...
class ExpressionKind(enum.Enum):
    ArbitrarySymbol: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.ArbitrarySymbol: 25>
    AssertionInstance: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.AssertionInstance: 39>
    Assignment: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.Assignment: 14>
    BinaryOp: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.BinaryOp: 11>
    Call: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.Call: 21>
    ClockingEvent: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.ClockingEvent: 38>
    Concatenation: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.Concatenation: 15>
    ConditionalOp: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.ConditionalOp: 12>
    Conversion: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.Conversion: 22>
    CopyClass: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.CopyClass: 36>
    DataType: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.DataType: 23>
    Dist: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.Dist: 32>
    ElementSelect: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.ElementSelect: 18>
    EmptyArgument: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.EmptyArgument: 30>
    HierarchicalValue: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.HierarchicalValue: 9>
    Inside: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.Inside: 13>
    IntegerLiteral: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.IntegerLiteral: 1>
    Invalid: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.Invalid: 0>
    LValueReference: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.LValueReference: 26>
    MemberAccess: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.MemberAccess: 20>
    MinTypMax: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.MinTypMax: 37>
    NamedValue: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.NamedValue: 8>
    NewArray: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.NewArray: 33>
    NewClass: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.NewClass: 34>
    NewCovergroup: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.NewCovergroup: 35>
    NullLiteral: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.NullLiteral: 5>
    RangeSelect: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.RangeSelect: 19>
    RealLiteral: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.RealLiteral: 2>
    ReplicatedAssignmentPattern: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.ReplicatedAssignmentPattern: 29>
    Replication: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.Replication: 16>
    SimpleAssignmentPattern: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.SimpleAssignmentPattern: 27>
    Streaming: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.Streaming: 17>
    StringLiteral: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.StringLiteral: 7>
    StructuredAssignmentPattern: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.StructuredAssignmentPattern: 28>
    TaggedUnion: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.TaggedUnion: 40>
    TimeLiteral: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.TimeLiteral: 3>
    TypeReference: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.TypeReference: 24>
    UnaryOp: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.UnaryOp: 10>
    UnbasedUnsizedIntegerLiteral: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.UnbasedUnsizedIntegerLiteral: 4>
    UnboundedLiteral: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.UnboundedLiteral: 6>
    ValueRange: typing.ClassVar[ExpressionKind]  # value = <ExpressionKind.ValueRange: 31>
class ExpressionStatement(Statement):
    @property
    def expr(self) -> Expression:
        ...
class FieldSymbol(VariableSymbol):
    @property
    def bitOffset(self) -> int:
        ...
    @property
    def fieldIndex(self) -> int:
        ...
    @property
    def randMode(self) -> RandMode:
        ...
class FirstMatchAssertionExpr(AssertionExpr):
    @property
    def matchItems(self) -> span[...]:
        ...
    @property
    def seq(self) -> AssertionExpr:
        ...
class FixedSizeUnpackedArrayType(Type):
    @property
    def elementType(self) -> Type:
        ...
    @property
    def range(self) -> pyslang.ConstantRange:
        ...
class FloatingType(Type):
    class Kind(enum.Enum):
        Real: typing.ClassVar[FloatingType.Kind]  # value = <Kind.Real: 0>
        RealTime: typing.ClassVar[FloatingType.Kind]  # value = <Kind.RealTime: 2>
        ShortReal: typing.ClassVar[FloatingType.Kind]  # value = <Kind.ShortReal: 1>
    Real: typing.ClassVar[FloatingType.Kind]  # value = <Kind.Real: 0>
    RealTime: typing.ClassVar[FloatingType.Kind]  # value = <Kind.RealTime: 2>
    ShortReal: typing.ClassVar[FloatingType.Kind]  # value = <Kind.ShortReal: 1>
    @property
    def floatKind(self) -> ...:
        ...
class ForLoopStatement(Statement):
    @property
    def body(self) -> Statement:
        ...
    @property
    def initializers(self) -> span[Expression]:
        ...
    @property
    def loopVars(self) -> span[...]:
        ...
    @property
    def steps(self) -> span[Expression]:
        ...
    @property
    def stopExpr(self) -> Expression:
        ...
class ForeachConstraint(Constraint):
    @property
    def arrayRef(self) -> ...:
        ...
    @property
    def body(self) -> Constraint:
        ...
    @property
    def loopDims(self) -> span[...]:
        ...
class ForeachLoopStatement(Statement):
    class LoopDim:
        @property
        def loopVar(self) -> ...:
            ...
        @property
        def range(self) -> pyslang.ConstantRange | None:
            ...
    @property
    def arrayRef(self) -> Expression:
        ...
    @property
    def body(self) -> Statement:
        ...
    @property
    def loopDims(self) -> span[...]:
        ...
class ForeverLoopStatement(Statement):
    @property
    def body(self) -> Statement:
        ...
class FormalArgumentSymbol(VariableSymbol):
    @property
    def defaultValue(self) -> Expression:
        ...
    @property
    def direction(self) -> ArgumentDirection:
        ...
class ForwardTypeRestriction(enum.Enum):
    Class: typing.ClassVar[ForwardTypeRestriction]  # value = <ForwardTypeRestriction.Class: 4>
    Enum: typing.ClassVar[ForwardTypeRestriction]  # value = <ForwardTypeRestriction.Enum: 1>
    InterfaceClass: typing.ClassVar[ForwardTypeRestriction]  # value = <ForwardTypeRestriction.InterfaceClass: 5>
    None_: typing.ClassVar[ForwardTypeRestriction]  # value = <ForwardTypeRestriction.None_: 0>
    Struct: typing.ClassVar[ForwardTypeRestriction]  # value = <ForwardTypeRestriction.Struct: 2>
    Union: typing.ClassVar[ForwardTypeRestriction]  # value = <ForwardTypeRestriction.Union: 3>
class ForwardingTypedefSymbol(Symbol):
    @property
    def nextForwardDecl(self) -> ForwardingTypedefSymbol:
        ...
    @property
    def typeRestriction(self) -> ForwardTypeRestriction:
        ...
    @property
    def visibility(self) -> pyslang.ast.Visibility | None:
        ...
class GenerateBlockArraySymbol(Symbol, Scope):
    @property
    def constructIndex(self) -> int:
        ...
    @property
    def entries(self) -> span[GenerateBlockSymbol]:
        ...
    @property
    def externalName(self) -> str:
        ...
    @property
    def initialExpression(self) -> Expression:
        ...
    @property
    def iterExpression(self) -> Expression:
        ...
    @property
    def loopVariable(self) -> VariableSymbol:
        ...
    @property
    def stopExpression(self) -> Expression:
        ...
    @property
    def valid(self) -> bool:
        ...
class GenerateBlockSymbol(Symbol, Scope):
    @property
    def arrayIndex(self) -> pyslang.SVInt:
        ...
    @property
    def branchKind(self) -> GenerateBranchKind:
        ...
    @property
    def caseItemExpressions(self) -> span[Expression]:
        ...
    @property
    def conditionExpression(self) -> Expression:
        ...
    @property
    def constructIndex(self) -> int:
        ...
    @property
    def externalName(self) -> str:
        ...
    @property
    def isUninstantiated(self) -> bool:
        ...
class GenerateBranchKind(enum.Enum):
    CaseDefault: typing.ClassVar[GenerateBranchKind]  # value = <GenerateBranchKind.CaseDefault: 3>
    CaseItem: typing.ClassVar[GenerateBranchKind]  # value = <GenerateBranchKind.CaseItem: 2>
    IfFalse: typing.ClassVar[GenerateBranchKind]  # value = <GenerateBranchKind.IfFalse: 1>
    IfTrue: typing.ClassVar[GenerateBranchKind]  # value = <GenerateBranchKind.IfTrue: 0>
    IllegalUnconditional: typing.ClassVar[GenerateBranchKind]  # value = <GenerateBranchKind.IllegalUnconditional: 5>
    LoopIteration: typing.ClassVar[GenerateBranchKind]  # value = <GenerateBranchKind.LoopIteration: 4>
class GenericClassDefSymbol(Symbol):
    @property
    def defaultSpecialization(self, arg1: Scope) -> Type:
        ...
    @property
    def firstForwardDecl(self) -> ForwardingTypedefSymbol:
        ...
    @property
    def invalidSpecialization(self) -> Type:
        ...
    @property
    def isInterface(self) -> bool:
        ...
class GenvarSymbol(Symbol):
    pass
class HierarchicalValueExpression(ValueExpressionBase):
    pass
class ImmediateAssertionStatement(Statement):
    @property
    def assertionKind(self) -> AssertionKind:
        ...
    @property
    def cond(self) -> Expression:
        ...
    @property
    def ifFalse(self) -> Statement:
        ...
    @property
    def ifTrue(self) -> Statement:
        ...
    @property
    def isDeferred(self) -> bool:
        ...
    @property
    def isFinal(self) -> bool:
        ...
class ImplicationConstraint(Constraint):
    @property
    def body(self) -> Constraint:
        ...
    @property
    def predicate(self) -> ...:
        ...
class ImplicitEventControl(TimingControl):
    pass
class InsideExpression(Expression):
    @property
    def left(self) -> Expression:
        ...
    @property
    def rangeList(self) -> span[Expression]:
        ...
class InstanceArraySymbol(Symbol, Scope):
    @property
    def arrayName(self) -> str:
        ...
    @property
    def elements(self) -> span[Symbol]:
        ...
    @property
    def range(self) -> pyslang.ConstantRange:
        ...
class InstanceBodySymbol(Symbol, Scope):
    def findPort(self, portName: str) -> Symbol:
        ...
    def hasSameType(self, other: InstanceBodySymbol) -> bool:
        ...
    @property
    def definition(self) -> DefinitionSymbol:
        ...
    @property
    def parameters(self) -> span[ParameterSymbolBase]:
        ...
    @property
    def parentInstance(self) -> InstanceSymbol:
        ...
    @property
    def portList(self) -> span[Symbol]:
        ...
class InstanceSymbol(InstanceSymbolBase):
    @typing.overload
    def getPortConnection(self, port: PortSymbol) -> PortConnection:
        ...
    @typing.overload
    def getPortConnection(self, port: InterfacePortSymbol) -> PortConnection:
        ...
    @property
    def body(self) -> ...:
        ...
    @property
    def canonicalBody(self) -> ...:
        ...
    @property
    def definition(self) -> DefinitionSymbol:
        ...
    @property
    def isInterface(self) -> bool:
        ...
    @property
    def isModule(self) -> bool:
        ...
    @property
    def portConnections(self) -> span[PortConnection]:
        ...
class InstanceSymbolBase(Symbol):
    @property
    def arrayName(self) -> str:
        ...
    @property
    def arrayPath(self) -> span[int]:
        ...
class IntegerLiteral(Expression):
    @property
    def isDeclaredUnsized(self) -> bool:
        ...
    @property
    def value(self) -> ...:
        ...
class IntegralFlags(enum.Flag):
    FourState: typing.ClassVar[IntegralFlags]  # value = <IntegralFlags.FourState: 2>
    Reg: typing.ClassVar[IntegralFlags]  # value = <IntegralFlags.Reg: 4>
    Signed: typing.ClassVar[IntegralFlags]  # value = <IntegralFlags.Signed: 1>
class IntegralType(Type):
    def getBitVectorRange(self) -> pyslang.ConstantRange:
        ...
    def isDeclaredReg(self) -> bool:
        ...
class InterfacePortSymbol(Symbol):
    @property
    def connection(self) -> tuple[Symbol, ...]:
        ...
    @property
    def declaredRange(self) -> span[pyslang.ConstantRange] | None:
        ...
    @property
    def interfaceDef(self) -> DefinitionSymbol:
        ...
    @property
    def isGeneric(self) -> bool:
        ...
    @property
    def isInvalid(self) -> bool:
        ...
    @property
    def modport(self) -> str:
        ...
class InvalidAssertionExpr(AssertionExpr):
    pass
class InvalidBinsSelectExpr(BinsSelectExpr):
    pass
class InvalidConstraint(Constraint):
    pass
class InvalidExpression(Expression):
    pass
class InvalidPattern(Pattern):
    pass
class InvalidStatement(Statement):
    pass
class InvalidTimingControl(TimingControl):
    pass
class IteratorSymbol(TempVarSymbol):
    pass
class LValue:
    def __init__(self) -> None:
        ...
    def bad(self) -> bool:
        ...
    def load(self) -> ...:
        ...
    def resolve(self) -> ...:
        ...
    def store(self, value: ...) -> None:
        ...
class LValueReferenceExpression(Expression):
    pass
class LetDeclSymbol(Symbol, Scope):
    @property
    def ports(self) -> span[AssertionPortSymbol]:
        ...
class LocalAssertionVarSymbol(VariableSymbol):
    pass
class Lookup:
    @staticmethod
    def ensureAccessible(symbol: ..., context: ASTContext, sourceRange: pyslang.SourceRange | None) -> bool:
        ...
    @staticmethod
    def ensureVisible(symbol: ..., context: ASTContext, sourceRange: pyslang.SourceRange | None) -> bool:
        ...
    @staticmethod
    def findAssertionLocalVar(context: ASTContext, name: ..., result: LookupResult) -> bool:
        ...
    @staticmethod
    def findClass(name: ..., context: ASTContext, requireInterfaceClass: pyslang.DiagCode | None = None) -> ...:
        ...
    @staticmethod
    def findTempVar(scope: ..., symbol: ..., name: ..., result: LookupResult) -> bool:
        ...
    @staticmethod
    def getContainingClass(scope: ...) -> tuple[..., bool]:
        ...
    @staticmethod
    def getVisibility(symbol: ...) -> Visibility:
        ...
    @staticmethod
    def isAccessibleFrom(target: ..., sourceScope: ...) -> bool:
        ...
    @staticmethod
    def isVisibleFrom(symbol: ..., scope: ...) -> bool:
        ...
    @staticmethod
    def name(syntax: ..., context: ASTContext, flags: LookupFlags, result: LookupResult) -> None:
        ...
    @staticmethod
    def unqualified(scope: ..., name: str, flags: LookupFlags = ...) -> ...:
        ...
    @staticmethod
    def unqualifiedAt(scope: ..., name: str, location: LookupLocation, sourceRange: pyslang.SourceRange, flags: LookupFlags = ...) -> ...:
        ...
    @staticmethod
    def withinClassRandomize(context: ASTContext, syntax: ..., flags: LookupFlags, result: LookupResult) -> bool:
        ...
class LookupFlags(enum.Flag):
    AllowDeclaredAfter: typing.ClassVar[LookupFlags]  # value = <LookupFlags.AllowDeclaredAfter: 2>
    AllowIncompleteForwardTypedefs: typing.ClassVar[LookupFlags]  # value = <LookupFlags.AllowIncompleteForwardTypedefs: 32>
    AllowRoot: typing.ClassVar[LookupFlags]  # value = <LookupFlags.AllowRoot: 128>
    AllowUnit: typing.ClassVar[LookupFlags]  # value = <LookupFlags.AllowUnit: 256>
    AllowUnnamedGenerate: typing.ClassVar[LookupFlags]  # value = <LookupFlags.AllowUnnamedGenerate: 16384>
    AlwaysAllowUpward: typing.ClassVar[LookupFlags]  # value = <LookupFlags.AlwaysAllowUpward: 4096>
    DisallowUnitReferences: typing.ClassVar[LookupFlags]  # value = <LookupFlags.DisallowUnitReferences: 8192>
    DisallowWildcardImport: typing.ClassVar[LookupFlags]  # value = <LookupFlags.DisallowWildcardImport: 4>
    IfacePortConn: typing.ClassVar[LookupFlags]  # value = <LookupFlags.IfacePortConn: 512>
    NoSelectors: typing.ClassVar[LookupFlags]  # value = <LookupFlags.NoSelectors: 64>
    NoUndeclaredError: typing.ClassVar[LookupFlags]  # value = <LookupFlags.NoUndeclaredError: 8>
    NoUndeclaredErrorIfUninstantiated: typing.ClassVar[LookupFlags]  # value = <LookupFlags.NoUndeclaredErrorIfUninstantiated: 16>
    StaticInitializer: typing.ClassVar[LookupFlags]  # value = <LookupFlags.StaticInitializer: 1024>
    Type: typing.ClassVar[LookupFlags]  # value = <LookupFlags.Type: 1>
    TypeReference: typing.ClassVar[LookupFlags]  # value = <LookupFlags.TypeReference: 2048>
class LookupLocation:
    __hash__: typing.ClassVar[None] = None
    max: typing.ClassVar[LookupLocation]  # value = <pyslang.ast.LookupLocation object>
    min: typing.ClassVar[LookupLocation]  # value = <pyslang.ast.LookupLocation object>
    @staticmethod
    def after(symbol: ...) -> LookupLocation:
        ...
    @staticmethod
    def before(symbol: ...) -> LookupLocation:
        ...
    def __eq__(self, arg0: LookupLocation) -> bool:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, scope: ..., index: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __ne__(self, arg0: LookupLocation) -> bool:
        ...
    @property
    def index(self) -> ...:
        ...
    @property
    def scope(self) -> ...:
        ...
class LookupResult:
    class MemberSelector:
        @property
        def dotLocation(self) -> pyslang.SourceLocation:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def nameRange(self) -> pyslang.SourceRange:
            ...
    def __init__(self) -> None:
        ...
    def clear(self) -> None:
        ...
    def errorIfSelectors(self, context: ASTContext) -> None:
        ...
    def reportDiags(self, context: ASTContext) -> None:
        ...
    @property
    def diagnostics(self) -> pyslang.Diagnostics:
        ...
    @property
    def flags(self) -> LookupResultFlags:
        ...
    @property
    def found(self) -> ...:
        ...
    @property
    def hasError(self) -> bool:
        ...
    @property
    def selectors(self) -> ...:
        ...
    @property
    def systemSubroutine(self) -> SystemSubroutine:
        ...
    @property
    def upwardCount(self) -> int:
        ...
class LookupResultFlags(enum.Flag):
    FromForwardTypedef: typing.ClassVar[LookupResultFlags]  # value = <LookupResultFlags.FromForwardTypedef: 16>
    FromTypeParam: typing.ClassVar[LookupResultFlags]  # value = <LookupResultFlags.FromTypeParam: 8>
    IsHierarchical: typing.ClassVar[LookupResultFlags]  # value = <LookupResultFlags.IsHierarchical: 2>
    SuppressUndeclared: typing.ClassVar[LookupResultFlags]  # value = <LookupResultFlags.SuppressUndeclared: 4>
    WasImported: typing.ClassVar[LookupResultFlags]  # value = <LookupResultFlags.WasImported: 1>
class MemberAccessExpression(Expression):
    @property
    def member(self) -> ...:
        ...
    @property
    def value(self) -> Expression:
        ...
class MethodFlags(enum.Flag):
    BuiltIn: typing.ClassVar[MethodFlags]  # value = <MethodFlags.BuiltIn: 512>
    Constructor: typing.ClassVar[MethodFlags]  # value = <MethodFlags.Constructor: 8>
    DPIContext: typing.ClassVar[MethodFlags]  # value = <MethodFlags.DPIContext: 256>
    DPIImport: typing.ClassVar[MethodFlags]  # value = <MethodFlags.DPIImport: 128>
    DefaultedSuperArg: typing.ClassVar[MethodFlags]  # value = <MethodFlags.DefaultedSuperArg: 4096>
    Extends: typing.ClassVar[MethodFlags]  # value = <MethodFlags.Extends: 16384>
    Final: typing.ClassVar[MethodFlags]  # value = <MethodFlags.Final: 32768>
    ForkJoin: typing.ClassVar[MethodFlags]  # value = <MethodFlags.ForkJoin: 2048>
    Initial: typing.ClassVar[MethodFlags]  # value = <MethodFlags.Initial: 8192>
    InterfaceExtern: typing.ClassVar[MethodFlags]  # value = <MethodFlags.InterfaceExtern: 16>
    ModportExport: typing.ClassVar[MethodFlags]  # value = <MethodFlags.ModportExport: 64>
    ModportImport: typing.ClassVar[MethodFlags]  # value = <MethodFlags.ModportImport: 32>
    Pure: typing.ClassVar[MethodFlags]  # value = <MethodFlags.Pure: 2>
    Randomize: typing.ClassVar[MethodFlags]  # value = <MethodFlags.Randomize: 1024>
    Static: typing.ClassVar[MethodFlags]  # value = <MethodFlags.Static: 4>
    Virtual: typing.ClassVar[MethodFlags]  # value = <MethodFlags.Virtual: 1>
class MethodPrototypeSymbol(Symbol, Scope):
    class ExternImpl:
        @property
        def impl(self) -> SubroutineSymbol:
            ...
        @property
        def nextImpl(self) -> MethodPrototypeSymbol.ExternImpl:
            ...
    @property
    def arguments(self) -> span[FormalArgumentSymbol]:
        ...
    @property
    def firstExternImpl(self) -> ...:
        ...
    @property
    def flags(self) -> MethodFlags:
        ...
    @property
    def isVirtual(self) -> bool:
        ...
    @property
    def override(self) -> Symbol:
        ...
    @property
    def returnType(self) -> ...:
        ...
    @property
    def subroutine(self) -> SubroutineSymbol:
        ...
    @property
    def subroutineKind(self) -> SubroutineKind:
        ...
    @property
    def visibility(self) -> Visibility:
        ...
class MinTypMax(enum.Enum):
    Max: typing.ClassVar[MinTypMax]  # value = <MinTypMax.Max: 2>
    Min: typing.ClassVar[MinTypMax]  # value = <MinTypMax.Min: 0>
    Typ: typing.ClassVar[MinTypMax]  # value = <MinTypMax.Typ: 1>
class MinTypMaxExpression(Expression):
    @property
    def max(self) -> Expression:
        ...
    @property
    def min(self) -> Expression:
        ...
    @property
    def selected(self) -> Expression:
        ...
    @property
    def typ(self) -> Expression:
        ...
class ModportClockingSymbol(Symbol):
    @property
    def target(self) -> Symbol:
        ...
class ModportPortSymbol(ValueSymbol):
    @property
    def direction(self) -> ArgumentDirection:
        ...
    @property
    def explicitConnection(self) -> Expression:
        ...
    @property
    def internalSymbol(self) -> Symbol:
        ...
class ModportSymbol(Symbol, Scope):
    @property
    def hasExports(self) -> bool:
        ...
class MultiPortSymbol(Symbol):
    @property
    def direction(self) -> ArgumentDirection:
        ...
    @property
    def initializer(self) -> Expression:
        ...
    @property
    def isNullPort(self) -> bool:
        ...
    @property
    def ports(self) -> span[PortSymbol]:
        ...
    @property
    def type(self) -> ...:
        ...
class NamedValueExpression(ValueExpressionBase):
    pass
class NetAliasSymbol(Symbol):
    @property
    def netReferences(self) -> span[Expression]:
        ...
class NetSymbol(ValueSymbol):
    class ExpansionHint(enum.Enum):
        None_: typing.ClassVar[NetSymbol.ExpansionHint]  # value = <ExpansionHint.None_: 0>
        Scalared: typing.ClassVar[NetSymbol.ExpansionHint]  # value = <ExpansionHint.Scalared: 2>
        Vectored: typing.ClassVar[NetSymbol.ExpansionHint]  # value = <ExpansionHint.Vectored: 1>
    None_: typing.ClassVar[NetSymbol.ExpansionHint]  # value = <ExpansionHint.None_: 0>
    Scalared: typing.ClassVar[NetSymbol.ExpansionHint]  # value = <ExpansionHint.Scalared: 2>
    Vectored: typing.ClassVar[NetSymbol.ExpansionHint]  # value = <ExpansionHint.Vectored: 1>
    @property
    def chargeStrength(self) -> ... | None:
        ...
    @property
    def delay(self) -> TimingControl:
        ...
    @property
    def driveStrength(self) -> tuple[... | None, ... | None]:
        ...
    @property
    def expansionHint(self) -> ...:
        ...
    @property
    def isImplicit(self) -> bool:
        ...
    @property
    def netType(self) -> ...:
        ...
class NetType(Symbol):
    class NetKind(enum.Enum):
        Interconnect: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Interconnect: 13>
        Supply0: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Supply0: 10>
        Supply1: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Supply1: 11>
        Tri: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Tri: 4>
        Tri0: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Tri0: 7>
        Tri1: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Tri1: 8>
        TriAnd: typing.ClassVar[NetType.NetKind]  # value = <NetKind.TriAnd: 5>
        TriOr: typing.ClassVar[NetType.NetKind]  # value = <NetKind.TriOr: 6>
        TriReg: typing.ClassVar[NetType.NetKind]  # value = <NetKind.TriReg: 9>
        UWire: typing.ClassVar[NetType.NetKind]  # value = <NetKind.UWire: 12>
        Unknown: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Unknown: 0>
        UserDefined: typing.ClassVar[NetType.NetKind]  # value = <NetKind.UserDefined: 14>
        WAnd: typing.ClassVar[NetType.NetKind]  # value = <NetKind.WAnd: 2>
        WOr: typing.ClassVar[NetType.NetKind]  # value = <NetKind.WOr: 3>
        Wire: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Wire: 1>
    Interconnect: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Interconnect: 13>
    Supply0: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Supply0: 10>
    Supply1: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Supply1: 11>
    Tri: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Tri: 4>
    Tri0: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Tri0: 7>
    Tri1: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Tri1: 8>
    TriAnd: typing.ClassVar[NetType.NetKind]  # value = <NetKind.TriAnd: 5>
    TriOr: typing.ClassVar[NetType.NetKind]  # value = <NetKind.TriOr: 6>
    TriReg: typing.ClassVar[NetType.NetKind]  # value = <NetKind.TriReg: 9>
    UWire: typing.ClassVar[NetType.NetKind]  # value = <NetKind.UWire: 12>
    Unknown: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Unknown: 0>
    UserDefined: typing.ClassVar[NetType.NetKind]  # value = <NetKind.UserDefined: 14>
    WAnd: typing.ClassVar[NetType.NetKind]  # value = <NetKind.WAnd: 2>
    WOr: typing.ClassVar[NetType.NetKind]  # value = <NetKind.WOr: 3>
    Wire: typing.ClassVar[NetType.NetKind]  # value = <NetKind.Wire: 1>
    @staticmethod
    def getSimulatedNetType(internal: NetType, external: NetType, shouldWarn: bool) -> NetType:
        ...
    @property
    def declaredType(self) -> ...:
        ...
    @property
    def isBuiltIn(self) -> bool:
        ...
    @property
    def isError(self) -> bool:
        ...
    @property
    def netKind(self) -> ...:
        ...
    @property
    def resolutionFunction(self) -> SubroutineSymbol:
        ...
class NewArrayExpression(Expression):
    @property
    def initExpr(self) -> Expression:
        ...
    @property
    def sizeExpr(self) -> Expression:
        ...
class NewClassExpression(Expression):
    @property
    def constructorCall(self) -> Expression:
        ...
    @property
    def isSuperClass(self) -> bool:
        ...
class NewCovergroupExpression(Expression):
    @property
    def arguments(self) -> span[Expression]:
        ...
class NonConstantFunction(SimpleSystemSubroutine):
    def __init__(self, name: str, returnType: ..., requiredArgs: typing.SupportsInt | typing.SupportsIndex = 0, argTypes: collections.abc.Sequence[...] = [], isMethod: bool = False) -> None:
        ...
class NullLiteral(Expression):
    pass
class NullType(Type):
    pass
class OneStepDelayControl(TimingControl):
    pass
class PackageSymbol(Symbol, Scope):
    def findForImport(self, name: str) -> Symbol:
        ...
    @property
    def defaultLifetime(self) -> VariableLifetime:
        ...
    @property
    def defaultNetType(self) -> ...:
        ...
    @property
    def exportDecls(self) -> span[...]:
        ...
    @property
    def hasExportAll(self) -> bool:
        ...
    @property
    def timeScale(self) -> pyslang.TimeScale | None:
        ...
class PackedArrayType(IntegralType):
    @property
    def elementType(self) -> Type:
        ...
    @property
    def range(self) -> pyslang.ConstantRange:
        ...
class PackedStructType(IntegralType, Scope):
    @property
    def systemId(self) -> int:
        ...
class PackedUnionType(IntegralType, Scope):
    @property
    def isSoft(self) -> bool:
        ...
    @property
    def isTagged(self) -> bool:
        ...
    @property
    def systemId(self) -> int:
        ...
    @property
    def tagBits(self) -> int:
        ...
class ParameterSymbol(ValueSymbol, ParameterSymbolBase):
    @property
    def isOverridden(self) -> bool:
        ...
    @property
    def value(self) -> pyslang.ConstantValue:
        ...
class ParameterSymbolBase:
    @property
    def isBodyParam(self) -> bool:
        ...
    @property
    def isLocalParam(self) -> bool:
        ...
    @property
    def isPortParam(self) -> bool:
        ...
class Pattern:
    def __repr__(self) -> str:
        ...
    def eval(self, context: EvalContext, value: ..., conditionKind: ...) -> ...:
        ...
    def isEquivalentTo(self, other: Pattern) -> bool:
        ...
    @property
    def bad(self) -> bool:
        ...
    @property
    def kind(self) -> PatternKind:
        ...
    @property
    def sourceRange(self) -> ...:
        ...
    @property
    def syntax(self) -> ...:
        ...
class PatternCaseStatement(Statement):
    class ItemGroup:
        @property
        def filter(self) -> Expression:
            ...
        @property
        def pattern(self) -> Pattern:
            ...
        @property
        def stmt(self) -> Statement:
            ...
    @property
    def check(self) -> UniquePriorityCheck:
        ...
    @property
    def condition(self) -> CaseStatementCondition:
        ...
    @property
    def defaultCase(self) -> Statement:
        ...
    @property
    def expr(self) -> Expression:
        ...
    @property
    def items(self) -> span[...]:
        ...
class PatternKind(enum.Enum):
    Constant: typing.ClassVar[PatternKind]  # value = <PatternKind.Constant: 2>
    Invalid: typing.ClassVar[PatternKind]  # value = <PatternKind.Invalid: 0>
    Structure: typing.ClassVar[PatternKind]  # value = <PatternKind.Structure: 5>
    Tagged: typing.ClassVar[PatternKind]  # value = <PatternKind.Tagged: 4>
    Variable: typing.ClassVar[PatternKind]  # value = <PatternKind.Variable: 3>
    Wildcard: typing.ClassVar[PatternKind]  # value = <PatternKind.Wildcard: 1>
class PatternVarSymbol(TempVarSymbol):
    pass
class PortConnection:
    @property
    def expression(self) -> Expression:
        ...
    @property
    def ifaceConn(self) -> tuple[Symbol, ...]:
        ...
    @property
    def port(self) -> Symbol:
        ...
class PortSymbol(Symbol):
    @property
    def direction(self) -> ArgumentDirection:
        ...
    @property
    def externalLoc(self) -> pyslang.SourceLocation:
        ...
    @property
    def initializer(self) -> Expression:
        ...
    @property
    def internalExpr(self) -> Expression:
        ...
    @property
    def internalSymbol(self) -> Symbol:
        ...
    @property
    def isAnsiPort(self) -> bool:
        ...
    @property
    def isNetPort(self) -> bool:
        ...
    @property
    def isNullPort(self) -> bool:
        ...
    @property
    def type(self) -> ...:
        ...
class PredefinedIntegerType(IntegralType):
    class Kind(enum.Enum):
        Byte: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.Byte: 3>
        Int: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.Int: 1>
        Integer: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.Integer: 4>
        LongInt: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.LongInt: 2>
        ShortInt: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.ShortInt: 0>
        Time: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.Time: 5>
    Byte: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.Byte: 3>
    Int: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.Int: 1>
    Integer: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.Integer: 4>
    LongInt: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.LongInt: 2>
    ShortInt: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.ShortInt: 0>
    Time: typing.ClassVar[PredefinedIntegerType.Kind]  # value = <Kind.Time: 5>
    @property
    def integerKind(self) -> ...:
        ...
class PrimitiveInstanceSymbol(InstanceSymbolBase):
    @property
    def delay(self) -> TimingControl:
        ...
    @property
    def driveStrength(self) -> tuple[... | None, ... | None]:
        ...
    @property
    def portConnections(self) -> span[Expression]:
        ...
    @property
    def primitiveType(self) -> ...:
        ...
class PrimitivePortDirection(enum.Enum):
    In: typing.ClassVar[PrimitivePortDirection]  # value = <PrimitivePortDirection.In: 0>
    InOut: typing.ClassVar[PrimitivePortDirection]  # value = <PrimitivePortDirection.InOut: 3>
    Out: typing.ClassVar[PrimitivePortDirection]  # value = <PrimitivePortDirection.Out: 1>
    OutReg: typing.ClassVar[PrimitivePortDirection]  # value = <PrimitivePortDirection.OutReg: 2>
class PrimitivePortSymbol(ValueSymbol):
    @property
    def direction(self) -> PrimitivePortDirection:
        ...
class PrimitiveSymbol(Symbol, Scope):
    class PrimitiveKind(enum.Enum):
        Fixed: typing.ClassVar[PrimitiveSymbol.PrimitiveKind]  # value = <PrimitiveKind.Fixed: 1>
        NInput: typing.ClassVar[PrimitiveSymbol.PrimitiveKind]  # value = <PrimitiveKind.NInput: 2>
        NOutput: typing.ClassVar[PrimitiveSymbol.PrimitiveKind]  # value = <PrimitiveKind.NOutput: 3>
        UserDefined: typing.ClassVar[PrimitiveSymbol.PrimitiveKind]  # value = <PrimitiveKind.UserDefined: 0>
    class TableEntry:
        @property
        def inputs(self) -> str:
            ...
        @property
        def output(self) -> str:
            ...
        @property
        def state(self) -> str:
            ...
    Fixed: typing.ClassVar[PrimitiveSymbol.PrimitiveKind]  # value = <PrimitiveKind.Fixed: 1>
    NInput: typing.ClassVar[PrimitiveSymbol.PrimitiveKind]  # value = <PrimitiveKind.NInput: 2>
    NOutput: typing.ClassVar[PrimitiveSymbol.PrimitiveKind]  # value = <PrimitiveKind.NOutput: 3>
    UserDefined: typing.ClassVar[PrimitiveSymbol.PrimitiveKind]  # value = <PrimitiveKind.UserDefined: 0>
    @property
    def initVal(self) -> pyslang.ConstantValue:
        ...
    @property
    def isSequential(self) -> bool:
        ...
    @property
    def ports(self) -> span[PrimitivePortSymbol]:
        ...
    @property
    def primitiveKind(self) -> ...:
        ...
    @property
    def table(self) -> span[...]:
        ...
class ProceduralAssignStatement(Statement):
    @property
    def assignment(self) -> Expression:
        ...
    @property
    def isForce(self) -> bool:
        ...
class ProceduralBlockKind(enum.Enum):
    Always: typing.ClassVar[ProceduralBlockKind]  # value = <ProceduralBlockKind.Always: 2>
    AlwaysComb: typing.ClassVar[ProceduralBlockKind]  # value = <ProceduralBlockKind.AlwaysComb: 3>
    AlwaysFF: typing.ClassVar[ProceduralBlockKind]  # value = <ProceduralBlockKind.AlwaysFF: 5>
    AlwaysLatch: typing.ClassVar[ProceduralBlockKind]  # value = <ProceduralBlockKind.AlwaysLatch: 4>
    Final: typing.ClassVar[ProceduralBlockKind]  # value = <ProceduralBlockKind.Final: 1>
    Initial: typing.ClassVar[ProceduralBlockKind]  # value = <ProceduralBlockKind.Initial: 0>
class ProceduralBlockSymbol(Symbol):
    @property
    def blocks(self) -> span[StatementBlockSymbol]:
        ...
    @property
    def body(self) -> Statement:
        ...
    @property
    def isSingleDriverBlock(self) -> bool:
        ...
    @property
    def procedureKind(self) -> ProceduralBlockKind:
        ...
class ProceduralCheckerStatement(Statement):
    @property
    def instances(self) -> span[...]:
        ...
class ProceduralDeassignStatement(Statement):
    @property
    def isRelease(self) -> bool:
        ...
    @property
    def lvalue(self) -> Expression:
        ...
class PropertySymbol(Symbol, Scope):
    @property
    def ports(self) -> span[AssertionPortSymbol]:
        ...
class PropertyType(Type):
    pass
class PulseStyleKind(enum.Enum):
    NoShowCancelled: typing.ClassVar[PulseStyleKind]  # value = <PulseStyleKind.NoShowCancelled: 3>
    OnDetect: typing.ClassVar[PulseStyleKind]  # value = <PulseStyleKind.OnDetect: 1>
    OnEvent: typing.ClassVar[PulseStyleKind]  # value = <PulseStyleKind.OnEvent: 0>
    ShowCancelled: typing.ClassVar[PulseStyleKind]  # value = <PulseStyleKind.ShowCancelled: 2>
class PulseStyleSymbol(Symbol):
    @property
    def pulseStyleKind(self) -> PulseStyleKind:
        ...
    @property
    def terminals(self) -> span[Expression]:
        ...
class QueueType(Type):
    @property
    def elementType(self) -> Type:
        ...
    @property
    def maxBound(self) -> int:
        ...
class RandCaseStatement(Statement):
    class Item:
        @property
        def expr(self) -> Expression:
            ...
        @property
        def stmt(self) -> Statement:
            ...
    @property
    def items(self) -> span[...]:
        ...
class RandMode(enum.Enum):
    None_: typing.ClassVar[RandMode]  # value = <RandMode.None_: 0>
    Rand: typing.ClassVar[RandMode]  # value = <RandMode.Rand: 1>
    RandC: typing.ClassVar[RandMode]  # value = <RandMode.RandC: 2>
class RandSeqProductionSymbol(Symbol, Scope):
    class CaseItem:
        @property
        def expressions(self) -> span[Expression]:
            ...
        @property
        def item(self) -> RandSeqProductionSymbol.ProdItem:
            ...
    class CaseProd(RandSeqProductionSymbol.ProdBase):
        @property
        def defaultItem(self) -> pyslang.ast.RandSeqProductionSymbol.ProdItem | None:
            ...
        @property
        def expr(self) -> Expression:
            ...
        @property
        def items(self) -> span[RandSeqProductionSymbol.CaseItem]:
            ...
    class CodeBlockProd(RandSeqProductionSymbol.ProdBase):
        @property
        def block(self) -> StatementBlockSymbol:
            ...
    class IfElseProd(RandSeqProductionSymbol.ProdBase):
        @property
        def elseItem(self) -> pyslang.ast.RandSeqProductionSymbol.ProdItem | None:
            ...
        @property
        def expr(self) -> Expression:
            ...
        @property
        def ifItem(self) -> RandSeqProductionSymbol.ProdItem:
            ...
    class ProdBase:
        @property
        def kind(self) -> RandSeqProductionSymbol.ProdKind:
            ...
    class ProdItem(RandSeqProductionSymbol.ProdBase):
        @property
        def args(self) -> span[Expression]:
            ...
        @property
        def target(self) -> RandSeqProductionSymbol:
            ...
    class ProdKind(enum.Enum):
        Case: typing.ClassVar[RandSeqProductionSymbol.ProdKind]  # value = <ProdKind.Case: 4>
        CodeBlock: typing.ClassVar[RandSeqProductionSymbol.ProdKind]  # value = <ProdKind.CodeBlock: 1>
        IfElse: typing.ClassVar[RandSeqProductionSymbol.ProdKind]  # value = <ProdKind.IfElse: 2>
        Item: typing.ClassVar[RandSeqProductionSymbol.ProdKind]  # value = <ProdKind.Item: 0>
        Repeat: typing.ClassVar[RandSeqProductionSymbol.ProdKind]  # value = <ProdKind.Repeat: 3>
    class RepeatProd(RandSeqProductionSymbol.ProdBase):
        @property
        def expr(self) -> Expression:
            ...
        @property
        def item(self) -> RandSeqProductionSymbol.ProdItem:
            ...
    class Rule:
        @property
        def codeBlock(self) -> pyslang.ast.RandSeqProductionSymbol.CodeBlockProd | None:
            ...
        @property
        def isRandJoin(self) -> bool:
            ...
        @property
        def prods(self) -> span[RandSeqProductionSymbol.ProdBase]:
            ...
        @property
        def randJoinExpr(self) -> Expression:
            ...
        @property
        def ruleBlock(self) -> StatementBlockSymbol:
            ...
        @property
        def weightExpr(self) -> Expression:
            ...
    @property
    def arguments(self) -> span[FormalArgumentSymbol]:
        ...
    @property
    def returnType(self) -> ...:
        ...
    @property
    def rules(self) -> span[...]:
        ...
class RandSequenceStatement(Statement):
    @property
    def firstProduction(self) -> ...:
        ...
class RangeSelectExpression(Expression):
    @property
    def left(self) -> Expression:
        ...
    @property
    def right(self) -> Expression:
        ...
    @property
    def selectionKind(self) -> RangeSelectionKind:
        ...
    @property
    def value(self) -> Expression:
        ...
class RangeSelectionKind(enum.Enum):
    IndexedDown: typing.ClassVar[RangeSelectionKind]  # value = <RangeSelectionKind.IndexedDown: 2>
    IndexedUp: typing.ClassVar[RangeSelectionKind]  # value = <RangeSelectionKind.IndexedUp: 1>
    Simple: typing.ClassVar[RangeSelectionKind]  # value = <RangeSelectionKind.Simple: 0>
class RealLiteral(Expression):
    @property
    def value(self) -> float:
        ...
class RepeatLoopStatement(Statement):
    @property
    def body(self) -> Statement:
        ...
    @property
    def count(self) -> Expression:
        ...
class RepeatedEventControl(TimingControl):
    @property
    def event(self) -> TimingControl:
        ...
    @property
    def expr(self) -> ...:
        ...
class ReplicatedAssignmentPatternExpression(AssignmentPatternExpressionBase):
    @property
    def count(self) -> Expression:
        ...
class ReplicationExpression(Expression):
    @property
    def concat(self) -> Expression:
        ...
    @property
    def count(self) -> Expression:
        ...
class ReturnStatement(Statement):
    @property
    def expr(self) -> Expression:
        ...
class RootSymbol(Symbol, Scope):
    @property
    def compilationUnits(self) -> span[CompilationUnitSymbol]:
        ...
    @property
    def topInstances(self) -> span[...]:
        ...
class ScalarType(IntegralType):
    class Kind(enum.Enum):
        Bit: typing.ClassVar[ScalarType.Kind]  # value = <Kind.Bit: 0>
        Logic: typing.ClassVar[ScalarType.Kind]  # value = <Kind.Logic: 1>
        Reg: typing.ClassVar[ScalarType.Kind]  # value = <Kind.Reg: 2>
    Bit: typing.ClassVar[ScalarType.Kind]  # value = <Kind.Bit: 0>
    Logic: typing.ClassVar[ScalarType.Kind]  # value = <Kind.Logic: 1>
    Reg: typing.ClassVar[ScalarType.Kind]  # value = <Kind.Reg: 2>
    @property
    def scalarKind(self) -> ...:
        ...
class Scope:
    def __getitem__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> typing.Any:
        ...
    def __iter__(self) -> collections.abc.Iterator[Symbol]:
        ...
    def __len__(self) -> int:
        ...
    def find(self, arg0: str) -> Symbol:
        ...
    def lookupName(self, name: str, location: LookupLocation = ..., flags: LookupFlags = ...) -> Symbol:
        ...
    @property
    def compilation(self) -> Compilation:
        ...
    @property
    def compilationUnit(self) -> ...:
        ...
    @property
    def containingInstance(self) -> ...:
        ...
    @property
    def defaultNetType(self) -> ...:
        ...
    @property
    def isProceduralContext(self) -> bool:
        ...
    @property
    def isUninstantiated(self) -> bool:
        ...
    @property
    def timeScale(self) -> pyslang.TimeScale | None:
        ...
class ScriptSession:
    def __init__(self) -> None:
        ...
    def eval(self, text: str) -> ...:
        ...
    def evalExpression(self, expr: ...) -> ...:
        ...
    def evalStatement(self, expr: ...) -> None:
        ...
    def getDiagnostics(self) -> ...:
        ...
    @property
    def compilation(self) -> Compilation:
        ...
class SequenceConcatExpr(AssertionExpr):
    class Element:
        @property
        def delay(self) -> SequenceRange:
            ...
        @property
        def sequence(self) -> AssertionExpr:
            ...
    @property
    def elements(self) -> span[...]:
        ...
class SequenceRange:
    @property
    def max(self) -> int | None:
        ...
    @property
    def min(self) -> int:
        ...
class SequenceRepetition:
    class Kind(enum.Enum):
        Consecutive: typing.ClassVar[SequenceRepetition.Kind]  # value = <Kind.Consecutive: 0>
        GoTo: typing.ClassVar[SequenceRepetition.Kind]  # value = <Kind.GoTo: 2>
        Nonconsecutive: typing.ClassVar[SequenceRepetition.Kind]  # value = <Kind.Nonconsecutive: 1>
    Consecutive: typing.ClassVar[SequenceRepetition.Kind]  # value = <Kind.Consecutive: 0>
    GoTo: typing.ClassVar[SequenceRepetition.Kind]  # value = <Kind.GoTo: 2>
    Nonconsecutive: typing.ClassVar[SequenceRepetition.Kind]  # value = <Kind.Nonconsecutive: 1>
    @property
    def kind(self) -> ...:
        ...
    @property
    def range(self) -> SequenceRange:
        ...
class SequenceSymbol(Symbol, Scope):
    @property
    def ports(self) -> span[AssertionPortSymbol]:
        ...
class SequenceType(Type):
    pass
class SequenceWithMatchExpr(AssertionExpr):
    @property
    def expr(self) -> AssertionExpr:
        ...
    @property
    def matchItems(self) -> span[...]:
        ...
    @property
    def repetition(self) -> pyslang.ast.SequenceRepetition | None:
        ...
class SetExprBinsSelectExpr(BinsSelectExpr):
    @property
    def expr(self) -> ...:
        ...
    @property
    def matchesExpr(self) -> ...:
        ...
class SignalEventControl(TimingControl):
    @property
    def edge(self) -> ...:
        ...
    @property
    def expr(self) -> ...:
        ...
    @property
    def iffCondition(self) -> ...:
        ...
class SimpleAssertionExpr(AssertionExpr):
    @property
    def expr(self) -> ...:
        ...
    @property
    def repetition(self) -> pyslang.ast.SequenceRepetition | None:
        ...
class SimpleAssignmentPatternExpression(AssignmentPatternExpressionBase):
    pass
class SimpleSystemSubroutine(SystemSubroutine):
    def __init__(self, name: str, kind: SubroutineKind, requiredArgs: typing.SupportsInt | typing.SupportsIndex, argTypes: collections.abc.Sequence[...], returnType: ..., isMethod: bool, isFirstArgLValue: bool = False) -> None:
        ...
class SolveBeforeConstraint(Constraint):
    @property
    def after(self) -> span[...]:
        ...
    @property
    def solve(self) -> span[...]:
        ...
class SpecifyBlockSymbol(Symbol, Scope):
    pass
class SpecparamSymbol(ValueSymbol):
    @property
    def isPathPulse(self) -> bool:
        ...
    @property
    def pathDest(self) -> Symbol:
        ...
    @property
    def pathSource(self) -> Symbol:
        ...
    @property
    def pulseErrorLimit(self) -> pyslang.ConstantValue:
        ...
    @property
    def pulseRejectLimit(self) -> pyslang.ConstantValue:
        ...
    @property
    def value(self) -> pyslang.ConstantValue:
        ...
class Statement:
    def __repr__(self) -> str:
        ...
    def eval(self, context: EvalContext) -> ...:
        ...
    def visit(self, f: typing.Any = None, lookup_table: typing.Any = None) -> None:
        """
        Visit a pyslang object with a callback function `f` or a `lookup_table` dict.
        
        At least one of `f` or `lookup_table` must be provided (both default to `None`). If both are provided, 'lookup_table' will be used to decide which callback to use.
        
        When `f` is provided without `lookup_table`, it is called for every node visited. The callback should take a single argument (the current node). Its return value controls traversal: `pyslang.VisitAction.Interrupt` aborts the visit, `pyslang.VisitAction.Skip` skips child nodes, and any other return value (including `pyslang.VisitAction.Advance` or `None`) continues normally.
        
        When `lookup_table` is provided, it should be a dict mapping node kind enum values to handler functions. The C++ side checks each node's kind before crossing the Python boundary, calling only the matching handler. Nodes not in the table are traversed without invoking Python. `f` is not called in this mode.
        """
    @property
    def bad(self) -> bool:
        ...
    @property
    def kind(self) -> StatementKind:
        ...
    @property
    def sourceRange(self) -> pyslang.SourceRange:
        ...
    @property
    def syntax(self) -> ...:
        ...
class StatementBlockKind(enum.Enum):
    JoinAll: typing.ClassVar[StatementBlockKind]  # value = <StatementBlockKind.JoinAll: 1>
    JoinAny: typing.ClassVar[StatementBlockKind]  # value = <StatementBlockKind.JoinAny: 2>
    JoinNone: typing.ClassVar[StatementBlockKind]  # value = <StatementBlockKind.JoinNone: 3>
    Sequential: typing.ClassVar[StatementBlockKind]  # value = <StatementBlockKind.Sequential: 0>
class StatementBlockSymbol(Symbol, Scope):
    @property
    def blockKind(self) -> StatementBlockKind:
        ...
    @property
    def defaultLifetime(self) -> VariableLifetime:
        ...
class StatementKind(enum.Enum):
    Block: typing.ClassVar[StatementKind]  # value = <StatementKind.Block: 3>
    Break: typing.ClassVar[StatementKind]  # value = <StatementKind.Break: 8>
    Case: typing.ClassVar[StatementKind]  # value = <StatementKind.Case: 11>
    ConcurrentAssertion: typing.ClassVar[StatementKind]  # value = <StatementKind.ConcurrentAssertion: 21>
    Conditional: typing.ClassVar[StatementKind]  # value = <StatementKind.Conditional: 10>
    Continue: typing.ClassVar[StatementKind]  # value = <StatementKind.Continue: 7>
    Disable: typing.ClassVar[StatementKind]  # value = <StatementKind.Disable: 9>
    DisableFork: typing.ClassVar[StatementKind]  # value = <StatementKind.DisableFork: 22>
    DoWhileLoop: typing.ClassVar[StatementKind]  # value = <StatementKind.DoWhileLoop: 17>
    Empty: typing.ClassVar[StatementKind]  # value = <StatementKind.Empty: 1>
    EventTrigger: typing.ClassVar[StatementKind]  # value = <StatementKind.EventTrigger: 26>
    ExpressionStatement: typing.ClassVar[StatementKind]  # value = <StatementKind.ExpressionStatement: 4>
    ForLoop: typing.ClassVar[StatementKind]  # value = <StatementKind.ForLoop: 13>
    ForeachLoop: typing.ClassVar[StatementKind]  # value = <StatementKind.ForeachLoop: 15>
    ForeverLoop: typing.ClassVar[StatementKind]  # value = <StatementKind.ForeverLoop: 18>
    ImmediateAssertion: typing.ClassVar[StatementKind]  # value = <StatementKind.ImmediateAssertion: 20>
    Invalid: typing.ClassVar[StatementKind]  # value = <StatementKind.Invalid: 0>
    List: typing.ClassVar[StatementKind]  # value = <StatementKind.List: 2>
    PatternCase: typing.ClassVar[StatementKind]  # value = <StatementKind.PatternCase: 12>
    ProceduralAssign: typing.ClassVar[StatementKind]  # value = <StatementKind.ProceduralAssign: 27>
    ProceduralChecker: typing.ClassVar[StatementKind]  # value = <StatementKind.ProceduralChecker: 31>
    ProceduralDeassign: typing.ClassVar[StatementKind]  # value = <StatementKind.ProceduralDeassign: 28>
    RandCase: typing.ClassVar[StatementKind]  # value = <StatementKind.RandCase: 29>
    RandSequence: typing.ClassVar[StatementKind]  # value = <StatementKind.RandSequence: 30>
    RepeatLoop: typing.ClassVar[StatementKind]  # value = <StatementKind.RepeatLoop: 14>
    Return: typing.ClassVar[StatementKind]  # value = <StatementKind.Return: 6>
    Timed: typing.ClassVar[StatementKind]  # value = <StatementKind.Timed: 19>
    VariableDeclaration: typing.ClassVar[StatementKind]  # value = <StatementKind.VariableDeclaration: 5>
    Wait: typing.ClassVar[StatementKind]  # value = <StatementKind.Wait: 23>
    WaitFork: typing.ClassVar[StatementKind]  # value = <StatementKind.WaitFork: 24>
    WaitOrder: typing.ClassVar[StatementKind]  # value = <StatementKind.WaitOrder: 25>
    WhileLoop: typing.ClassVar[StatementKind]  # value = <StatementKind.WhileLoop: 16>
class StatementList(Statement):
    @property
    def list(self) -> span[Statement]:
        ...
class StreamingConcatenationExpression(Expression):
    class StreamExpression:
        @property
        def constantWithWidth(self) -> int | None:
            ...
        @property
        def operand(self) -> Expression:
            ...
        @property
        def withExpr(self) -> Expression:
            ...
    @property
    def bitstreamWidth(self) -> int:
        ...
    @property
    def isFixedSize(self) -> bool:
        ...
    @property
    def sliceSize(self) -> int:
        ...
    @property
    def streams(self) -> span[...]:
        ...
class StringLiteral(Expression):
    @property
    def intValue(self) -> ...:
        ...
    @property
    def rawValue(self) -> str:
        ...
    @property
    def value(self) -> str:
        ...
class StringType(Type):
    pass
class StrongWeakAssertionExpr(AssertionExpr):
    class Strength(enum.Enum):
        Strong: typing.ClassVar[StrongWeakAssertionExpr.Strength]  # value = <Strength.Strong: 0>
        Weak: typing.ClassVar[StrongWeakAssertionExpr.Strength]  # value = <Strength.Weak: 1>
    Strong: typing.ClassVar[StrongWeakAssertionExpr.Strength]  # value = <Strength.Strong: 0>
    Weak: typing.ClassVar[StrongWeakAssertionExpr.Strength]  # value = <Strength.Weak: 1>
    @property
    def expr(self) -> AssertionExpr:
        ...
    @property
    def strength(self) -> ...:
        ...
class StructurePattern(Pattern):
    class FieldPattern:
        @property
        def field(self) -> ...:
            ...
        @property
        def pattern(self) -> Pattern:
            ...
    @property
    def patterns(self) -> span[...]:
        ...
class StructuredAssignmentPatternExpression(AssignmentPatternExpressionBase):
    class IndexSetter:
        @property
        def expr(self) -> Expression:
            ...
        @property
        def index(self) -> Expression:
            ...
    class MemberSetter:
        @property
        def expr(self) -> Expression:
            ...
        @property
        def member(self) -> ...:
            ...
    class TypeSetter:
        @property
        def expr(self) -> Expression:
            ...
        @property
        def type(self) -> ...:
            ...
    @property
    def defaultSetter(self) -> Expression:
        ...
    @property
    def indexSetters(self) -> span[...]:
        ...
    @property
    def memberSetters(self) -> span[...]:
        ...
    @property
    def typeSetters(self) -> span[...]:
        ...
class SubroutineKind(enum.Enum):
    Function: typing.ClassVar[SubroutineKind]  # value = <SubroutineKind.Function: 0>
    Task: typing.ClassVar[SubroutineKind]  # value = <SubroutineKind.Task: 1>
class SubroutineSymbol(Symbol, Scope):
    @property
    def arguments(self) -> span[FormalArgumentSymbol]:
        ...
    @property
    def body(self) -> Statement:
        ...
    @property
    def defaultLifetime(self) -> VariableLifetime:
        ...
    @property
    def flags(self) -> MethodFlags:
        ...
    @property
    def isVirtual(self) -> bool:
        ...
    @property
    def override(self) -> SubroutineSymbol:
        ...
    @property
    def prototype(self) -> ...:
        ...
    @property
    def returnType(self) -> ...:
        ...
    @property
    def returnValVar(self) -> VariableSymbol:
        ...
    @property
    def subroutineKind(self) -> SubroutineKind:
        ...
    @property
    def thisVar(self) -> VariableSymbol:
        ...
    @property
    def visibility(self) -> Visibility:
        ...
class Symbol:
    def __repr__(self) -> str:
        ...
    @typing.overload
    def isDeclaredBefore(self, target: Symbol) -> bool | None:
        ...
    @typing.overload
    def isDeclaredBefore(self, location: LookupLocation) -> bool | None:
        ...
    def visit(self, f: typing.Any = None, lookup_table: typing.Any = None) -> None:
        """
        Visit a pyslang object with a callback function `f` or a `lookup_table` dict.
        
        At least one of `f` or `lookup_table` must be provided (both default to `None`). If both are provided, 'lookup_table' will be used to decide which callback to use.
        
        When `f` is provided without `lookup_table`, it is called for every node visited. The callback should take a single argument (the current node). Its return value controls traversal: `pyslang.VisitAction.Interrupt` aborts the visit, `pyslang.VisitAction.Skip` skips child nodes, and any other return value (including `pyslang.VisitAction.Advance` or `None`) continues normally.
        
        When `lookup_table` is provided, it should be a dict mapping node kind enum values to handler functions. The C++ side checks each node's kind before crossing the Python boundary, calling only the matching handler. Nodes not in the table are traversed without invoking Python. `f` is not called in this mode.
        """
    @property
    def declaredType(self) -> ...:
        ...
    @property
    def declaringDefinition(self) -> ...:
        ...
    @property
    def hierarchicalPath(self) -> str:
        ...
    @property
    def isScope(self) -> bool:
        ...
    @property
    def isType(self) -> bool:
        ...
    @property
    def isValue(self) -> bool:
        ...
    @property
    def kind(self) -> SymbolKind:
        ...
    @property
    def lexicalPath(self) -> str:
        ...
    @property
    def location(self) -> pyslang.SourceLocation:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def nextSibling(self) -> Symbol:
        ...
    @property
    def parentScope(self) -> ...:
        ...
    @property
    def randMode(self) -> RandMode:
        ...
    @property
    def sourceLibrary(self) -> pyslang.SourceLibrary:
        ...
    @property
    def syntax(self) -> ...:
        ...
class SymbolKind(enum.Enum):
    AnonymousProgram: typing.ClassVar[SymbolKind]  # value = <SymbolKind.AnonymousProgram: 98>
    AssertionPort: typing.ClassVar[SymbolKind]  # value = <SymbolKind.AssertionPort: 81>
    AssociativeArrayType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.AssociativeArrayType: 16>
    Attribute: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Attribute: 53>
    CHandleType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.CHandleType: 26>
    Checker: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Checker: 86>
    CheckerInstance: typing.ClassVar[SymbolKind]  # value = <SymbolKind.CheckerInstance: 87>
    CheckerInstanceBody: typing.ClassVar[SymbolKind]  # value = <SymbolKind.CheckerInstanceBody: 88>
    ClassProperty: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ClassProperty: 63>
    ClassType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ClassType: 22>
    ClockVar: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ClockVar: 83>
    ClockingBlock: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ClockingBlock: 82>
    CompilationUnit: typing.ClassVar[SymbolKind]  # value = <SymbolKind.CompilationUnit: 3>
    ConfigBlock: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ConfigBlock: 100>
    ConstraintBlock: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ConstraintBlock: 72>
    ContinuousAssign: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ContinuousAssign: 65>
    CoverCross: typing.ClassVar[SymbolKind]  # value = <SymbolKind.CoverCross: 92>
    CoverCrossBody: typing.ClassVar[SymbolKind]  # value = <SymbolKind.CoverCrossBody: 93>
    CoverageBin: typing.ClassVar[SymbolKind]  # value = <SymbolKind.CoverageBin: 94>
    CovergroupBody: typing.ClassVar[SymbolKind]  # value = <SymbolKind.CovergroupBody: 90>
    CovergroupType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.CovergroupType: 23>
    Coverpoint: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Coverpoint: 91>
    DPIOpenArrayType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.DPIOpenArrayType: 15>
    DefParam: typing.ClassVar[SymbolKind]  # value = <SymbolKind.DefParam: 73>
    DeferredMember: typing.ClassVar[SymbolKind]  # value = <SymbolKind.DeferredMember: 4>
    Definition: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Definition: 2>
    DynamicArrayType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.DynamicArrayType: 14>
    ElabSystemTask: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ElabSystemTask: 66>
    EmptyMember: typing.ClassVar[SymbolKind]  # value = <SymbolKind.EmptyMember: 6>
    EnumType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.EnumType: 10>
    EnumValue: typing.ClassVar[SymbolKind]  # value = <SymbolKind.EnumValue: 11>
    ErrorType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ErrorType: 36>
    EventType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.EventType: 28>
    ExplicitImport: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ExplicitImport: 51>
    Field: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Field: 62>
    FixedSizeUnpackedArrayType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.FixedSizeUnpackedArrayType: 13>
    FloatingType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.FloatingType: 9>
    FormalArgument: typing.ClassVar[SymbolKind]  # value = <SymbolKind.FormalArgument: 61>
    ForwardingTypedef: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ForwardingTypedef: 37>
    GenerateBlock: typing.ClassVar[SymbolKind]  # value = <SymbolKind.GenerateBlock: 55>
    GenerateBlockArray: typing.ClassVar[SymbolKind]  # value = <SymbolKind.GenerateBlockArray: 56>
    GenericClassDef: typing.ClassVar[SymbolKind]  # value = <SymbolKind.GenericClassDef: 67>
    Genvar: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Genvar: 54>
    Instance: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Instance: 47>
    InstanceArray: typing.ClassVar[SymbolKind]  # value = <SymbolKind.InstanceArray: 49>
    InstanceBody: typing.ClassVar[SymbolKind]  # value = <SymbolKind.InstanceBody: 48>
    InterfacePort: typing.ClassVar[SymbolKind]  # value = <SymbolKind.InterfacePort: 43>
    Iterator: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Iterator: 70>
    LetDecl: typing.ClassVar[SymbolKind]  # value = <SymbolKind.LetDecl: 85>
    LocalAssertionVar: typing.ClassVar[SymbolKind]  # value = <SymbolKind.LocalAssertionVar: 84>
    MethodPrototype: typing.ClassVar[SymbolKind]  # value = <SymbolKind.MethodPrototype: 68>
    Modport: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Modport: 44>
    ModportClocking: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ModportClocking: 46>
    ModportPort: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ModportPort: 45>
    MultiPort: typing.ClassVar[SymbolKind]  # value = <SymbolKind.MultiPort: 42>
    Net: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Net: 59>
    NetAlias: typing.ClassVar[SymbolKind]  # value = <SymbolKind.NetAlias: 99>
    NetType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.NetType: 38>
    NullType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.NullType: 25>
    Package: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Package: 50>
    PackedArrayType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.PackedArrayType: 12>
    PackedStructType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.PackedStructType: 18>
    PackedUnionType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.PackedUnionType: 20>
    Parameter: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Parameter: 39>
    PatternVar: typing.ClassVar[SymbolKind]  # value = <SymbolKind.PatternVar: 71>
    Port: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Port: 41>
    PredefinedIntegerType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.PredefinedIntegerType: 7>
    Primitive: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Primitive: 75>
    PrimitiveInstance: typing.ClassVar[SymbolKind]  # value = <SymbolKind.PrimitiveInstance: 77>
    PrimitivePort: typing.ClassVar[SymbolKind]  # value = <SymbolKind.PrimitivePort: 76>
    ProceduralBlock: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ProceduralBlock: 57>
    Property: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Property: 80>
    PropertyType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.PropertyType: 33>
    PulseStyle: typing.ClassVar[SymbolKind]  # value = <SymbolKind.PulseStyle: 96>
    QueueType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.QueueType: 17>
    RandSeqProduction: typing.ClassVar[SymbolKind]  # value = <SymbolKind.RandSeqProduction: 89>
    Root: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Root: 1>
    ScalarType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.ScalarType: 8>
    Sequence: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Sequence: 79>
    SequenceType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.SequenceType: 32>
    SpecifyBlock: typing.ClassVar[SymbolKind]  # value = <SymbolKind.SpecifyBlock: 78>
    Specparam: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Specparam: 74>
    StatementBlock: typing.ClassVar[SymbolKind]  # value = <SymbolKind.StatementBlock: 58>
    StringType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.StringType: 27>
    Subroutine: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Subroutine: 64>
    SystemTimingCheck: typing.ClassVar[SymbolKind]  # value = <SymbolKind.SystemTimingCheck: 97>
    TimingPath: typing.ClassVar[SymbolKind]  # value = <SymbolKind.TimingPath: 95>
    TransparentMember: typing.ClassVar[SymbolKind]  # value = <SymbolKind.TransparentMember: 5>
    TypeAlias: typing.ClassVar[SymbolKind]  # value = <SymbolKind.TypeAlias: 35>
    TypeParameter: typing.ClassVar[SymbolKind]  # value = <SymbolKind.TypeParameter: 40>
    TypeRefType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.TypeRefType: 30>
    UnboundedType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.UnboundedType: 29>
    UninstantiatedDef: typing.ClassVar[SymbolKind]  # value = <SymbolKind.UninstantiatedDef: 69>
    Unknown: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Unknown: 0>
    UnpackedStructType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.UnpackedStructType: 19>
    UnpackedUnionType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.UnpackedUnionType: 21>
    UntypedType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.UntypedType: 31>
    Variable: typing.ClassVar[SymbolKind]  # value = <SymbolKind.Variable: 60>
    VirtualInterfaceType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.VirtualInterfaceType: 34>
    VoidType: typing.ClassVar[SymbolKind]  # value = <SymbolKind.VoidType: 24>
    WildcardImport: typing.ClassVar[SymbolKind]  # value = <SymbolKind.WildcardImport: 52>
class SystemSubroutine:
    class WithClauseMode(enum.Enum):
        Iterator: typing.ClassVar[SystemSubroutine.WithClauseMode]  # value = <WithClauseMode.Iterator: 1>
        None_: typing.ClassVar[SystemSubroutine.WithClauseMode]  # value = <WithClauseMode.None_: 0>
        Randomize: typing.ClassVar[SystemSubroutine.WithClauseMode]  # value = <WithClauseMode.Randomize: 2>
    hasOutputArgs: bool
    kind: SubroutineKind
    knownNameId: ...
    name: str
    withClauseMode: ...
    @staticmethod
    def unevaluatedContext(sourceContext: ASTContext) -> ASTContext:
        ...
    def __init__(self, name: str, kind: SubroutineKind) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def allowClockingArgument(self, argIndex: typing.SupportsInt | typing.SupportsIndex) -> bool:
        ...
    def allowEmptyArgument(self, argIndex: typing.SupportsInt | typing.SupportsIndex) -> bool:
        ...
    def badArg(self, context: ASTContext, arg: ...) -> ...:
        ...
    def bindArgument(self, argIndex: typing.SupportsInt | typing.SupportsIndex, context: ASTContext, syntax: ..., previousArgs: span[...]) -> ...:
        ...
    def checkArgCount(self, context: ASTContext, isMethod: bool, args: span[...], callRange: ..., min: typing.SupportsInt | typing.SupportsIndex, max: typing.SupportsInt | typing.SupportsIndex) -> bool:
        ...
    def checkArguments(self, context: ASTContext, args: span[...], range: ..., iterOrThis: ...) -> ...:
        ...
    def eval(self, context: EvalContext, args: span[...], range: ..., callInfo: ...) -> ...:
        ...
    def kindStr(self) -> str:
        ...
    def noHierarchical(self, context: EvalContext, expr: ...) -> bool:
        ...
    def notConst(self, context: EvalContext, range: ...) -> bool:
        ...
class SystemTimingCheckKind(enum.Enum):
    FullSkew: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.FullSkew: 9>
    Hold: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.Hold: 2>
    NoChange: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.NoChange: 12>
    Period: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.Period: 10>
    RecRem: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.RecRem: 6>
    Recovery: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.Recovery: 4>
    Removal: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.Removal: 5>
    Setup: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.Setup: 1>
    SetupHold: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.SetupHold: 3>
    Skew: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.Skew: 7>
    TimeSkew: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.TimeSkew: 8>
    Unknown: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.Unknown: 0>
    Width: typing.ClassVar[SystemTimingCheckKind]  # value = <SystemTimingCheckKind.Width: 11>
class SystemTimingCheckSymbol(Symbol):
    class Arg:
        @property
        def condition(self) -> Expression:
            ...
        @property
        def edge(self) -> EdgeKind:
            ...
        @property
        def edgeDescriptors(self) -> span[typing.Annotated[list[str], "FixedSize(2)"]]:
            ...
        @property
        def expr(self) -> Expression:
            ...
    @property
    def arguments(self) -> span[...]:
        ...
    @property
    def timingCheckKind(self) -> SystemTimingCheckKind:
        ...
class TaggedPattern(Pattern):
    @property
    def member(self) -> ...:
        ...
    @property
    def valuePattern(self) -> Pattern:
        ...
class TaggedUnionExpression(Expression):
    @property
    def member(self) -> ...:
        ...
    @property
    def valueExpr(self) -> Expression:
        ...
class TempVarSymbol(VariableSymbol):
    pass
class TimeLiteral(Expression):
    @property
    def scale(self) -> ...:
        ...
    @property
    def value(self) -> float:
        ...
class TimedStatement(Statement):
    @property
    def stmt(self) -> Statement:
        ...
    @property
    def timing(self) -> TimingControl:
        ...
class TimingControl:
    def __repr__(self) -> str:
        ...
    def isEquivalentTo(self, other: TimingControl) -> bool:
        ...
    def visit(self, f: typing.Any = None, lookup_table: typing.Any = None) -> None:
        """
        Visit a pyslang object with a callback function `f` or a `lookup_table` dict.
        
        At least one of `f` or `lookup_table` must be provided (both default to `None`). If both are provided, 'lookup_table' will be used to decide which callback to use.
        
        When `f` is provided without `lookup_table`, it is called for every node visited. The callback should take a single argument (the current node). Its return value controls traversal: `pyslang.VisitAction.Interrupt` aborts the visit, `pyslang.VisitAction.Skip` skips child nodes, and any other return value (including `pyslang.VisitAction.Advance` or `None`) continues normally.
        
        When `lookup_table` is provided, it should be a dict mapping node kind enum values to handler functions. The C++ side checks each node's kind before crossing the Python boundary, calling only the matching handler. Nodes not in the table are traversed without invoking Python. `f` is not called in this mode.
        """
    @property
    def bad(self) -> bool:
        ...
    @property
    def kind(self) -> TimingControlKind:
        ...
    @property
    def sourceRange(self) -> ...:
        ...
    @property
    def syntax(self) -> ...:
        ...
class TimingControlKind(enum.Enum):
    BlockEventList: typing.ClassVar[TimingControlKind]  # value = <TimingControlKind.BlockEventList: 9>
    CycleDelay: typing.ClassVar[TimingControlKind]  # value = <TimingControlKind.CycleDelay: 8>
    Delay: typing.ClassVar[TimingControlKind]  # value = <TimingControlKind.Delay: 1>
    Delay3: typing.ClassVar[TimingControlKind]  # value = <TimingControlKind.Delay3: 6>
    EventList: typing.ClassVar[TimingControlKind]  # value = <TimingControlKind.EventList: 3>
    ImplicitEvent: typing.ClassVar[TimingControlKind]  # value = <TimingControlKind.ImplicitEvent: 4>
    Invalid: typing.ClassVar[TimingControlKind]  # value = <TimingControlKind.Invalid: 0>
    OneStepDelay: typing.ClassVar[TimingControlKind]  # value = <TimingControlKind.OneStepDelay: 7>
    RepeatedEvent: typing.ClassVar[TimingControlKind]  # value = <TimingControlKind.RepeatedEvent: 5>
    SignalEvent: typing.ClassVar[TimingControlKind]  # value = <TimingControlKind.SignalEvent: 2>
class TimingPathSymbol(Symbol):
    class ConnectionKind(enum.Enum):
        Full: typing.ClassVar[TimingPathSymbol.ConnectionKind]  # value = <ConnectionKind.Full: 0>
        Parallel: typing.ClassVar[TimingPathSymbol.ConnectionKind]  # value = <ConnectionKind.Parallel: 1>
    class Polarity(enum.Enum):
        Negative: typing.ClassVar[TimingPathSymbol.Polarity]  # value = <Polarity.Negative: 2>
        Positive: typing.ClassVar[TimingPathSymbol.Polarity]  # value = <Polarity.Positive: 1>
        Unknown: typing.ClassVar[TimingPathSymbol.Polarity]  # value = <Polarity.Unknown: 0>
    @property
    def conditionExpr(self) -> Expression:
        ...
    @property
    def connectionKind(self) -> ...:
        ...
    @property
    def delays(self) -> span[Expression]:
        ...
    @property
    def edgeIdentifier(self) -> EdgeKind:
        ...
    @property
    def edgePolarity(self) -> ...:
        ...
    @property
    def edgeSourceExpr(self) -> Expression:
        ...
    @property
    def inputs(self) -> span[Expression]:
        ...
    @property
    def isStateDependent(self) -> bool:
        ...
    @property
    def outputs(self) -> span[Expression]:
        ...
    @property
    def polarity(self) -> ...:
        ...
class TransparentMemberSymbol(Symbol):
    @property
    def wrapped(self) -> Symbol:
        ...
class Type(Symbol):
    @staticmethod
    def getCommonBase(left: Type, right: Type) -> Type:
        ...
    def __repr__(self) -> str:
        ...
    def coerceValue(self, value: pyslang.ConstantValue) -> pyslang.ConstantValue:
        ...
    def implements(self, rhs: Type) -> bool:
        ...
    def isAssignmentCompatible(self, rhs: Type) -> bool:
        ...
    def isBitstreamCastable(self, rhs: Type) -> bool:
        ...
    def isBitstreamType(self, destination: bool = False) -> bool:
        ...
    def isCastCompatible(self, rhs: Type) -> bool:
        ...
    def isDerivedFrom(self, rhs: Type) -> bool:
        ...
    def isEquivalent(self, rhs: Type) -> bool:
        ...
    def isMatching(self, rhs: Type) -> bool:
        ...
    def isValidForRand(self, mode: RandMode, languageVersion: pyslang.LanguageVersion) -> bool:
        ...
    @property
    def arrayElementType(self) -> Type:
        ...
    @property
    def associativeIndexType(self) -> Type:
        ...
    @property
    def bitWidth(self) -> int:
        ...
    @property
    def bitstreamWidth(self) -> int:
        ...
    @property
    def canBeStringLike(self) -> bool:
        ...
    @property
    def canonicalType(self) -> Type:
        ...
    @property
    def defaultValue(self) -> pyslang.ConstantValue:
        ...
    @property
    def fixedRange(self) -> pyslang.ConstantRange:
        ...
    @property
    def hasFixedRange(self) -> bool:
        ...
    @property
    def integralFlags(self) -> IntegralFlags:
        ...
    @property
    def isAggregate(self) -> bool:
        ...
    @property
    def isAlias(self) -> bool:
        ...
    @property
    def isArray(self) -> bool:
        ...
    @property
    def isAssociativeArray(self) -> bool:
        ...
    @property
    def isBooleanConvertible(self) -> bool:
        ...
    @property
    def isByteArray(self) -> bool:
        ...
    @property
    def isCHandle(self) -> bool:
        ...
    @property
    def isClass(self) -> bool:
        ...
    @property
    def isCovergroup(self) -> bool:
        ...
    @property
    def isDynamicallySizedArray(self) -> bool:
        ...
    @property
    def isEnum(self) -> bool:
        ...
    @property
    def isError(self) -> bool:
        ...
    @property
    def isEvent(self) -> bool:
        ...
    @property
    def isFixedSize(self) -> bool:
        ...
    @property
    def isFloating(self) -> bool:
        ...
    @property
    def isFourState(self) -> bool:
        ...
    @property
    def isHandleType(self) -> bool:
        ...
    @property
    def isIntegral(self) -> bool:
        ...
    @property
    def isIterable(self) -> bool:
        ...
    @property
    def isNull(self) -> bool:
        ...
    @property
    def isNumeric(self) -> bool:
        ...
    @property
    def isObjectHandleType(self) -> bool:
        ...
    @property
    def isPackedArray(self) -> bool:
        ...
    @property
    def isPackedUnion(self) -> bool:
        ...
    @property
    def isPredefinedInteger(self) -> bool:
        ...
    @property
    def isPropertyType(self) -> bool:
        ...
    @property
    def isQueue(self) -> bool:
        ...
    @property
    def isScalar(self) -> bool:
        ...
    @property
    def isSequenceType(self) -> bool:
        ...
    @property
    def isSigned(self) -> bool:
        ...
    @property
    def isSimpleBitVector(self) -> bool:
        ...
    @property
    def isSimpleType(self) -> bool:
        ...
    @property
    def isSingular(self) -> bool:
        ...
    @property
    def isString(self) -> bool:
        ...
    @property
    def isStruct(self) -> bool:
        ...
    @property
    def isTaggedUnion(self) -> bool:
        ...
    @property
    def isTypeRefType(self) -> bool:
        ...
    @property
    def isUnbounded(self) -> bool:
        ...
    @property
    def isUnpackedArray(self) -> bool:
        ...
    @property
    def isUnpackedStruct(self) -> bool:
        ...
    @property
    def isUnpackedUnion(self) -> bool:
        ...
    @property
    def isUntypedType(self) -> bool:
        ...
    @property
    def isValidForDPIArg(self) -> bool:
        ...
    @property
    def isValidForDPIReturn(self) -> bool:
        ...
    @property
    def isValidForSequence(self) -> bool:
        ...
    @property
    def isVirtualInterface(self) -> bool:
        ...
    @property
    def isVoid(self) -> bool:
        ...
    @property
    def selectableWidth(self) -> int:
        ...
class TypeAliasType(Type):
    @property
    def firstForwardDecl(self) -> ForwardingTypedefSymbol:
        ...
    @property
    def targetType(self) -> DeclaredType:
        ...
    @property
    def visibility(self) -> Visibility:
        ...
class TypeParameterSymbol(Symbol, ParameterSymbolBase):
    @property
    def isOverridden(self) -> bool:
        ...
    @property
    def targetType(self) -> ...:
        ...
    @property
    def typeAlias(self) -> ...:
        ...
class TypePrinter:
    options: TypePrintingOptions
    def __init__(self) -> None:
        ...
    def append(self, type: Type) -> None:
        ...
    def clear(self) -> None:
        ...
    def toString(self) -> str:
        ...
class TypePrintingOptions:
    class AnonymousTypeStyle(enum.Enum):
        FriendlyName: typing.ClassVar[TypePrintingOptions.AnonymousTypeStyle]  # value = <AnonymousTypeStyle.FriendlyName: 1>
        SystemName: typing.ClassVar[TypePrintingOptions.AnonymousTypeStyle]  # value = <AnonymousTypeStyle.SystemName: 0>
    FriendlyName: typing.ClassVar[TypePrintingOptions.AnonymousTypeStyle]  # value = <AnonymousTypeStyle.FriendlyName: 1>
    SystemName: typing.ClassVar[TypePrintingOptions.AnonymousTypeStyle]  # value = <AnonymousTypeStyle.SystemName: 0>
    addSingleQuotes: bool
    anonymousTypeStyle: ...
    elideScopeNames: bool
    fullEnumType: bool
    printAKA: bool
    skipScopedTypeNames: bool
    skipTypeDefs: bool
class TypeRefType(Type):
    pass
class TypeReferenceExpression(Expression):
    @property
    def targetType(self) -> ...:
        ...
class UnaryAssertionExpr(AssertionExpr):
    @property
    def expr(self) -> AssertionExpr:
        ...
    @property
    def op(self) -> UnaryAssertionOperator:
        ...
    @property
    def range(self) -> pyslang.ast.SequenceRange | None:
        ...
class UnaryAssertionOperator(enum.Enum):
    Always: typing.ClassVar[UnaryAssertionOperator]  # value = <UnaryAssertionOperator.Always: 3>
    Eventually: typing.ClassVar[UnaryAssertionOperator]  # value = <UnaryAssertionOperator.Eventually: 5>
    NextTime: typing.ClassVar[UnaryAssertionOperator]  # value = <UnaryAssertionOperator.NextTime: 1>
    Not: typing.ClassVar[UnaryAssertionOperator]  # value = <UnaryAssertionOperator.Not: 0>
    SAlways: typing.ClassVar[UnaryAssertionOperator]  # value = <UnaryAssertionOperator.SAlways: 4>
    SEventually: typing.ClassVar[UnaryAssertionOperator]  # value = <UnaryAssertionOperator.SEventually: 6>
    SNextTime: typing.ClassVar[UnaryAssertionOperator]  # value = <UnaryAssertionOperator.SNextTime: 2>
class UnaryBinsSelectExpr(BinsSelectExpr):
    class Op(enum.Enum):
        Negation: typing.ClassVar[UnaryBinsSelectExpr.Op]  # value = <Op.Negation: 0>
    Negation: typing.ClassVar[UnaryBinsSelectExpr.Op]  # value = <Op.Negation: 0>
    @property
    def expr(self) -> BinsSelectExpr:
        ...
    @property
    def op(self) -> ...:
        ...
class UnaryExpression(Expression):
    @property
    def op(self) -> UnaryOperator:
        ...
    @property
    def operand(self) -> Expression:
        ...
class UnaryOperator(enum.Enum):
    BitwiseAnd: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.BitwiseAnd: 3>
    BitwiseNand: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.BitwiseNand: 6>
    BitwiseNor: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.BitwiseNor: 7>
    BitwiseNot: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.BitwiseNot: 2>
    BitwiseOr: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.BitwiseOr: 4>
    BitwiseXnor: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.BitwiseXnor: 8>
    BitwiseXor: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.BitwiseXor: 5>
    LogicalNot: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.LogicalNot: 9>
    Minus: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.Minus: 1>
    Plus: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.Plus: 0>
    Postdecrement: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.Postdecrement: 13>
    Postincrement: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.Postincrement: 12>
    Predecrement: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.Predecrement: 11>
    Preincrement: typing.ClassVar[UnaryOperator]  # value = <UnaryOperator.Preincrement: 10>
class UnbasedUnsizedIntegerLiteral(Expression):
    @property
    def literalValue(self) -> ...:
        ...
    @property
    def value(self) -> ...:
        ...
class UnboundedLiteral(Expression):
    pass
class UnboundedType(Type):
    pass
class UnconnectedDrive(enum.Enum):
    None_: typing.ClassVar[UnconnectedDrive]  # value = <UnconnectedDrive.None_: 0>
    Pull0: typing.ClassVar[UnconnectedDrive]  # value = <UnconnectedDrive.Pull0: 1>
    Pull1: typing.ClassVar[UnconnectedDrive]  # value = <UnconnectedDrive.Pull1: 2>
class UninstantiatedDefSymbol(Symbol):
    @property
    def definitionName(self) -> str:
        ...
    @property
    def isChecker(self) -> bool:
        ...
    @property
    def paramExpressions(self) -> span[Expression]:
        ...
    @property
    def portConnections(self) -> span[AssertionExpr]:
        ...
    @property
    def portNames(self) -> span[str]:
        ...
class UniquePriorityCheck(enum.Enum):
    None_: typing.ClassVar[UniquePriorityCheck]  # value = <UniquePriorityCheck.None_: 0>
    Priority: typing.ClassVar[UniquePriorityCheck]  # value = <UniquePriorityCheck.Priority: 3>
    Unique: typing.ClassVar[UniquePriorityCheck]  # value = <UniquePriorityCheck.Unique: 1>
    Unique0: typing.ClassVar[UniquePriorityCheck]  # value = <UniquePriorityCheck.Unique0: 2>
class UniquenessConstraint(Constraint):
    @property
    def items(self) -> span[...]:
        ...
class UnpackedStructType(Type, Scope):
    @property
    def systemId(self) -> int:
        ...
class UnpackedUnionType(Type, Scope):
    @property
    def isTagged(self) -> bool:
        ...
    @property
    def systemId(self) -> int:
        ...
class UntypedType(Type):
    pass
class ValueExpressionBase(Expression):
    @property
    def symbol(self) -> ...:
        ...
class ValuePath:
    @staticmethod
    def visitPaths(expr: ..., evalContext: EvalContext, callback: collections.abc.Callable, skipSelectors: bool = False) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, expr: ..., evalContext: EvalContext) -> None:
        ...
    def __iter__(self) -> collections.abc.Iterator[...]:
        ...
    def expandIndirectRefs(self, alloc: ..., evalContext: EvalContext, callback: collections.abc.Callable) -> None:
        ...
    def overlaps(self, other: ValuePath) -> bool:
        ...
    def toString(self, evalContext: EvalContext) -> str:
        ...
    @property
    def empty(self) -> bool:
        ...
    @property
    def fullExpr(self) -> ...:
        ...
    @property
    def isFullyStatic(self) -> bool:
        ...
    @property
    def lsp(self) -> ...:
        ...
    @property
    def lspBounds(self) -> tuple[int, int]:
        ...
    @property
    def rootExpr(self) -> ...:
        ...
    @property
    def rootSymbol(self) -> ...:
        ...
class ValueRangeExpression(Expression):
    @property
    def left(self) -> Expression:
        ...
    @property
    def right(self) -> Expression:
        ...
class ValueRangeKind(enum.Enum):
    AbsoluteTolerance: typing.ClassVar[ValueRangeKind]  # value = <ValueRangeKind.AbsoluteTolerance: 1>
    RelativeTolerance: typing.ClassVar[ValueRangeKind]  # value = <ValueRangeKind.RelativeTolerance: 2>
    Simple: typing.ClassVar[ValueRangeKind]  # value = <ValueRangeKind.Simple: 0>
class ValueSymbol(Symbol):
    @property
    def initializer(self) -> Expression:
        ...
    @property
    def type(self) -> ...:
        ...
class VariableDeclStatement(Statement):
    @property
    def symbol(self) -> ...:
        ...
class VariableFlags(enum.Flag):
    CheckerFreeVariable: typing.ClassVar[VariableFlags]  # value = <VariableFlags.CheckerFreeVariable: 16>
    CompilerGenerated: typing.ClassVar[VariableFlags]  # value = <VariableFlags.CompilerGenerated: 2>
    Const: typing.ClassVar[VariableFlags]  # value = <VariableFlags.Const: 1>
    CoverageSampleFormal: typing.ClassVar[VariableFlags]  # value = <VariableFlags.CoverageSampleFormal: 8>
    ImmutableCoverageOption: typing.ClassVar[VariableFlags]  # value = <VariableFlags.ImmutableCoverageOption: 4>
    RefStatic: typing.ClassVar[VariableFlags]  # value = <VariableFlags.RefStatic: 32>
class VariableLifetime(enum.Enum):
    Automatic: typing.ClassVar[VariableLifetime]  # value = <VariableLifetime.Automatic: 0>
    Static: typing.ClassVar[VariableLifetime]  # value = <VariableLifetime.Static: 1>
class VariablePattern(Pattern):
    @property
    def variable(self) -> ...:
        ...
class VariableSymbol(ValueSymbol):
    @property
    def flags(self) -> VariableFlags:
        ...
    @property
    def lifetime(self) -> VariableLifetime:
        ...
class VirtualInterfaceType(Type):
    @property
    def iface(self) -> InstanceSymbol:
        ...
    @property
    def modport(self) -> ModportSymbol:
        ...
class Visibility(enum.Enum):
    Local: typing.ClassVar[Visibility]  # value = <Visibility.Local: 2>
    Protected: typing.ClassVar[Visibility]  # value = <Visibility.Protected: 1>
    Public: typing.ClassVar[Visibility]  # value = <Visibility.Public: 0>
class VisitAction(enum.Enum):
    Advance: typing.ClassVar[VisitAction]  # value = <VisitAction.Advance: 0>
    Interrupt: typing.ClassVar[VisitAction]  # value = <VisitAction.Interrupt: 2>
    Skip: typing.ClassVar[VisitAction]  # value = <VisitAction.Skip: 1>
class VoidType(Type):
    pass
class WaitForkStatement(Statement):
    pass
class WaitOrderStatement(Statement):
    @property
    def events(self) -> span[Expression]:
        ...
    @property
    def ifFalse(self) -> Statement:
        ...
    @property
    def ifTrue(self) -> Statement:
        ...
class WaitStatement(Statement):
    @property
    def cond(self) -> Expression:
        ...
    @property
    def stmt(self) -> Statement:
        ...
class WhileLoopStatement(Statement):
    @property
    def body(self) -> Statement:
        ...
    @property
    def cond(self) -> Expression:
        ...
class WildcardImportSymbol(Symbol):
    @property
    def isFromExport(self) -> bool:
        ...
    @property
    def package(self) -> PackageSymbol:
        ...
    @property
    def packageName(self) -> str:
        ...
class WildcardPattern(Pattern):
    pass
