"""
Lexer, parser, preprocessor types
"""
from __future__ import annotations
import collections.abc
import enum
import pathlib
import pyslang
import pyslang.syntax
import typing
__all__: list[str] = ['KnownSystemName', 'Lexer', 'LexerOptions', 'ParserOptions', 'PreprocessorOptions', 'Token', 'TokenKind', 'Trivia', 'TriviaKind']
class KnownSystemName(enum.Enum):
    Unknown: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.Unknown: 0>
    and: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.and: 240>
    atobin: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.atobin: 278>
    atohex: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.atohex: 276>
    atoi: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.atoi: 275>
    atooct: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.atooct: 277>
    atoreal: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.atoreal: 279>
    bintoa: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.bintoa: 283>
    compare: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.compare: 273>
    constraint_mode: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.constraint_mode: 286>
    delete: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.delete: 233>
    exists: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.exists: 234>
    find: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.find: 244>
    find_first: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.find_first: 246>
    find_first_index: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.find_first_index: 247>
    find_index: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.find_index: 245>
    find_last: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.find_last: 248>
    find_last_index: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.find_last_index: 249>
    first: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.first: 258>
    getc: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.getc: 269>
    hextoa: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.hextoa: 281>
    icompare: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.icompare: 274>
    index: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.index: 236>
    insert: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.insert: 235>
    itoa: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.itoa: 280>
    last: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.last: 259>
    len: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.len: 267>
    map: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.map: 237>
    matched: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.matched: 63>
    max: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.max: 251>
    min: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.min: 250>
    name: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.name: 266>
    next: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.next: 260>
    num: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.num: 257>
    octtoa: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.octtoa: 282>
    or: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.or: 239>
    pop_back: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.pop_back: 263>
    pop_front: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.pop_front: 262>
    prev: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.prev: 261>
    product: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.product: 243>
    push_back: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.push_back: 265>
    push_front: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.push_front: 264>
    putc: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.putc: 268>
    rand_mode: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.rand_mode: 285>
    randomize: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.randomize: 61>
    realtoa: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.realtoa: 284>
    reverse: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.reverse: 232>
    rsort: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.rsort: 255>
    shuffle: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.shuffle: 256>
    size: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.size: 238>
    sort: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.sort: 254>
    substr: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.substr: 270>
    sum: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.sum: 242>
    tolower: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.tolower: 272>
    toupper: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.toupper: 271>
    triggered: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.triggered: 62>
    unique: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.unique: 252>
    unique_index: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.unique_index: 253>
    xor: typing.ClassVar[KnownSystemName]  # value = <KnownSystemName.xor: 241>
    @property
    def name(self):
        """
        The name of the Enum member.
        """
class Lexer:
    def __init__(self, buffer: pyslang.SourceBuffer, alloc: pyslang.BumpAllocator, diagnostics: pyslang.Diagnostics, sourceManager: pyslang.SourceManager, options: LexerOptions = ...) -> None:
        ...
    def isNextTokenOnSameLine(self) -> bool:
        ...
    def lex(self) -> Token:
        ...
    @property
    def bufferId(self) -> pyslang.BufferID:
        ...
    @property
    def library(self) -> pyslang.SourceLibrary:
        ...
class LexerOptions:
    enableLegacyProtect: bool
    languageVersion: pyslang.LanguageVersion
    def __init__(self) -> None:
        ...
    @property
    def commentHandlers(self) -> dict[str, dict[str, pyslang.syntax.CommentHandler]]:
        ...
    @commentHandlers.setter
    def commentHandlers(self, arg0: collections.abc.Mapping[str, collections.abc.Mapping[str, pyslang.syntax.CommentHandler]]) -> None:
        ...
    @property
    def maxErrors(self) -> int:
        ...
    @maxErrors.setter
    def maxErrors(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
class ParserOptions:
    languageVersion: pyslang.LanguageVersion
    def __init__(self) -> None:
        ...
    @property
    def maxRecursionDepth(self) -> int:
        ...
    @maxRecursionDepth.setter
    def maxRecursionDepth(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
class PreprocessorOptions:
    languageVersion: pyslang.LanguageVersion
    predefineSource: str
    def __init__(self) -> None:
        ...
    @property
    def additionalIncludePaths(self) -> list[pathlib.Path]:
        ...
    @additionalIncludePaths.setter
    def additionalIncludePaths(self, arg0: collections.abc.Sequence[os.PathLike | str | bytes]) -> None:
        ...
    @property
    def ignoreDirectives(self) -> set[str]:
        ...
    @ignoreDirectives.setter
    def ignoreDirectives(self, arg0: collections.abc.Set[str]) -> None:
        ...
    @property
    def keywordMapping(self) -> list[tuple[str, ...]]:
        ...
    @keywordMapping.setter
    def keywordMapping(self, arg0: collections.abc.Sequence[tuple[str, ...]]) -> None:
        ...
    @property
    def maxIncludeDepth(self) -> int:
        ...
    @maxIncludeDepth.setter
    def maxIncludeDepth(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def predefines(self) -> list[str]:
        ...
    @predefines.setter
    def predefines(self, arg0: collections.abc.Sequence[str]) -> None:
        ...
    @property
    def undefines(self) -> list[str]:
        ...
    @undefines.setter
    def undefines(self, arg0: collections.abc.Sequence[str]) -> None:
        ...
class Token:
    __hash__: typing.ClassVar[None] = None
    def __bool__(self) -> bool:
        ...
    def __eq__(self, arg0: Token) -> bool:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, alloc: pyslang.BumpAllocator, kind: TokenKind, trivia: span[Trivia], rawText: str, location: pyslang.SourceLocation) -> None:
        ...
    @typing.overload
    def __init__(self, alloc: pyslang.BumpAllocator, kind: TokenKind, trivia: span[Trivia], rawText: str, location: pyslang.SourceLocation, strText: str) -> None:
        ...
    @typing.overload
    def __init__(self, alloc: pyslang.BumpAllocator, kind: TokenKind, trivia: span[Trivia], rawText: str, location: pyslang.SourceLocation, directive: pyslang.syntax.SyntaxKind) -> None:
        ...
    @typing.overload
    def __init__(self, alloc: pyslang.BumpAllocator, kind: TokenKind, trivia: span[Trivia], rawText: str, location: pyslang.SourceLocation, bit: pyslang.logic_t) -> None:
        ...
    @typing.overload
    def __init__(self, alloc: pyslang.BumpAllocator, kind: TokenKind, trivia: span[Trivia], rawText: str, location: pyslang.SourceLocation, value: pyslang.SVInt) -> None:
        ...
    @typing.overload
    def __init__(self, alloc: pyslang.BumpAllocator, kind: TokenKind, trivia: span[Trivia], rawText: str, location: pyslang.SourceLocation, value: typing.SupportsFloat | typing.SupportsIndex, outOfRange: bool, timeUnit: pyslang.TimeUnit | None) -> None:
        ...
    @typing.overload
    def __init__(self, alloc: pyslang.BumpAllocator, kind: TokenKind, trivia: span[Trivia], rawText: str, location: pyslang.SourceLocation, base: pyslang.LiteralBase, isSigned: bool) -> None:
        ...
    def __ne__(self, arg0: Token) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def isMissing(self) -> bool:
        ...
    @property
    def isOnSameLine(self) -> bool:
        ...
    @property
    def kind(self) -> TokenKind:
        ...
    @property
    def location(self) -> pyslang.SourceLocation:
        ...
    @property
    def range(self) -> pyslang.SourceRange:
        ...
    @property
    def rawText(self) -> str:
        ...
    @property
    def trivia(self) -> list[Trivia]:
        ...
    @property
    def value(self) -> typing.Any:
        ...
    @property
    def valueText(self) -> str:
        ...
class TokenKind(enum.Enum):
    AcceptOnKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AcceptOnKeyword: 93>
    AliasKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AliasKeyword: 94>
    AlwaysCombKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AlwaysCombKeyword: 96>
    AlwaysFFKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AlwaysFFKeyword: 97>
    AlwaysKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AlwaysKeyword: 95>
    AlwaysLatchKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AlwaysLatchKeyword: 98>
    And: typing.ClassVar[TokenKind]  # value = <TokenKind.And: 89>
    AndEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.AndEqual: 61>
    AndKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AndKeyword: 99>
    Apostrophe: typing.ClassVar[TokenKind]  # value = <TokenKind.Apostrophe: 11>
    ApostropheOpenBrace: typing.ClassVar[TokenKind]  # value = <TokenKind.ApostropheOpenBrace: 12>
    AssertKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AssertKeyword: 100>
    AssignKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AssignKeyword: 101>
    AssumeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AssumeKeyword: 102>
    At: typing.ClassVar[TokenKind]  # value = <TokenKind.At: 87>
    AutomaticKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.AutomaticKeyword: 103>
    BeforeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.BeforeKeyword: 104>
    BeginKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.BeginKeyword: 105>
    BindKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.BindKeyword: 106>
    BinsKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.BinsKeyword: 107>
    BinsOfKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.BinsOfKeyword: 108>
    BitKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.BitKeyword: 109>
    BreakKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.BreakKeyword: 110>
    BufIf0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.BufIf0Keyword: 112>
    BufIf1Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.BufIf1Keyword: 113>
    BufKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.BufKeyword: 111>
    ByteKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ByteKeyword: 114>
    CHandleKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CHandleKeyword: 119>
    CaseKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CaseKeyword: 115>
    CaseXKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CaseXKeyword: 116>
    CaseZKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CaseZKeyword: 117>
    CellKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CellKeyword: 118>
    CheckerKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CheckerKeyword: 120>
    ClassKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ClassKeyword: 121>
    ClockingKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ClockingKeyword: 122>
    CloseBrace: typing.ClassVar[TokenKind]  # value = <TokenKind.CloseBrace: 14>
    CloseBracket: typing.ClassVar[TokenKind]  # value = <TokenKind.CloseBracket: 16>
    CloseParenthesis: typing.ClassVar[TokenKind]  # value = <TokenKind.CloseParenthesis: 18>
    CmosKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CmosKeyword: 123>
    Colon: typing.ClassVar[TokenKind]  # value = <TokenKind.Colon: 20>
    ColonEquals: typing.ClassVar[TokenKind]  # value = <TokenKind.ColonEquals: 21>
    ColonSlash: typing.ClassVar[TokenKind]  # value = <TokenKind.ColonSlash: 22>
    Comma: typing.ClassVar[TokenKind]  # value = <TokenKind.Comma: 24>
    ConfigKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ConfigKeyword: 124>
    ConstKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ConstKeyword: 125>
    ConstraintKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ConstraintKeyword: 126>
    ContextKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ContextKeyword: 127>
    ContinueKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ContinueKeyword: 128>
    CoverGroupKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CoverGroupKeyword: 130>
    CoverKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CoverKeyword: 129>
    CoverPointKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CoverPointKeyword: 131>
    CrossKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.CrossKeyword: 132>
    DeassignKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.DeassignKeyword: 133>
    DefParamKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.DefParamKeyword: 135>
    DefaultKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.DefaultKeyword: 134>
    DesignKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.DesignKeyword: 136>
    Directive: typing.ClassVar[TokenKind]  # value = <TokenKind.Directive: 343>
    DisableKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.DisableKeyword: 137>
    DistKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.DistKeyword: 138>
    DoKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.DoKeyword: 139>
    Dollar: typing.ClassVar[TokenKind]  # value = <TokenKind.Dollar: 44>
    Dot: typing.ClassVar[TokenKind]  # value = <TokenKind.Dot: 25>
    DoubleAnd: typing.ClassVar[TokenKind]  # value = <TokenKind.DoubleAnd: 90>
    DoubleAt: typing.ClassVar[TokenKind]  # value = <TokenKind.DoubleAt: 88>
    DoubleColon: typing.ClassVar[TokenKind]  # value = <TokenKind.DoubleColon: 23>
    DoubleEquals: typing.ClassVar[TokenKind]  # value = <TokenKind.DoubleEquals: 53>
    DoubleEqualsQuestion: typing.ClassVar[TokenKind]  # value = <TokenKind.DoubleEqualsQuestion: 54>
    DoubleHash: typing.ClassVar[TokenKind]  # value = <TokenKind.DoubleHash: 47>
    DoubleMinus: typing.ClassVar[TokenKind]  # value = <TokenKind.DoubleMinus: 36>
    DoubleOr: typing.ClassVar[TokenKind]  # value = <TokenKind.DoubleOr: 84>
    DoublePlus: typing.ClassVar[TokenKind]  # value = <TokenKind.DoublePlus: 31>
    DoubleStar: typing.ClassVar[TokenKind]  # value = <TokenKind.DoubleStar: 28>
    EdgeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EdgeKeyword: 140>
    ElseKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ElseKeyword: 141>
    EmptyMacroArgument: typing.ClassVar[TokenKind]  # value = <TokenKind.EmptyMacroArgument: 350>
    EndCaseKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndCaseKeyword: 143>
    EndCheckerKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndCheckerKeyword: 144>
    EndClassKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndClassKeyword: 145>
    EndClockingKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndClockingKeyword: 146>
    EndConfigKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndConfigKeyword: 147>
    EndFunctionKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndFunctionKeyword: 148>
    EndGenerateKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndGenerateKeyword: 149>
    EndGroupKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndGroupKeyword: 150>
    EndInterfaceKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndInterfaceKeyword: 151>
    EndKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndKeyword: 142>
    EndModuleKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndModuleKeyword: 152>
    EndOfFile: typing.ClassVar[TokenKind]  # value = <TokenKind.EndOfFile: 1>
    EndPackageKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndPackageKeyword: 153>
    EndPrimitiveKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndPrimitiveKeyword: 154>
    EndProgramKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndProgramKeyword: 155>
    EndPropertyKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndPropertyKeyword: 156>
    EndSequenceKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndSequenceKeyword: 158>
    EndSpecifyKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndSpecifyKeyword: 157>
    EndTableKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndTableKeyword: 159>
    EndTaskKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EndTaskKeyword: 160>
    EnumKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EnumKeyword: 161>
    Equals: typing.ClassVar[TokenKind]  # value = <TokenKind.Equals: 52>
    EqualsArrow: typing.ClassVar[TokenKind]  # value = <TokenKind.EqualsArrow: 56>
    EventKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EventKeyword: 162>
    EventuallyKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.EventuallyKeyword: 163>
    Exclamation: typing.ClassVar[TokenKind]  # value = <TokenKind.Exclamation: 73>
    ExclamationDoubleEquals: typing.ClassVar[TokenKind]  # value = <TokenKind.ExclamationDoubleEquals: 76>
    ExclamationEquals: typing.ClassVar[TokenKind]  # value = <TokenKind.ExclamationEquals: 74>
    ExclamationEqualsQuestion: typing.ClassVar[TokenKind]  # value = <TokenKind.ExclamationEqualsQuestion: 75>
    ExpectKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ExpectKeyword: 164>
    ExportKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ExportKeyword: 165>
    ExtendsKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ExtendsKeyword: 166>
    ExternKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ExternKeyword: 167>
    FinalKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.FinalKeyword: 168>
    FirstMatchKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.FirstMatchKeyword: 169>
    ForKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ForKeyword: 170>
    ForceKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ForceKeyword: 171>
    ForeachKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ForeachKeyword: 172>
    ForeverKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ForeverKeyword: 173>
    ForkJoinKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ForkJoinKeyword: 175>
    ForkKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ForkKeyword: 174>
    FunctionKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.FunctionKeyword: 176>
    GenVarKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.GenVarKeyword: 178>
    GenerateKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.GenerateKeyword: 177>
    GlobalKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.GlobalKeyword: 179>
    GreaterThan: typing.ClassVar[TokenKind]  # value = <TokenKind.GreaterThan: 81>
    GreaterThanEquals: typing.ClassVar[TokenKind]  # value = <TokenKind.GreaterThanEquals: 82>
    Hash: typing.ClassVar[TokenKind]  # value = <TokenKind.Hash: 46>
    HashEqualsHash: typing.ClassVar[TokenKind]  # value = <TokenKind.HashEqualsHash: 49>
    HashMinusHash: typing.ClassVar[TokenKind]  # value = <TokenKind.HashMinusHash: 48>
    HighZ0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.HighZ0Keyword: 180>
    HighZ1Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.HighZ1Keyword: 181>
    Identifier: typing.ClassVar[TokenKind]  # value = <TokenKind.Identifier: 2>
    IfKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.IfKeyword: 182>
    IfNoneKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.IfNoneKeyword: 184>
    IffKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.IffKeyword: 183>
    IgnoreBinsKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.IgnoreBinsKeyword: 185>
    IllegalBinsKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.IllegalBinsKeyword: 186>
    ImplementsKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ImplementsKeyword: 187>
    ImpliesKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ImpliesKeyword: 188>
    ImportKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ImportKeyword: 189>
    InOutKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.InOutKeyword: 193>
    IncDirKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.IncDirKeyword: 190>
    IncludeFileName: typing.ClassVar[TokenKind]  # value = <TokenKind.IncludeFileName: 344>
    IncludeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.IncludeKeyword: 191>
    InitialKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.InitialKeyword: 192>
    InputKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.InputKeyword: 194>
    InsideKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.InsideKeyword: 195>
    InstanceKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.InstanceKeyword: 196>
    IntKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.IntKeyword: 197>
    IntegerBase: typing.ClassVar[TokenKind]  # value = <TokenKind.IntegerBase: 6>
    IntegerKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.IntegerKeyword: 198>
    IntegerLiteral: typing.ClassVar[TokenKind]  # value = <TokenKind.IntegerLiteral: 5>
    InterconnectKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.InterconnectKeyword: 199>
    InterfaceKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.InterfaceKeyword: 200>
    IntersectKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.IntersectKeyword: 201>
    JoinAnyKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.JoinAnyKeyword: 203>
    JoinKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.JoinKeyword: 202>
    JoinNoneKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.JoinNoneKeyword: 204>
    LargeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.LargeKeyword: 205>
    LeftShift: typing.ClassVar[TokenKind]  # value = <TokenKind.LeftShift: 69>
    LeftShiftEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.LeftShiftEqual: 65>
    LessThan: typing.ClassVar[TokenKind]  # value = <TokenKind.LessThan: 78>
    LessThanEquals: typing.ClassVar[TokenKind]  # value = <TokenKind.LessThanEquals: 79>
    LessThanMinusArrow: typing.ClassVar[TokenKind]  # value = <TokenKind.LessThanMinusArrow: 80>
    LetKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.LetKeyword: 206>
    LibListKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.LibListKeyword: 207>
    LibraryKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.LibraryKeyword: 208>
    LineContinuation: typing.ClassVar[TokenKind]  # value = <TokenKind.LineContinuation: 351>
    LocalKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.LocalKeyword: 209>
    LocalParamKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.LocalParamKeyword: 210>
    LogicKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.LogicKeyword: 211>
    LongIntKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.LongIntKeyword: 212>
    MacroEscapedQuote: typing.ClassVar[TokenKind]  # value = <TokenKind.MacroEscapedQuote: 348>
    MacroPaste: typing.ClassVar[TokenKind]  # value = <TokenKind.MacroPaste: 349>
    MacroQuote: typing.ClassVar[TokenKind]  # value = <TokenKind.MacroQuote: 346>
    MacroTripleQuote: typing.ClassVar[TokenKind]  # value = <TokenKind.MacroTripleQuote: 347>
    MacroUsage: typing.ClassVar[TokenKind]  # value = <TokenKind.MacroUsage: 345>
    MacromoduleKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.MacromoduleKeyword: 213>
    MatchesKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.MatchesKeyword: 214>
    MediumKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.MediumKeyword: 215>
    Minus: typing.ClassVar[TokenKind]  # value = <TokenKind.Minus: 35>
    MinusArrow: typing.ClassVar[TokenKind]  # value = <TokenKind.MinusArrow: 38>
    MinusColon: typing.ClassVar[TokenKind]  # value = <TokenKind.MinusColon: 37>
    MinusDoubleArrow: typing.ClassVar[TokenKind]  # value = <TokenKind.MinusDoubleArrow: 39>
    MinusEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.MinusEqual: 58>
    ModPortKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ModPortKeyword: 216>
    ModuleKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ModuleKeyword: 217>
    NandKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NandKeyword: 218>
    NegEdgeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NegEdgeKeyword: 219>
    NetTypeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NetTypeKeyword: 220>
    NewKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NewKeyword: 221>
    NextTimeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NextTimeKeyword: 222>
    NmosKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NmosKeyword: 223>
    NoShowCancelledKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NoShowCancelledKeyword: 225>
    NorKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NorKeyword: 224>
    NotIf0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NotIf0Keyword: 227>
    NotIf1Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NotIf1Keyword: 228>
    NotKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NotKeyword: 226>
    NullKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.NullKeyword: 229>
    OneStep: typing.ClassVar[TokenKind]  # value = <TokenKind.OneStep: 92>
    OpenBrace: typing.ClassVar[TokenKind]  # value = <TokenKind.OpenBrace: 13>
    OpenBracket: typing.ClassVar[TokenKind]  # value = <TokenKind.OpenBracket: 15>
    OpenParenthesis: typing.ClassVar[TokenKind]  # value = <TokenKind.OpenParenthesis: 17>
    Or: typing.ClassVar[TokenKind]  # value = <TokenKind.Or: 83>
    OrEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.OrEqual: 62>
    OrEqualsArrow: typing.ClassVar[TokenKind]  # value = <TokenKind.OrEqualsArrow: 86>
    OrKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.OrKeyword: 230>
    OrMinusArrow: typing.ClassVar[TokenKind]  # value = <TokenKind.OrMinusArrow: 85>
    OutputKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.OutputKeyword: 231>
    PackageKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PackageKeyword: 232>
    PackedKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PackedKeyword: 233>
    ParameterKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ParameterKeyword: 234>
    Percent: typing.ClassVar[TokenKind]  # value = <TokenKind.Percent: 77>
    PercentEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.PercentEqual: 63>
    Placeholder: typing.ClassVar[TokenKind]  # value = <TokenKind.Placeholder: 10>
    Plus: typing.ClassVar[TokenKind]  # value = <TokenKind.Plus: 30>
    PlusColon: typing.ClassVar[TokenKind]  # value = <TokenKind.PlusColon: 32>
    PlusDivMinus: typing.ClassVar[TokenKind]  # value = <TokenKind.PlusDivMinus: 33>
    PlusEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.PlusEqual: 57>
    PlusModMinus: typing.ClassVar[TokenKind]  # value = <TokenKind.PlusModMinus: 34>
    PmosKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PmosKeyword: 235>
    PosEdgeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PosEdgeKeyword: 236>
    PrimitiveKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PrimitiveKeyword: 237>
    PriorityKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PriorityKeyword: 238>
    ProgramKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ProgramKeyword: 239>
    PropertyKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PropertyKeyword: 240>
    ProtectedKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ProtectedKeyword: 241>
    Pull0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Pull0Keyword: 242>
    Pull1Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Pull1Keyword: 243>
    PullDownKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PullDownKeyword: 244>
    PullUpKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PullUpKeyword: 245>
    PulseStyleOnDetectKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PulseStyleOnDetectKeyword: 246>
    PulseStyleOnEventKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PulseStyleOnEventKeyword: 247>
    PureKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.PureKeyword: 248>
    Question: typing.ClassVar[TokenKind]  # value = <TokenKind.Question: 45>
    RandCKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RandCKeyword: 250>
    RandCaseKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RandCaseKeyword: 251>
    RandKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RandKeyword: 249>
    RandSequenceKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RandSequenceKeyword: 252>
    RcmosKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RcmosKeyword: 253>
    RealKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RealKeyword: 254>
    RealLiteral: typing.ClassVar[TokenKind]  # value = <TokenKind.RealLiteral: 8>
    RealTimeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RealTimeKeyword: 255>
    RefKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RefKeyword: 256>
    RegKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RegKeyword: 257>
    RejectOnKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RejectOnKeyword: 258>
    ReleaseKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ReleaseKeyword: 259>
    RepeatKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RepeatKeyword: 260>
    RestrictKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RestrictKeyword: 261>
    ReturnKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ReturnKeyword: 262>
    RightShift: typing.ClassVar[TokenKind]  # value = <TokenKind.RightShift: 70>
    RightShiftEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.RightShiftEqual: 67>
    RnmosKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RnmosKeyword: 263>
    RootSystemName: typing.ClassVar[TokenKind]  # value = <TokenKind.RootSystemName: 342>
    RpmosKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RpmosKeyword: 264>
    RtranIf0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RtranIf0Keyword: 266>
    RtranIf1Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RtranIf1Keyword: 267>
    RtranKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.RtranKeyword: 265>
    SAlwaysKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SAlwaysKeyword: 268>
    SEventuallyKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SEventuallyKeyword: 269>
    SNextTimeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SNextTimeKeyword: 270>
    SUntilKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SUntilKeyword: 271>
    SUntilWithKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SUntilWithKeyword: 272>
    ScalaredKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ScalaredKeyword: 273>
    Semicolon: typing.ClassVar[TokenKind]  # value = <TokenKind.Semicolon: 19>
    SequenceKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SequenceKeyword: 274>
    ShortIntKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ShortIntKeyword: 275>
    ShortRealKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ShortRealKeyword: 276>
    ShowCancelledKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ShowCancelledKeyword: 277>
    SignedKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SignedKeyword: 278>
    Slash: typing.ClassVar[TokenKind]  # value = <TokenKind.Slash: 26>
    SlashEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.SlashEqual: 59>
    SmallKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SmallKeyword: 279>
    SoftKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SoftKeyword: 280>
    SolveKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SolveKeyword: 281>
    SpecParamKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SpecParamKeyword: 283>
    SpecifyKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SpecifyKeyword: 282>
    Star: typing.ClassVar[TokenKind]  # value = <TokenKind.Star: 27>
    StarArrow: typing.ClassVar[TokenKind]  # value = <TokenKind.StarArrow: 29>
    StarEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.StarEqual: 60>
    StaticKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.StaticKeyword: 284>
    StringKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.StringKeyword: 285>
    StringLiteral: typing.ClassVar[TokenKind]  # value = <TokenKind.StringLiteral: 4>
    Strong0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Strong0Keyword: 287>
    Strong1Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Strong1Keyword: 288>
    StrongKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.StrongKeyword: 286>
    StructKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.StructKeyword: 289>
    SuperKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SuperKeyword: 290>
    Supply0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Supply0Keyword: 291>
    Supply1Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Supply1Keyword: 292>
    SyncAcceptOnKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SyncAcceptOnKeyword: 293>
    SyncRejectOnKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.SyncRejectOnKeyword: 294>
    SystemIdentifier: typing.ClassVar[TokenKind]  # value = <TokenKind.SystemIdentifier: 3>
    TableKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TableKeyword: 295>
    TaggedKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TaggedKeyword: 296>
    TaskKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TaskKeyword: 297>
    ThisKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ThisKeyword: 298>
    ThroughoutKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.ThroughoutKeyword: 299>
    Tilde: typing.ClassVar[TokenKind]  # value = <TokenKind.Tilde: 40>
    TildeAnd: typing.ClassVar[TokenKind]  # value = <TokenKind.TildeAnd: 41>
    TildeOr: typing.ClassVar[TokenKind]  # value = <TokenKind.TildeOr: 42>
    TildeXor: typing.ClassVar[TokenKind]  # value = <TokenKind.TildeXor: 43>
    TimeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TimeKeyword: 300>
    TimeLiteral: typing.ClassVar[TokenKind]  # value = <TokenKind.TimeLiteral: 9>
    TimePrecisionKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TimePrecisionKeyword: 301>
    TimeUnitKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TimeUnitKeyword: 302>
    TranIf0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TranIf0Keyword: 304>
    TranIf1Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TranIf1Keyword: 305>
    TranKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TranKeyword: 303>
    Tri0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Tri0Keyword: 307>
    Tri1Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Tri1Keyword: 308>
    TriAndKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TriAndKeyword: 309>
    TriKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TriKeyword: 306>
    TriOrKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TriOrKeyword: 310>
    TriRegKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TriRegKeyword: 311>
    TripleAnd: typing.ClassVar[TokenKind]  # value = <TokenKind.TripleAnd: 91>
    TripleEquals: typing.ClassVar[TokenKind]  # value = <TokenKind.TripleEquals: 55>
    TripleLeftShift: typing.ClassVar[TokenKind]  # value = <TokenKind.TripleLeftShift: 71>
    TripleLeftShiftEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.TripleLeftShiftEqual: 66>
    TripleRightShift: typing.ClassVar[TokenKind]  # value = <TokenKind.TripleRightShift: 72>
    TripleRightShiftEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.TripleRightShiftEqual: 68>
    TypeKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TypeKeyword: 312>
    TypedefKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.TypedefKeyword: 313>
    UWireKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.UWireKeyword: 322>
    UnbasedUnsizedLiteral: typing.ClassVar[TokenKind]  # value = <TokenKind.UnbasedUnsizedLiteral: 7>
    UnionKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.UnionKeyword: 314>
    Unique0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Unique0Keyword: 316>
    UniqueKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.UniqueKeyword: 315>
    UnitSystemName: typing.ClassVar[TokenKind]  # value = <TokenKind.UnitSystemName: 341>
    Unknown: typing.ClassVar[TokenKind]  # value = <TokenKind.Unknown: 0>
    UnsignedKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.UnsignedKeyword: 317>
    UntilKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.UntilKeyword: 318>
    UntilWithKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.UntilWithKeyword: 319>
    UntypedKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.UntypedKeyword: 320>
    UseKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.UseKeyword: 321>
    VarKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.VarKeyword: 323>
    VectoredKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.VectoredKeyword: 324>
    VirtualKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.VirtualKeyword: 325>
    VoidKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.VoidKeyword: 326>
    WAndKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.WAndKeyword: 329>
    WOrKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.WOrKeyword: 338>
    WaitKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.WaitKeyword: 327>
    WaitOrderKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.WaitOrderKeyword: 328>
    Weak0Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Weak0Keyword: 331>
    Weak1Keyword: typing.ClassVar[TokenKind]  # value = <TokenKind.Weak1Keyword: 332>
    WeakKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.WeakKeyword: 330>
    WhileKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.WhileKeyword: 333>
    WildcardKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.WildcardKeyword: 334>
    WireKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.WireKeyword: 335>
    WithKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.WithKeyword: 336>
    WithinKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.WithinKeyword: 337>
    XnorKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.XnorKeyword: 339>
    Xor: typing.ClassVar[TokenKind]  # value = <TokenKind.Xor: 50>
    XorEqual: typing.ClassVar[TokenKind]  # value = <TokenKind.XorEqual: 64>
    XorKeyword: typing.ClassVar[TokenKind]  # value = <TokenKind.XorKeyword: 340>
    XorTilde: typing.ClassVar[TokenKind]  # value = <TokenKind.XorTilde: 51>
class Trivia:
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, kind: TriviaKind, rawText: str) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def getExplicitLocation(self) -> pyslang.SourceLocation | None:
        ...
    def getRawText(self) -> str:
        ...
    def getSkippedTokens(self) -> span[...]:
        ...
    def syntax(self) -> ...:
        ...
    @property
    def kind(self) -> TriviaKind:
        ...
class TriviaKind(enum.Enum):
    BlockComment: typing.ClassVar[TriviaKind]  # value = <TriviaKind.BlockComment: 4>
    Directive: typing.ClassVar[TriviaKind]  # value = <TriviaKind.Directive: 8>
    DisabledText: typing.ClassVar[TriviaKind]  # value = <TriviaKind.DisabledText: 5>
    EndOfLine: typing.ClassVar[TriviaKind]  # value = <TriviaKind.EndOfLine: 2>
    LineComment: typing.ClassVar[TriviaKind]  # value = <TriviaKind.LineComment: 3>
    SkippedSyntax: typing.ClassVar[TriviaKind]  # value = <TriviaKind.SkippedSyntax: 7>
    SkippedTokens: typing.ClassVar[TriviaKind]  # value = <TriviaKind.SkippedTokens: 6>
    Unknown: typing.ClassVar[TriviaKind]  # value = <TriviaKind.Unknown: 0>
    Whitespace: typing.ClassVar[TriviaKind]  # value = <TriviaKind.Whitespace: 1>
