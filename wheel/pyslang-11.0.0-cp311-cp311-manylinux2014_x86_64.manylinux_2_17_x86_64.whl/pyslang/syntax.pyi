"""
Syntax tree nodes and utilities
"""
from __future__ import annotations
import collections.abc
import enum
import pyslang
import pyslang.parsing
import typing
__all__: list[str] = ['AcceptOnPropertyExprSyntax', 'ActionBlockSyntax', 'AnonymousProgramSyntax', 'AnsiPortListSyntax', 'AnsiUdpPortListSyntax', 'ArgumentListSyntax', 'ArgumentSyntax', 'ArrayOrRandomizeMethodExpressionSyntax', 'AssertionItemPortListSyntax', 'AssertionItemPortSyntax', 'AssignmentPatternExpressionSyntax', 'AssignmentPatternItemSyntax', 'AssignmentPatternSyntax', 'AttributeInstanceSyntax', 'AttributeSpecSyntax', 'BadExpressionSyntax', 'BeginKeywordsDirectiveSyntax', 'BinSelectWithFilterExprSyntax', 'BinaryBinsSelectExprSyntax', 'BinaryBlockEventExpressionSyntax', 'BinaryConditionalDirectiveExpressionSyntax', 'BinaryEventExpressionSyntax', 'BinaryExpressionSyntax', 'BinaryPropertyExprSyntax', 'BinarySequenceExprSyntax', 'BindDirectiveSyntax', 'BindTargetListSyntax', 'BinsSelectConditionExprSyntax', 'BinsSelectExpressionSyntax', 'BinsSelectionSyntax', 'BitSelectSyntax', 'BlockCoverageEventSyntax', 'BlockEventExpressionSyntax', 'BlockStatementSyntax', 'CSTJsonMode', 'CaseGenerateSyntax', 'CaseItemSyntax', 'CasePropertyExprSyntax', 'CaseStatementSyntax', 'CastExpressionSyntax', 'CellConfigRuleSyntax', 'ChargeStrengthSyntax', 'CheckerDataDeclarationSyntax', 'CheckerDeclarationSyntax', 'CheckerInstanceStatementSyntax', 'CheckerInstantiationSyntax', 'ClassDeclarationSyntax', 'ClassMethodDeclarationSyntax', 'ClassMethodPrototypeSyntax', 'ClassNameSyntax', 'ClassPropertyDeclarationSyntax', 'ClassSpecifierSyntax', 'ClockingDeclarationSyntax', 'ClockingDirectionSyntax', 'ClockingItemSyntax', 'ClockingPropertyExprSyntax', 'ClockingSequenceExprSyntax', 'ClockingSkewSyntax', 'ColonExpressionClauseSyntax', 'CommentHandler', 'CompilationUnitSyntax', 'ConcatenationExpressionSyntax', 'ConcurrentAssertionMemberSyntax', 'ConcurrentAssertionStatementSyntax', 'ConditionalBranchDirectiveSyntax', 'ConditionalConstraintSyntax', 'ConditionalDirectiveExpressionSyntax', 'ConditionalExpressionSyntax', 'ConditionalPathDeclarationSyntax', 'ConditionalPatternSyntax', 'ConditionalPredicateSyntax', 'ConditionalPropertyExprSyntax', 'ConditionalStatementSyntax', 'ConfigCellIdentifierSyntax', 'ConfigDeclarationSyntax', 'ConfigInstanceIdentifierSyntax', 'ConfigLiblistSyntax', 'ConfigRuleClauseSyntax', 'ConfigRuleSyntax', 'ConfigUseClauseSyntax', 'ConstraintBlockSyntax', 'ConstraintDeclarationSyntax', 'ConstraintItemSyntax', 'ConstraintPrototypeSyntax', 'ContinuousAssignSyntax', 'CopyClassExpressionSyntax', 'CoverCrossSyntax', 'CoverageBinInitializerSyntax', 'CoverageBinsArraySizeSyntax', 'CoverageBinsSyntax', 'CoverageIffClauseSyntax', 'CoverageOptionSyntax', 'CovergroupDeclarationSyntax', 'CoverpointSyntax', 'DPIExportSyntax', 'DPIImportSyntax', 'DataDeclarationSyntax', 'DataTypeSyntax', 'DeclaratorSyntax', 'DefParamAssignmentSyntax', 'DefParamSyntax', 'DefaultCaseItemSyntax', 'DefaultClockingReferenceSyntax', 'DefaultConfigRuleSyntax', 'DefaultCoverageBinInitializerSyntax', 'DefaultDecayTimeDirectiveSyntax', 'DefaultDisableDeclarationSyntax', 'DefaultDistItemSyntax', 'DefaultExtendsClauseArgSyntax', 'DefaultFunctionPortSyntax', 'DefaultNetTypeDirectiveSyntax', 'DefaultPropertyCaseItemSyntax', 'DefaultRsCaseItemSyntax', 'DefaultSkewItemSyntax', 'DefaultTriregStrengthDirectiveSyntax', 'DeferredAssertionSyntax', 'DefineDirectiveSyntax', 'Delay3Syntax', 'DelaySyntax', 'DelayedSequenceElementSyntax', 'DelayedSequenceExprSyntax', 'DimensionSpecifierSyntax', 'DirectiveSyntax', 'DisableConstraintSyntax', 'DisableForkStatementSyntax', 'DisableIffSyntax', 'DisableStatementSyntax', 'DistConstraintListSyntax', 'DistItemBaseSyntax', 'DistItemSyntax', 'DistWeightSyntax', 'DividerClauseSyntax', 'DoWhileStatementSyntax', 'DotMemberClauseSyntax', 'DriveStrengthSyntax', 'EdgeControlSpecifierSyntax', 'EdgeDescriptorSyntax', 'EdgeSensitivePathSuffixSyntax', 'ElabSystemTaskSyntax', 'ElementSelectExpressionSyntax', 'ElementSelectSyntax', 'ElseClauseSyntax', 'ElseConstraintClauseSyntax', 'ElsePropertyClauseSyntax', 'EmptyArgumentSyntax', 'EmptyIdentifierNameSyntax', 'EmptyMemberSyntax', 'EmptyNonAnsiPortSyntax', 'EmptyPortConnectionSyntax', 'EmptyQueueExpressionSyntax', 'EmptyStatementSyntax', 'EmptyTimingCheckArgSyntax', 'EnumTypeSyntax', 'EqualsAssertionArgClauseSyntax', 'EqualsTypeClauseSyntax', 'EqualsValueClauseSyntax', 'EventControlSyntax', 'EventControlWithExpressionSyntax', 'EventExpressionSyntax', 'EventTriggerStatementSyntax', 'ExplicitAnsiPortSyntax', 'ExplicitNonAnsiPortSyntax', 'ExpressionConstraintSyntax', 'ExpressionCoverageBinInitializerSyntax', 'ExpressionOrDistSyntax', 'ExpressionPatternSyntax', 'ExpressionStatementSyntax', 'ExpressionSyntax', 'ExpressionTimingCheckArgSyntax', 'ExtendsClauseSyntax', 'ExternInterfaceMethodSyntax', 'ExternModuleDeclSyntax', 'ExternUdpDeclSyntax', 'FilePathSpecSyntax', 'FirstMatchSequenceExprSyntax', 'ForLoopStatementSyntax', 'ForVariableDeclarationSyntax', 'ForeachLoopListSyntax', 'ForeachLoopStatementSyntax', 'ForeverStatementSyntax', 'ForwardTypeRestrictionSyntax', 'ForwardTypedefDeclarationSyntax', 'FunctionDeclarationSyntax', 'FunctionPortBaseSyntax', 'FunctionPortListSyntax', 'FunctionPortSyntax', 'FunctionPrototypeSyntax', 'GenerateBlockSyntax', 'GenerateRegionSyntax', 'GenvarDeclarationSyntax', 'HierarchicalInstanceSyntax', 'HierarchyInstantiationSyntax', 'IdWithExprCoverageBinInitializerSyntax', 'IdentifierNameSyntax', 'IdentifierSelectNameSyntax', 'IfGenerateSyntax', 'IfNonePathDeclarationSyntax', 'IffEventClauseSyntax', 'ImmediateAssertionMemberSyntax', 'ImmediateAssertionStatementSyntax', 'ImplementsClauseSyntax', 'ImplicationConstraintSyntax', 'ImplicitAnsiPortSyntax', 'ImplicitEventControlSyntax', 'ImplicitNonAnsiPortSyntax', 'ImplicitTypeSyntax', 'IncludeDirectiveSyntax', 'IncludeMetadata', 'InsideExpressionSyntax', 'InstanceConfigRuleSyntax', 'InstanceNameSyntax', 'IntegerTypeSyntax', 'IntegerVectorExpressionSyntax', 'InterfacePortHeaderSyntax', 'IntersectClauseSyntax', 'InvocationExpressionSyntax', 'JumpStatementSyntax', 'KeywordNameSyntax', 'KeywordTypeSyntax', 'LetDeclarationSyntax', 'LibraryDeclarationSyntax', 'LibraryIncDirClauseSyntax', 'LibraryIncludeStatementSyntax', 'LibraryMapSyntax', 'LineDirectiveSyntax', 'LiteralExpressionSyntax', 'LocalVariableDeclarationSyntax', 'LoopConstraintSyntax', 'LoopGenerateSyntax', 'LoopStatementSyntax', 'MacroActualArgumentListSyntax', 'MacroActualArgumentSyntax', 'MacroArgumentDefaultSyntax', 'MacroFormalArgumentListSyntax', 'MacroFormalArgumentSyntax', 'MacroUsageSyntax', 'MatchesClauseSyntax', 'MemberAccessExpressionSyntax', 'MemberSyntax', 'MinTypMaxExpressionSyntax', 'ModportClockingPortSyntax', 'ModportDeclarationSyntax', 'ModportExplicitPortSyntax', 'ModportItemSyntax', 'ModportNamedPortSyntax', 'ModportPortSyntax', 'ModportSimplePortListSyntax', 'ModportSubroutinePortListSyntax', 'ModportSubroutinePortSyntax', 'ModuleDeclarationSyntax', 'ModuleHeaderSyntax', 'MultipleConcatenationExpressionSyntax', 'NameSyntax', 'NameValuePragmaExpressionSyntax', 'NamedArgumentSyntax', 'NamedBlockClauseSyntax', 'NamedConditionalDirectiveExpressionSyntax', 'NamedLabelSyntax', 'NamedParamAssignmentSyntax', 'NamedPortConnectionSyntax', 'NamedStructurePatternMemberSyntax', 'NamedTypeSyntax', 'NetAliasSyntax', 'NetDeclarationSyntax', 'NetPortHeaderSyntax', 'NetStrengthSyntax', 'NetTypeDeclarationSyntax', 'NewArrayExpressionSyntax', 'NewClassExpressionSyntax', 'NonAnsiPortListSyntax', 'NonAnsiPortSyntax', 'NonAnsiUdpPortListSyntax', 'NumberPragmaExpressionSyntax', 'OneStepDelaySyntax', 'OrderedArgumentSyntax', 'OrderedParamAssignmentSyntax', 'OrderedPortConnectionSyntax', 'OrderedStructurePatternMemberSyntax', 'PackageExportAllDeclarationSyntax', 'PackageExportDeclarationSyntax', 'PackageImportDeclarationSyntax', 'PackageImportItemSyntax', 'ParamAssignmentSyntax', 'ParameterDeclarationBaseSyntax', 'ParameterDeclarationStatementSyntax', 'ParameterDeclarationSyntax', 'ParameterPortListSyntax', 'ParameterValueAssignmentSyntax', 'ParenExpressionListSyntax', 'ParenPragmaExpressionSyntax', 'ParenthesizedBinsSelectExprSyntax', 'ParenthesizedConditionalDirectiveExpressionSyntax', 'ParenthesizedEventExpressionSyntax', 'ParenthesizedExpressionSyntax', 'ParenthesizedPatternSyntax', 'ParenthesizedPropertyExprSyntax', 'ParenthesizedSequenceExprSyntax', 'PathDeclarationSyntax', 'PathDescriptionSyntax', 'PathSuffixSyntax', 'PatternCaseItemSyntax', 'PatternSyntax', 'PortConcatenationSyntax', 'PortConnectionSyntax', 'PortDeclarationSyntax', 'PortExpressionSyntax', 'PortHeaderSyntax', 'PortListSyntax', 'PortReferenceSyntax', 'PostfixUnaryExpressionSyntax', 'PragmaDirectiveSyntax', 'PragmaExpressionSyntax', 'PrefixUnaryExpressionSyntax', 'PrimaryBlockEventExpressionSyntax', 'PrimaryExpressionSyntax', 'PrimitiveInstantiationSyntax', 'ProceduralAssignStatementSyntax', 'ProceduralBlockSyntax', 'ProceduralDeassignStatementSyntax', 'ProductionSyntax', 'PropertyCaseItemSyntax', 'PropertyDeclarationSyntax', 'PropertyExprSyntax', 'PropertySpecSyntax', 'PullStrengthSyntax', 'PulseStyleDeclarationSyntax', 'QueueDimensionSpecifierSyntax', 'RandCaseItemSyntax', 'RandCaseStatementSyntax', 'RandJoinClauseSyntax', 'RandSequenceStatementSyntax', 'RangeCoverageBinInitializerSyntax', 'RangeDimensionSpecifierSyntax', 'RangeListSyntax', 'RangeSelectSyntax', 'RepeatedEventControlSyntax', 'ReplicatedAssignmentPatternSyntax', 'ReturnStatementSyntax', 'RsCaseItemSyntax', 'RsCaseSyntax', 'RsCodeBlockSyntax', 'RsElseClauseSyntax', 'RsIfElseSyntax', 'RsProdItemSyntax', 'RsProdSyntax', 'RsRepeatSyntax', 'RsRuleSyntax', 'RsWeightClauseSyntax', 'ScopedNameSyntax', 'SelectorSyntax', 'SequenceDeclarationSyntax', 'SequenceExprSyntax', 'SequenceMatchListSyntax', 'SequenceRepetitionSyntax', 'SignalEventExpressionSyntax', 'SignedCastExpressionSyntax', 'SimpleAssignmentPatternSyntax', 'SimpleBinsSelectExprSyntax', 'SimpleDirectiveSyntax', 'SimplePathSuffixSyntax', 'SimplePragmaExpressionSyntax', 'SimplePropertyExprSyntax', 'SimpleSequenceExprSyntax', 'SolveBeforeConstraintSyntax', 'SpecifyBlockSyntax', 'SpecparamDeclarationSyntax', 'SpecparamDeclaratorSyntax', 'StandardCaseItemSyntax', 'StandardPropertyCaseItemSyntax', 'StandardRsCaseItemSyntax', 'StatementSyntax', 'StreamExpressionSyntax', 'StreamExpressionWithRangeSyntax', 'StreamingConcatenationExpressionSyntax', 'StrongWeakPropertyExprSyntax', 'StructUnionMemberSyntax', 'StructUnionTypeSyntax', 'StructurePatternMemberSyntax', 'StructurePatternSyntax', 'StructuredAssignmentPatternSyntax', 'SuperNewDefaultedArgsExpressionSyntax', 'SyntaxFactory', 'SyntaxKind', 'SyntaxNode', 'SyntaxPrinter', 'SyntaxRewriter', 'SyntaxTree', 'SystemNameSyntax', 'SystemTimingCheckSyntax', 'TaggedPatternSyntax', 'TaggedUnionExpressionSyntax', 'TimeScaleDirectiveSyntax', 'TimeUnitsDeclarationSyntax', 'TimingCheckArgSyntax', 'TimingCheckEventArgSyntax', 'TimingCheckEventConditionSyntax', 'TimingControlExpressionSyntax', 'TimingControlStatementSyntax', 'TimingControlSyntax', 'TransListCoverageBinInitializerSyntax', 'TransRangeSyntax', 'TransRepeatRangeSyntax', 'TransSetSyntax', 'TypeAssignmentSyntax', 'TypeParameterDeclarationSyntax', 'TypeReferenceSyntax', 'TypedefDeclarationSyntax', 'UdpBodySyntax', 'UdpDeclarationSyntax', 'UdpEdgeFieldSyntax', 'UdpEntrySyntax', 'UdpFieldBaseSyntax', 'UdpInitialStmtSyntax', 'UdpInputPortDeclSyntax', 'UdpOutputPortDeclSyntax', 'UdpPortDeclSyntax', 'UdpPortListSyntax', 'UdpSimpleFieldSyntax', 'UnaryBinsSelectExprSyntax', 'UnaryConditionalDirectiveExpressionSyntax', 'UnaryPropertyExprSyntax', 'UnarySelectPropertyExprSyntax', 'UnconditionalBranchDirectiveSyntax', 'UnconnectedDriveDirectiveSyntax', 'UndefDirectiveSyntax', 'UniquenessConstraintSyntax', 'UserDefinedNetDeclarationSyntax', 'ValueRangeExpressionSyntax', 'VariableDimensionSyntax', 'VariablePatternSyntax', 'VariablePortHeaderSyntax', 'VirtualInterfaceTypeSyntax', 'VoidCastedCallStatementSyntax', 'WaitForkStatementSyntax', 'WaitOrderStatementSyntax', 'WaitStatementSyntax', 'WildcardDimensionSpecifierSyntax', 'WildcardPatternSyntax', 'WildcardPortConnectionSyntax', 'WildcardPortListSyntax', 'WildcardUdpPortListSyntax', 'WithClauseSyntax', 'WithFunctionClauseSyntax', 'WithFunctionSampleSyntax', 'clone', 'deepClone', 'rewrite']
class AcceptOnPropertyExprSyntax(PropertyExprSyntax):
    closeParen: pyslang.parsing.Token
    condition: ExpressionSyntax
    expr: PropertyExprSyntax
    keyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class ActionBlockSyntax(SyntaxNode):
    elseClause: ElseClauseSyntax
    statement: StatementSyntax
class AnonymousProgramSyntax(MemberSyntax):
    endkeyword: pyslang.parsing.Token
    keyword: pyslang.parsing.Token
    members: SyntaxList
    semi: pyslang.parsing.Token
class AnsiPortListSyntax(PortListSyntax):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    ports: SeparatedSyntaxList
class AnsiUdpPortListSyntax(UdpPortListSyntax):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    ports: SeparatedSyntaxList
    semi: pyslang.parsing.Token
class ArgumentListSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    parameters: SeparatedSyntaxList
class ArgumentSyntax(SyntaxNode):
    pass
class ArrayOrRandomizeMethodExpressionSyntax(ExpressionSyntax):
    args: ParenExpressionListSyntax
    constraints: ConstraintBlockSyntax
    method: ExpressionSyntax
    with_: pyslang.parsing.Token
class AssertionItemPortListSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    ports: SeparatedSyntaxList
class AssertionItemPortSyntax(SyntaxNode):
    attributes: SyntaxList
    defaultValue: EqualsAssertionArgClauseSyntax
    dimensions: SyntaxList
    direction: pyslang.parsing.Token
    local: pyslang.parsing.Token
    name: pyslang.parsing.Token
    type: DataTypeSyntax
class AssignmentPatternExpressionSyntax(PrimaryExpressionSyntax):
    pattern: AssignmentPatternSyntax
    type: DataTypeSyntax
class AssignmentPatternItemSyntax(SyntaxNode):
    colon: pyslang.parsing.Token
    expr: ExpressionSyntax
    key: ExpressionSyntax
class AssignmentPatternSyntax(SyntaxNode):
    pass
class AttributeInstanceSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    closeStar: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    openStar: pyslang.parsing.Token
    specs: SeparatedSyntaxList
class AttributeSpecSyntax(SyntaxNode):
    name: pyslang.parsing.Token
    value: EqualsValueClauseSyntax
class BadExpressionSyntax(ExpressionSyntax):
    expr: ExpressionSyntax
class BeginKeywordsDirectiveSyntax(DirectiveSyntax):
    versionSpecifier: pyslang.parsing.Token
class BinSelectWithFilterExprSyntax(BinsSelectExpressionSyntax):
    closeParen: pyslang.parsing.Token
    expr: BinsSelectExpressionSyntax
    filter: ExpressionSyntax
    matchesClause: MatchesClauseSyntax
    openParen: pyslang.parsing.Token
    with_: pyslang.parsing.Token
class BinaryBinsSelectExprSyntax(BinsSelectExpressionSyntax):
    left: BinsSelectExpressionSyntax
    op: pyslang.parsing.Token
    right: BinsSelectExpressionSyntax
class BinaryBlockEventExpressionSyntax(BlockEventExpressionSyntax):
    left: BlockEventExpressionSyntax
    orKeyword: pyslang.parsing.Token
    right: BlockEventExpressionSyntax
class BinaryConditionalDirectiveExpressionSyntax(ConditionalDirectiveExpressionSyntax):
    left: ConditionalDirectiveExpressionSyntax
    op: pyslang.parsing.Token
    right: ConditionalDirectiveExpressionSyntax
class BinaryEventExpressionSyntax(EventExpressionSyntax):
    left: EventExpressionSyntax
    operatorToken: pyslang.parsing.Token
    right: EventExpressionSyntax
class BinaryExpressionSyntax(ExpressionSyntax):
    attributes: SyntaxList
    left: ExpressionSyntax
    operatorToken: pyslang.parsing.Token
    right: ExpressionSyntax
class BinaryPropertyExprSyntax(PropertyExprSyntax):
    left: PropertyExprSyntax
    op: pyslang.parsing.Token
    right: PropertyExprSyntax
class BinarySequenceExprSyntax(SequenceExprSyntax):
    left: SequenceExprSyntax
    op: pyslang.parsing.Token
    right: SequenceExprSyntax
class BindDirectiveSyntax(MemberSyntax):
    bind: pyslang.parsing.Token
    instantiation: MemberSyntax
    target: NameSyntax
    targetInstances: BindTargetListSyntax
class BindTargetListSyntax(SyntaxNode):
    colon: pyslang.parsing.Token
    targets: SeparatedSyntaxList
class BinsSelectConditionExprSyntax(BinsSelectExpressionSyntax):
    binsof: pyslang.parsing.Token
    closeParen: pyslang.parsing.Token
    intersects: IntersectClauseSyntax
    name: NameSyntax
    openParen: pyslang.parsing.Token
class BinsSelectExpressionSyntax(SyntaxNode):
    pass
class BinsSelectionSyntax(MemberSyntax):
    equals: pyslang.parsing.Token
    expr: BinsSelectExpressionSyntax
    iff: CoverageIffClauseSyntax
    keyword: pyslang.parsing.Token
    name: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class BitSelectSyntax(SelectorSyntax):
    expr: ExpressionSyntax
class BlockCoverageEventSyntax(SyntaxNode):
    atat: pyslang.parsing.Token
    closeParen: pyslang.parsing.Token
    expr: BlockEventExpressionSyntax
    openParen: pyslang.parsing.Token
class BlockEventExpressionSyntax(SyntaxNode):
    pass
class BlockStatementSyntax(StatementSyntax):
    begin: pyslang.parsing.Token
    blockName: NamedBlockClauseSyntax
    end: pyslang.parsing.Token
    endBlockName: NamedBlockClauseSyntax
    items: SyntaxList
class CSTJsonMode(enum.Enum):
    Full: typing.ClassVar[CSTJsonMode]  # value = <CSTJsonMode.Full: 0>
    NoTrivia: typing.ClassVar[CSTJsonMode]  # value = <CSTJsonMode.NoTrivia: 3>
    NoWhitespace: typing.ClassVar[CSTJsonMode]  # value = <CSTJsonMode.NoWhitespace: 1>
    SimpleTokens: typing.ClassVar[CSTJsonMode]  # value = <CSTJsonMode.SimpleTokens: 4>
    SimpleTrivia: typing.ClassVar[CSTJsonMode]  # value = <CSTJsonMode.SimpleTrivia: 2>
class CaseGenerateSyntax(MemberSyntax):
    closeParen: pyslang.parsing.Token
    condition: ExpressionSyntax
    endCase: pyslang.parsing.Token
    items: SyntaxList
    keyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class CaseItemSyntax(SyntaxNode):
    pass
class CasePropertyExprSyntax(PropertyExprSyntax):
    caseKeyword: pyslang.parsing.Token
    closeParen: pyslang.parsing.Token
    endcase: pyslang.parsing.Token
    expr: ExpressionSyntax
    items: SyntaxList
    openParen: pyslang.parsing.Token
class CaseStatementSyntax(StatementSyntax):
    caseKeyword: pyslang.parsing.Token
    closeParen: pyslang.parsing.Token
    endcase: pyslang.parsing.Token
    expr: ExpressionSyntax
    items: SyntaxList
    matchesOrInside: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    uniqueOrPriority: pyslang.parsing.Token
class CastExpressionSyntax(ExpressionSyntax):
    apostrophe: pyslang.parsing.Token
    left: ExpressionSyntax
    right: ParenthesizedExpressionSyntax
class CellConfigRuleSyntax(ConfigRuleSyntax):
    cell: pyslang.parsing.Token
    name: ConfigCellIdentifierSyntax
    ruleClause: ConfigRuleClauseSyntax
    semi: pyslang.parsing.Token
class ChargeStrengthSyntax(NetStrengthSyntax):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    strength: pyslang.parsing.Token
class CheckerDataDeclarationSyntax(MemberSyntax):
    data: DataDeclarationSyntax
    rand: pyslang.parsing.Token
class CheckerDeclarationSyntax(MemberSyntax):
    end: pyslang.parsing.Token
    endBlockName: NamedBlockClauseSyntax
    keyword: pyslang.parsing.Token
    members: SyntaxList
    name: pyslang.parsing.Token
    portList: AssertionItemPortListSyntax
    semi: pyslang.parsing.Token
class CheckerInstanceStatementSyntax(StatementSyntax):
    instance: CheckerInstantiationSyntax
class CheckerInstantiationSyntax(MemberSyntax):
    instances: SeparatedSyntaxList
    parameters: ParameterValueAssignmentSyntax
    semi: pyslang.parsing.Token
    type: NameSyntax
class ClassDeclarationSyntax(MemberSyntax):
    classKeyword: pyslang.parsing.Token
    endBlockName: NamedBlockClauseSyntax
    endClass: pyslang.parsing.Token
    extendsClause: ExtendsClauseSyntax
    finalSpecifier: ClassSpecifierSyntax
    implementsClause: ImplementsClauseSyntax
    items: SyntaxList
    name: pyslang.parsing.Token
    parameters: ParameterPortListSyntax
    semi: pyslang.parsing.Token
    virtualOrInterface: pyslang.parsing.Token
class ClassMethodDeclarationSyntax(MemberSyntax):
    declaration: FunctionDeclarationSyntax
    qualifiers: TokenList
class ClassMethodPrototypeSyntax(MemberSyntax):
    prototype: FunctionPrototypeSyntax
    qualifiers: TokenList
    semi: pyslang.parsing.Token
class ClassNameSyntax(NameSyntax):
    identifier: pyslang.parsing.Token
    parameters: ParameterValueAssignmentSyntax
class ClassPropertyDeclarationSyntax(MemberSyntax):
    declaration: MemberSyntax
    qualifiers: TokenList
class ClassSpecifierSyntax(SyntaxNode):
    colon: pyslang.parsing.Token
    keyword: pyslang.parsing.Token
class ClockingDeclarationSyntax(MemberSyntax):
    at: pyslang.parsing.Token
    blockName: pyslang.parsing.Token
    clocking: pyslang.parsing.Token
    endBlockName: NamedBlockClauseSyntax
    endClocking: pyslang.parsing.Token
    event: EventExpressionSyntax
    globalOrDefault: pyslang.parsing.Token
    items: SyntaxList
    semi: pyslang.parsing.Token
class ClockingDirectionSyntax(SyntaxNode):
    input: pyslang.parsing.Token
    inputSkew: ClockingSkewSyntax
    output: pyslang.parsing.Token
    outputSkew: ClockingSkewSyntax
class ClockingItemSyntax(MemberSyntax):
    decls: SeparatedSyntaxList
    direction: ClockingDirectionSyntax
    semi: pyslang.parsing.Token
class ClockingPropertyExprSyntax(PropertyExprSyntax):
    event: TimingControlSyntax
    expr: PropertyExprSyntax
class ClockingSequenceExprSyntax(SequenceExprSyntax):
    event: TimingControlSyntax
    expr: SequenceExprSyntax
class ClockingSkewSyntax(SyntaxNode):
    delay: TimingControlSyntax
    edge: pyslang.parsing.Token
class ColonExpressionClauseSyntax(SyntaxNode):
    colon: pyslang.parsing.Token
    expr: ExpressionSyntax
class CommentHandler:
    class Kind(enum.Enum):
        LintOff: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.LintOff: 3>
        LintOn: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.LintOn: 2>
        LintRestore: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.LintRestore: 5>
        LintSave: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.LintSave: 4>
        Protect: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.Protect: 0>
        TranslateOff: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.TranslateOff: 1>
    LintOff: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.LintOff: 3>
    LintOn: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.LintOn: 2>
    LintRestore: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.LintRestore: 5>
    LintSave: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.LintSave: 4>
    Protect: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.Protect: 0>
    TranslateOff: typing.ClassVar[CommentHandler.Kind]  # value = <Kind.TranslateOff: 1>
    endRegion: str
    kind: ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, kind: ..., endRegion: str) -> None:
        ...
class CompilationUnitSyntax(SyntaxNode):
    endOfFile: pyslang.parsing.Token
    members: SyntaxList
class ConcatenationExpressionSyntax(PrimaryExpressionSyntax):
    closeBrace: pyslang.parsing.Token
    expressions: SeparatedSyntaxList
    openBrace: pyslang.parsing.Token
class ConcurrentAssertionMemberSyntax(MemberSyntax):
    statement: ConcurrentAssertionStatementSyntax
class ConcurrentAssertionStatementSyntax(StatementSyntax):
    action: ActionBlockSyntax
    closeParen: pyslang.parsing.Token
    keyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    propertyOrSequence: pyslang.parsing.Token
    propertySpec: PropertySpecSyntax
class ConditionalBranchDirectiveSyntax(DirectiveSyntax):
    disabledTokens: TokenList
    expr: ConditionalDirectiveExpressionSyntax
class ConditionalConstraintSyntax(ConstraintItemSyntax):
    closeParen: pyslang.parsing.Token
    condition: ExpressionSyntax
    constraints: ConstraintItemSyntax
    elseClause: ElseConstraintClauseSyntax
    ifKeyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class ConditionalDirectiveExpressionSyntax(SyntaxNode):
    pass
class ConditionalExpressionSyntax(ExpressionSyntax):
    attributes: SyntaxList
    colon: pyslang.parsing.Token
    left: ExpressionSyntax
    predicate: ConditionalPredicateSyntax
    question: pyslang.parsing.Token
    right: ExpressionSyntax
class ConditionalPathDeclarationSyntax(MemberSyntax):
    closeParen: pyslang.parsing.Token
    keyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    path: PathDeclarationSyntax
    predicate: ExpressionSyntax
class ConditionalPatternSyntax(SyntaxNode):
    expr: ExpressionSyntax
    matchesClause: MatchesClauseSyntax
class ConditionalPredicateSyntax(SyntaxNode):
    conditions: SeparatedSyntaxList
class ConditionalPropertyExprSyntax(PropertyExprSyntax):
    closeParen: pyslang.parsing.Token
    condition: ExpressionSyntax
    elseClause: ElsePropertyClauseSyntax
    expr: PropertyExprSyntax
    ifKeyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class ConditionalStatementSyntax(StatementSyntax):
    closeParen: pyslang.parsing.Token
    elseClause: ElseClauseSyntax
    ifKeyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    predicate: ConditionalPredicateSyntax
    statement: StatementSyntax
    uniqueOrPriority: pyslang.parsing.Token
class ConfigCellIdentifierSyntax(SyntaxNode):
    cell: pyslang.parsing.Token
    dot: pyslang.parsing.Token
    library: pyslang.parsing.Token
class ConfigDeclarationSyntax(MemberSyntax):
    blockName: NamedBlockClauseSyntax
    config: pyslang.parsing.Token
    design: pyslang.parsing.Token
    endconfig: pyslang.parsing.Token
    localparams: SyntaxList
    name: pyslang.parsing.Token
    rules: SyntaxList
    semi1: pyslang.parsing.Token
    semi2: pyslang.parsing.Token
    topCells: SyntaxList
class ConfigInstanceIdentifierSyntax(SyntaxNode):
    dot: pyslang.parsing.Token
    name: pyslang.parsing.Token
class ConfigLiblistSyntax(ConfigRuleClauseSyntax):
    liblist: pyslang.parsing.Token
    libraries: TokenList
class ConfigRuleClauseSyntax(SyntaxNode):
    pass
class ConfigRuleSyntax(SyntaxNode):
    pass
class ConfigUseClauseSyntax(ConfigRuleClauseSyntax):
    colon: pyslang.parsing.Token
    config: pyslang.parsing.Token
    name: ConfigCellIdentifierSyntax
    paramAssignments: ParameterValueAssignmentSyntax
    use: pyslang.parsing.Token
class ConstraintBlockSyntax(ConstraintItemSyntax):
    closeBrace: pyslang.parsing.Token
    items: SyntaxList
    openBrace: pyslang.parsing.Token
class ConstraintDeclarationSyntax(MemberSyntax):
    block: ConstraintBlockSyntax
    keyword: pyslang.parsing.Token
    name: NameSyntax
    qualifiers: TokenList
    specifiers: SyntaxList
class ConstraintItemSyntax(SyntaxNode):
    pass
class ConstraintPrototypeSyntax(MemberSyntax):
    keyword: pyslang.parsing.Token
    name: NameSyntax
    qualifiers: TokenList
    semi: pyslang.parsing.Token
    specifiers: SyntaxList
class ContinuousAssignSyntax(MemberSyntax):
    assign: pyslang.parsing.Token
    assignments: SeparatedSyntaxList
    delay: TimingControlSyntax
    semi: pyslang.parsing.Token
    strength: DriveStrengthSyntax
class CopyClassExpressionSyntax(ExpressionSyntax):
    expr: ExpressionSyntax
    scopedNew: NameSyntax
class CoverCrossSyntax(MemberSyntax):
    closeBrace: pyslang.parsing.Token
    cross: pyslang.parsing.Token
    emptySemi: pyslang.parsing.Token
    iff: CoverageIffClauseSyntax
    items: SeparatedSyntaxList
    label: NamedLabelSyntax
    members: SyntaxList
    openBrace: pyslang.parsing.Token
class CoverageBinInitializerSyntax(SyntaxNode):
    pass
class CoverageBinsArraySizeSyntax(SyntaxNode):
    closeBracket: pyslang.parsing.Token
    expr: ExpressionSyntax
    openBracket: pyslang.parsing.Token
class CoverageBinsSyntax(MemberSyntax):
    equals: pyslang.parsing.Token
    iff: CoverageIffClauseSyntax
    initializer: CoverageBinInitializerSyntax
    keyword: pyslang.parsing.Token
    name: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    size: CoverageBinsArraySizeSyntax
    wildcard: pyslang.parsing.Token
class CoverageIffClauseSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    expr: ExpressionSyntax
    iff: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class CoverageOptionSyntax(MemberSyntax):
    expr: ExpressionSyntax
    semi: pyslang.parsing.Token
class CovergroupDeclarationSyntax(MemberSyntax):
    covergroup: pyslang.parsing.Token
    endBlockName: NamedBlockClauseSyntax
    endgroup: pyslang.parsing.Token
    event: SyntaxNode
    extends: pyslang.parsing.Token
    members: SyntaxList
    name: pyslang.parsing.Token
    portList: FunctionPortListSyntax
    semi: pyslang.parsing.Token
class CoverpointSyntax(MemberSyntax):
    closeBrace: pyslang.parsing.Token
    coverpoint: pyslang.parsing.Token
    emptySemi: pyslang.parsing.Token
    expr: ExpressionSyntax
    iff: CoverageIffClauseSyntax
    label: NamedLabelSyntax
    members: SyntaxList
    openBrace: pyslang.parsing.Token
    type: DataTypeSyntax
class DPIExportSyntax(MemberSyntax):
    c_identifier: pyslang.parsing.Token
    equals: pyslang.parsing.Token
    functionOrTask: pyslang.parsing.Token
    keyword: pyslang.parsing.Token
    name: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    specString: pyslang.parsing.Token
class DPIImportSyntax(MemberSyntax):
    c_identifier: pyslang.parsing.Token
    equals: pyslang.parsing.Token
    keyword: pyslang.parsing.Token
    method: FunctionPrototypeSyntax
    property: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    specString: pyslang.parsing.Token
class DataDeclarationSyntax(MemberSyntax):
    declarators: SeparatedSyntaxList
    modifiers: TokenList
    semi: pyslang.parsing.Token
    type: DataTypeSyntax
class DataTypeSyntax(ExpressionSyntax):
    pass
class DeclaratorSyntax(SyntaxNode):
    dimensions: SyntaxList
    initializer: EqualsValueClauseSyntax
    name: pyslang.parsing.Token
class DefParamAssignmentSyntax(SyntaxNode):
    name: NameSyntax
    setter: EqualsValueClauseSyntax
class DefParamSyntax(MemberSyntax):
    assignments: SeparatedSyntaxList
    defparam: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class DefaultCaseItemSyntax(CaseItemSyntax):
    clause: SyntaxNode
    colon: pyslang.parsing.Token
    defaultKeyword: pyslang.parsing.Token
class DefaultClockingReferenceSyntax(MemberSyntax):
    clocking: pyslang.parsing.Token
    defaultKeyword: pyslang.parsing.Token
    name: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class DefaultConfigRuleSyntax(ConfigRuleSyntax):
    defaultKeyword: pyslang.parsing.Token
    liblist: ConfigLiblistSyntax
    semi: pyslang.parsing.Token
class DefaultCoverageBinInitializerSyntax(CoverageBinInitializerSyntax):
    defaultKeyword: pyslang.parsing.Token
    sequenceKeyword: pyslang.parsing.Token
class DefaultDecayTimeDirectiveSyntax(DirectiveSyntax):
    time: pyslang.parsing.Token
class DefaultDisableDeclarationSyntax(MemberSyntax):
    defaultKeyword: pyslang.parsing.Token
    disableKeyword: pyslang.parsing.Token
    expr: ExpressionSyntax
    iffKeyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class DefaultDistItemSyntax(DistItemBaseSyntax):
    defaultKeyword: pyslang.parsing.Token
    weight: DistWeightSyntax
class DefaultExtendsClauseArgSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    defaultKeyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class DefaultFunctionPortSyntax(FunctionPortBaseSyntax):
    keyword: pyslang.parsing.Token
class DefaultNetTypeDirectiveSyntax(DirectiveSyntax):
    netType: pyslang.parsing.Token
class DefaultPropertyCaseItemSyntax(PropertyCaseItemSyntax):
    colon: pyslang.parsing.Token
    defaultKeyword: pyslang.parsing.Token
    expr: PropertyExprSyntax
    semi: pyslang.parsing.Token
class DefaultRsCaseItemSyntax(RsCaseItemSyntax):
    colon: pyslang.parsing.Token
    defaultKeyword: pyslang.parsing.Token
    item: RsProdItemSyntax
    semi: pyslang.parsing.Token
class DefaultSkewItemSyntax(MemberSyntax):
    direction: ClockingDirectionSyntax
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class DefaultTriregStrengthDirectiveSyntax(DirectiveSyntax):
    strength: pyslang.parsing.Token
class DeferredAssertionSyntax(SyntaxNode):
    finalKeyword: pyslang.parsing.Token
    hash: pyslang.parsing.Token
    zero: pyslang.parsing.Token
class DefineDirectiveSyntax(DirectiveSyntax):
    body: TokenList
    formalArguments: MacroFormalArgumentListSyntax
    name: pyslang.parsing.Token
class Delay3Syntax(TimingControlSyntax):
    closeParen: pyslang.parsing.Token
    comma1: pyslang.parsing.Token
    comma2: pyslang.parsing.Token
    delay1: ExpressionSyntax
    delay2: ExpressionSyntax
    delay3: ExpressionSyntax
    hash: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class DelaySyntax(TimingControlSyntax):
    delayValue: ExpressionSyntax
    hash: pyslang.parsing.Token
class DelayedSequenceElementSyntax(SyntaxNode):
    closeBracket: pyslang.parsing.Token
    delayVal: ExpressionSyntax
    doubleHash: pyslang.parsing.Token
    expr: SequenceExprSyntax
    op: pyslang.parsing.Token
    openBracket: pyslang.parsing.Token
    range: SelectorSyntax
class DelayedSequenceExprSyntax(SequenceExprSyntax):
    elements: SyntaxList
    first: SequenceExprSyntax
class DimensionSpecifierSyntax(SyntaxNode):
    pass
class DirectiveSyntax(SyntaxNode):
    directive: pyslang.parsing.Token
class DisableConstraintSyntax(ConstraintItemSyntax):
    disable: pyslang.parsing.Token
    name: ExpressionSyntax
    semi: pyslang.parsing.Token
    soft: pyslang.parsing.Token
class DisableForkStatementSyntax(StatementSyntax):
    disable: pyslang.parsing.Token
    fork: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class DisableIffSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    disable: pyslang.parsing.Token
    expr: ExpressionSyntax
    iff: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class DisableStatementSyntax(StatementSyntax):
    disable: pyslang.parsing.Token
    name: NameSyntax
    semi: pyslang.parsing.Token
class DistConstraintListSyntax(SyntaxNode):
    closeBrace: pyslang.parsing.Token
    dist: pyslang.parsing.Token
    items: SeparatedSyntaxList
    openBrace: pyslang.parsing.Token
class DistItemBaseSyntax(SyntaxNode):
    pass
class DistItemSyntax(DistItemBaseSyntax):
    range: ExpressionSyntax
    weight: DistWeightSyntax
class DistWeightSyntax(SyntaxNode):
    expr: ExpressionSyntax
    extraOp: pyslang.parsing.Token
    op: pyslang.parsing.Token
class DividerClauseSyntax(SyntaxNode):
    divide: pyslang.parsing.Token
    value: pyslang.parsing.Token
class DoWhileStatementSyntax(StatementSyntax):
    closeParen: pyslang.parsing.Token
    doKeyword: pyslang.parsing.Token
    expr: ExpressionSyntax
    openParen: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    statement: StatementSyntax
    whileKeyword: pyslang.parsing.Token
class DotMemberClauseSyntax(SyntaxNode):
    dot: pyslang.parsing.Token
    member: pyslang.parsing.Token
class DriveStrengthSyntax(NetStrengthSyntax):
    closeParen: pyslang.parsing.Token
    comma: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    strength0: pyslang.parsing.Token
    strength1: pyslang.parsing.Token
class EdgeControlSpecifierSyntax(SyntaxNode):
    closeBracket: pyslang.parsing.Token
    descriptors: SeparatedSyntaxList
    openBracket: pyslang.parsing.Token
class EdgeDescriptorSyntax(SyntaxNode):
    t1: pyslang.parsing.Token
    t2: pyslang.parsing.Token
class EdgeSensitivePathSuffixSyntax(PathSuffixSyntax):
    closeParen: pyslang.parsing.Token
    colon: pyslang.parsing.Token
    expr: ExpressionSyntax
    openParen: pyslang.parsing.Token
    outputs: SeparatedSyntaxList
    polarityOperator: pyslang.parsing.Token
class ElabSystemTaskSyntax(MemberSyntax):
    arguments: ArgumentListSyntax
    name: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class ElementSelectExpressionSyntax(ExpressionSyntax):
    left: ExpressionSyntax
    select: ElementSelectSyntax
class ElementSelectSyntax(SyntaxNode):
    closeBracket: pyslang.parsing.Token
    openBracket: pyslang.parsing.Token
    selector: SelectorSyntax
class ElseClauseSyntax(SyntaxNode):
    clause: SyntaxNode
    elseKeyword: pyslang.parsing.Token
class ElseConstraintClauseSyntax(SyntaxNode):
    constraints: ConstraintItemSyntax
    elseKeyword: pyslang.parsing.Token
class ElsePropertyClauseSyntax(SyntaxNode):
    elseKeyword: pyslang.parsing.Token
    expr: PropertyExprSyntax
class EmptyArgumentSyntax(ArgumentSyntax):
    placeholder: pyslang.parsing.Token
class EmptyIdentifierNameSyntax(NameSyntax):
    placeholder: pyslang.parsing.Token
class EmptyMemberSyntax(MemberSyntax):
    qualifiers: TokenList
    semi: pyslang.parsing.Token
class EmptyNonAnsiPortSyntax(NonAnsiPortSyntax):
    placeholder: pyslang.parsing.Token
class EmptyPortConnectionSyntax(PortConnectionSyntax):
    placeholder: pyslang.parsing.Token
class EmptyQueueExpressionSyntax(PrimaryExpressionSyntax):
    closeBrace: pyslang.parsing.Token
    openBrace: pyslang.parsing.Token
class EmptyStatementSyntax(StatementSyntax):
    semicolon: pyslang.parsing.Token
class EmptyTimingCheckArgSyntax(TimingCheckArgSyntax):
    placeholder: pyslang.parsing.Token
class EnumTypeSyntax(DataTypeSyntax):
    baseType: DataTypeSyntax
    closeBrace: pyslang.parsing.Token
    dimensions: SyntaxList
    keyword: pyslang.parsing.Token
    members: SeparatedSyntaxList
    openBrace: pyslang.parsing.Token
class EqualsAssertionArgClauseSyntax(SyntaxNode):
    equals: pyslang.parsing.Token
    expr: PropertyExprSyntax
class EqualsTypeClauseSyntax(SyntaxNode):
    equals: pyslang.parsing.Token
    type: DataTypeSyntax
class EqualsValueClauseSyntax(SyntaxNode):
    equals: pyslang.parsing.Token
    expr: ExpressionSyntax
class EventControlSyntax(TimingControlSyntax):
    at: pyslang.parsing.Token
    eventName: ExpressionSyntax
class EventControlWithExpressionSyntax(TimingControlSyntax):
    at: pyslang.parsing.Token
    expr: EventExpressionSyntax
class EventExpressionSyntax(SequenceExprSyntax):
    pass
class EventTriggerStatementSyntax(StatementSyntax):
    name: NameSyntax
    semi: pyslang.parsing.Token
    timing: TimingControlSyntax
    trigger: pyslang.parsing.Token
class ExplicitAnsiPortSyntax(MemberSyntax):
    closeParen: pyslang.parsing.Token
    direction: pyslang.parsing.Token
    dot: pyslang.parsing.Token
    expr: ExpressionSyntax
    name: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class ExplicitNonAnsiPortSyntax(NonAnsiPortSyntax):
    closeParen: pyslang.parsing.Token
    dot: pyslang.parsing.Token
    expr: PortExpressionSyntax
    name: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class ExpressionConstraintSyntax(ConstraintItemSyntax):
    expr: ExpressionSyntax
    semi: pyslang.parsing.Token
    soft: pyslang.parsing.Token
class ExpressionCoverageBinInitializerSyntax(CoverageBinInitializerSyntax):
    expr: ExpressionSyntax
class ExpressionOrDistSyntax(ExpressionSyntax):
    distribution: DistConstraintListSyntax
    expr: ExpressionSyntax
class ExpressionPatternSyntax(PatternSyntax):
    expr: ExpressionSyntax
class ExpressionStatementSyntax(StatementSyntax):
    expr: ExpressionSyntax
    semi: pyslang.parsing.Token
class ExpressionSyntax(SyntaxNode):
    pass
class ExpressionTimingCheckArgSyntax(TimingCheckArgSyntax):
    expr: ExpressionSyntax
class ExtendsClauseSyntax(SyntaxNode):
    arguments: ArgumentListSyntax
    baseName: NameSyntax
    defaultedArg: DefaultExtendsClauseArgSyntax
    keyword: pyslang.parsing.Token
class ExternInterfaceMethodSyntax(MemberSyntax):
    externKeyword: pyslang.parsing.Token
    forkJoin: pyslang.parsing.Token
    prototype: FunctionPrototypeSyntax
    semi: pyslang.parsing.Token
class ExternModuleDeclSyntax(MemberSyntax):
    actualAttributes: SyntaxList
    externKeyword: pyslang.parsing.Token
    header: ModuleHeaderSyntax
class ExternUdpDeclSyntax(MemberSyntax):
    actualAttributes: SyntaxList
    externKeyword: pyslang.parsing.Token
    name: pyslang.parsing.Token
    portList: UdpPortListSyntax
    primitive: pyslang.parsing.Token
class FilePathSpecSyntax(SyntaxNode):
    path: pyslang.parsing.Token
class FirstMatchSequenceExprSyntax(SequenceExprSyntax):
    closeParen: pyslang.parsing.Token
    expr: SequenceExprSyntax
    first_match: pyslang.parsing.Token
    matchList: SequenceMatchListSyntax
    openParen: pyslang.parsing.Token
class ForLoopStatementSyntax(StatementSyntax):
    closeParen: pyslang.parsing.Token
    forKeyword: pyslang.parsing.Token
    initializers: SeparatedSyntaxList
    openParen: pyslang.parsing.Token
    semi1: pyslang.parsing.Token
    semi2: pyslang.parsing.Token
    statement: StatementSyntax
    steps: SeparatedSyntaxList
    stopExpr: ExpressionSyntax
class ForVariableDeclarationSyntax(SyntaxNode):
    declarator: DeclaratorSyntax
    type: DataTypeSyntax
    varKeyword: pyslang.parsing.Token
class ForeachLoopListSyntax(SyntaxNode):
    arrayName: ExpressionSyntax
    closeBracket: pyslang.parsing.Token
    closeParen: pyslang.parsing.Token
    loopVariables: SeparatedSyntaxList
    openBracket: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class ForeachLoopStatementSyntax(StatementSyntax):
    keyword: pyslang.parsing.Token
    loopList: ForeachLoopListSyntax
    statement: StatementSyntax
class ForeverStatementSyntax(StatementSyntax):
    foreverKeyword: pyslang.parsing.Token
    statement: StatementSyntax
class ForwardTypeRestrictionSyntax(SyntaxNode):
    keyword1: pyslang.parsing.Token
    keyword2: pyslang.parsing.Token
class ForwardTypedefDeclarationSyntax(MemberSyntax):
    name: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    typeRestriction: ForwardTypeRestrictionSyntax
    typedefKeyword: pyslang.parsing.Token
class FunctionDeclarationSyntax(MemberSyntax):
    end: pyslang.parsing.Token
    endBlockName: NamedBlockClauseSyntax
    items: SyntaxList
    prototype: FunctionPrototypeSyntax
    semi: pyslang.parsing.Token
class FunctionPortBaseSyntax(SyntaxNode):
    pass
class FunctionPortListSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    ports: SeparatedSyntaxList
class FunctionPortSyntax(FunctionPortBaseSyntax):
    attributes: SyntaxList
    constKeyword: pyslang.parsing.Token
    dataType: DataTypeSyntax
    declarator: DeclaratorSyntax
    direction: pyslang.parsing.Token
    staticKeyword: pyslang.parsing.Token
    varKeyword: pyslang.parsing.Token
class FunctionPrototypeSyntax(SyntaxNode):
    keyword: pyslang.parsing.Token
    lifetime: pyslang.parsing.Token
    name: NameSyntax
    portList: FunctionPortListSyntax
    returnType: DataTypeSyntax
    specifiers: SyntaxList
class GenerateBlockSyntax(MemberSyntax):
    begin: pyslang.parsing.Token
    beginName: NamedBlockClauseSyntax
    end: pyslang.parsing.Token
    endName: NamedBlockClauseSyntax
    label: NamedLabelSyntax
    members: SyntaxList
class GenerateRegionSyntax(MemberSyntax):
    endgenerate: pyslang.parsing.Token
    keyword: pyslang.parsing.Token
    members: SyntaxList
class GenvarDeclarationSyntax(MemberSyntax):
    identifiers: SeparatedSyntaxList
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class HierarchicalInstanceSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    connections: SeparatedSyntaxList
    decl: InstanceNameSyntax
    openParen: pyslang.parsing.Token
class HierarchyInstantiationSyntax(MemberSyntax):
    instances: SeparatedSyntaxList
    parameters: ParameterValueAssignmentSyntax
    semi: pyslang.parsing.Token
    type: pyslang.parsing.Token
class IdWithExprCoverageBinInitializerSyntax(CoverageBinInitializerSyntax):
    id: pyslang.parsing.Token
    withClause: WithClauseSyntax
class IdentifierNameSyntax(NameSyntax):
    identifier: pyslang.parsing.Token
class IdentifierSelectNameSyntax(NameSyntax):
    identifier: pyslang.parsing.Token
    selectors: SyntaxList
class IfGenerateSyntax(MemberSyntax):
    block: MemberSyntax
    closeParen: pyslang.parsing.Token
    condition: ExpressionSyntax
    elseClause: ElseClauseSyntax
    keyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class IfNonePathDeclarationSyntax(MemberSyntax):
    keyword: pyslang.parsing.Token
    path: PathDeclarationSyntax
class IffEventClauseSyntax(SyntaxNode):
    expr: ExpressionSyntax
    iff: pyslang.parsing.Token
class ImmediateAssertionMemberSyntax(MemberSyntax):
    statement: ImmediateAssertionStatementSyntax
class ImmediateAssertionStatementSyntax(StatementSyntax):
    action: ActionBlockSyntax
    delay: DeferredAssertionSyntax
    expr: ParenthesizedExpressionSyntax
    keyword: pyslang.parsing.Token
class ImplementsClauseSyntax(SyntaxNode):
    interfaces: SeparatedSyntaxList
    keyword: pyslang.parsing.Token
class ImplicationConstraintSyntax(ConstraintItemSyntax):
    arrow: pyslang.parsing.Token
    constraints: ConstraintItemSyntax
    left: ExpressionSyntax
class ImplicitAnsiPortSyntax(MemberSyntax):
    declarator: DeclaratorSyntax
    header: PortHeaderSyntax
class ImplicitEventControlSyntax(TimingControlSyntax):
    at: pyslang.parsing.Token
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    star: pyslang.parsing.Token
class ImplicitNonAnsiPortSyntax(NonAnsiPortSyntax):
    expr: PortExpressionSyntax
class ImplicitTypeSyntax(DataTypeSyntax):
    dimensions: SyntaxList
    placeholder: pyslang.parsing.Token
    signing: pyslang.parsing.Token
class IncludeDirectiveSyntax(DirectiveSyntax):
    fileName: pyslang.parsing.Token
class IncludeMetadata:
    def __init__(self) -> None:
        ...
    @property
    def buffer(self) -> pyslang.SourceBuffer:
        ...
    @property
    def isSystem(self) -> bool:
        ...
    @property
    def path(self) -> str:
        ...
    @property
    def syntax(self) -> ...:
        ...
class InsideExpressionSyntax(ExpressionSyntax):
    expr: ExpressionSyntax
    inside: pyslang.parsing.Token
    ranges: RangeListSyntax
class InstanceConfigRuleSyntax(ConfigRuleSyntax):
    instance: pyslang.parsing.Token
    instanceNames: SyntaxList
    ruleClause: ConfigRuleClauseSyntax
    semi: pyslang.parsing.Token
    topModule: pyslang.parsing.Token
class InstanceNameSyntax(SyntaxNode):
    dimensions: SyntaxList
    name: pyslang.parsing.Token
class IntegerTypeSyntax(DataTypeSyntax):
    dimensions: SyntaxList
    keyword: pyslang.parsing.Token
    signing: pyslang.parsing.Token
class IntegerVectorExpressionSyntax(PrimaryExpressionSyntax):
    base: pyslang.parsing.Token
    size: pyslang.parsing.Token
    value: pyslang.parsing.Token
class InterfacePortHeaderSyntax(PortHeaderSyntax):
    modport: DotMemberClauseSyntax
    nameOrKeyword: pyslang.parsing.Token
class IntersectClauseSyntax(SyntaxNode):
    intersect: pyslang.parsing.Token
    ranges: RangeListSyntax
class InvocationExpressionSyntax(ExpressionSyntax):
    arguments: ArgumentListSyntax
    attributes: SyntaxList
    left: ExpressionSyntax
class JumpStatementSyntax(StatementSyntax):
    breakOrContinue: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class KeywordNameSyntax(NameSyntax):
    keyword: pyslang.parsing.Token
class KeywordTypeSyntax(DataTypeSyntax):
    keyword: pyslang.parsing.Token
class LetDeclarationSyntax(MemberSyntax):
    equals: pyslang.parsing.Token
    expr: ExpressionSyntax
    identifier: pyslang.parsing.Token
    let: pyslang.parsing.Token
    portList: AssertionItemPortListSyntax
    semi: pyslang.parsing.Token
class LibraryDeclarationSyntax(MemberSyntax):
    filePaths: SeparatedSyntaxList
    incDirClause: LibraryIncDirClauseSyntax
    library: pyslang.parsing.Token
    name: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class LibraryIncDirClauseSyntax(SyntaxNode):
    filePaths: SeparatedSyntaxList
    incdir: pyslang.parsing.Token
    minus: pyslang.parsing.Token
class LibraryIncludeStatementSyntax(MemberSyntax):
    filePath: FilePathSpecSyntax
    include: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class LibraryMapSyntax(SyntaxNode):
    endOfFile: pyslang.parsing.Token
    members: SyntaxList
class LineDirectiveSyntax(DirectiveSyntax):
    fileName: pyslang.parsing.Token
    level: pyslang.parsing.Token
    lineNumber: pyslang.parsing.Token
class LiteralExpressionSyntax(PrimaryExpressionSyntax):
    literal: pyslang.parsing.Token
class LocalVariableDeclarationSyntax(MemberSyntax):
    declarators: SeparatedSyntaxList
    semi: pyslang.parsing.Token
    type: DataTypeSyntax
    var: pyslang.parsing.Token
class LoopConstraintSyntax(ConstraintItemSyntax):
    constraints: ConstraintItemSyntax
    foreachKeyword: pyslang.parsing.Token
    loopList: ForeachLoopListSyntax
class LoopGenerateSyntax(MemberSyntax):
    block: MemberSyntax
    closeParen: pyslang.parsing.Token
    equals: pyslang.parsing.Token
    genvar: pyslang.parsing.Token
    identifier: pyslang.parsing.Token
    initialExpr: ExpressionSyntax
    iterationExpr: ExpressionSyntax
    keyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    semi1: pyslang.parsing.Token
    semi2: pyslang.parsing.Token
    stopExpr: ExpressionSyntax
class LoopStatementSyntax(StatementSyntax):
    closeParen: pyslang.parsing.Token
    expr: ExpressionSyntax
    openParen: pyslang.parsing.Token
    repeatOrWhile: pyslang.parsing.Token
    statement: StatementSyntax
class MacroActualArgumentListSyntax(SyntaxNode):
    args: SeparatedSyntaxList
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class MacroActualArgumentSyntax(SyntaxNode):
    tokens: TokenList
class MacroArgumentDefaultSyntax(SyntaxNode):
    equals: pyslang.parsing.Token
    tokens: TokenList
class MacroFormalArgumentListSyntax(SyntaxNode):
    args: SeparatedSyntaxList
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class MacroFormalArgumentSyntax(SyntaxNode):
    defaultValue: MacroArgumentDefaultSyntax
    name: pyslang.parsing.Token
class MacroUsageSyntax(DirectiveSyntax):
    args: MacroActualArgumentListSyntax
class MatchesClauseSyntax(SyntaxNode):
    matchesKeyword: pyslang.parsing.Token
    pattern: PatternSyntax
class MemberAccessExpressionSyntax(ExpressionSyntax):
    dot: pyslang.parsing.Token
    left: ExpressionSyntax
    name: pyslang.parsing.Token
class MemberSyntax(SyntaxNode):
    attributes: SyntaxList
class MinTypMaxExpressionSyntax(ExpressionSyntax):
    colon1: pyslang.parsing.Token
    colon2: pyslang.parsing.Token
    max: ExpressionSyntax
    min: ExpressionSyntax
    typ: ExpressionSyntax
class ModportClockingPortSyntax(MemberSyntax):
    clocking: pyslang.parsing.Token
    name: pyslang.parsing.Token
class ModportDeclarationSyntax(MemberSyntax):
    items: SeparatedSyntaxList
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class ModportExplicitPortSyntax(ModportPortSyntax):
    closeParen: pyslang.parsing.Token
    dot: pyslang.parsing.Token
    expr: ExpressionSyntax
    name: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class ModportItemSyntax(SyntaxNode):
    name: pyslang.parsing.Token
    ports: AnsiPortListSyntax
class ModportNamedPortSyntax(ModportPortSyntax):
    name: pyslang.parsing.Token
class ModportPortSyntax(SyntaxNode):
    pass
class ModportSimplePortListSyntax(MemberSyntax):
    direction: pyslang.parsing.Token
    ports: SeparatedSyntaxList
class ModportSubroutinePortListSyntax(MemberSyntax):
    importExport: pyslang.parsing.Token
    ports: SeparatedSyntaxList
class ModportSubroutinePortSyntax(ModportPortSyntax):
    prototype: FunctionPrototypeSyntax
class ModuleDeclarationSyntax(MemberSyntax):
    blockName: NamedBlockClauseSyntax
    endmodule: pyslang.parsing.Token
    header: ModuleHeaderSyntax
    members: SyntaxList
class ModuleHeaderSyntax(SyntaxNode):
    imports: SyntaxList
    lifetime: pyslang.parsing.Token
    moduleKeyword: pyslang.parsing.Token
    name: pyslang.parsing.Token
    parameters: ParameterPortListSyntax
    ports: PortListSyntax
    semi: pyslang.parsing.Token
class MultipleConcatenationExpressionSyntax(PrimaryExpressionSyntax):
    closeBrace: pyslang.parsing.Token
    concatenation: ConcatenationExpressionSyntax
    expression: ExpressionSyntax
    openBrace: pyslang.parsing.Token
class NameSyntax(ExpressionSyntax):
    pass
class NameValuePragmaExpressionSyntax(PragmaExpressionSyntax):
    equals: pyslang.parsing.Token
    name: pyslang.parsing.Token
    value: PragmaExpressionSyntax
class NamedArgumentSyntax(ArgumentSyntax):
    closeParen: pyslang.parsing.Token
    dot: pyslang.parsing.Token
    expr: PropertyExprSyntax
    name: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class NamedBlockClauseSyntax(SyntaxNode):
    colon: pyslang.parsing.Token
    name: pyslang.parsing.Token
class NamedConditionalDirectiveExpressionSyntax(ConditionalDirectiveExpressionSyntax):
    name: pyslang.parsing.Token
class NamedLabelSyntax(SyntaxNode):
    colon: pyslang.parsing.Token
    name: pyslang.parsing.Token
class NamedParamAssignmentSyntax(ParamAssignmentSyntax):
    closeParen: pyslang.parsing.Token
    dot: pyslang.parsing.Token
    expr: ExpressionSyntax
    name: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class NamedPortConnectionSyntax(PortConnectionSyntax):
    closeParen: pyslang.parsing.Token
    dot: pyslang.parsing.Token
    expr: PropertyExprSyntax
    name: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class NamedStructurePatternMemberSyntax(StructurePatternMemberSyntax):
    colon: pyslang.parsing.Token
    name: pyslang.parsing.Token
    pattern: PatternSyntax
class NamedTypeSyntax(DataTypeSyntax):
    name: NameSyntax
class NetAliasSyntax(MemberSyntax):
    keyword: pyslang.parsing.Token
    nets: SeparatedSyntaxList
    semi: pyslang.parsing.Token
class NetDeclarationSyntax(MemberSyntax):
    declarators: SeparatedSyntaxList
    delay: TimingControlSyntax
    expansionHint: pyslang.parsing.Token
    netType: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    strength: NetStrengthSyntax
    type: DataTypeSyntax
class NetPortHeaderSyntax(PortHeaderSyntax):
    dataType: DataTypeSyntax
    direction: pyslang.parsing.Token
    netType: pyslang.parsing.Token
class NetStrengthSyntax(SyntaxNode):
    pass
class NetTypeDeclarationSyntax(MemberSyntax):
    keyword: pyslang.parsing.Token
    name: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    type: DataTypeSyntax
    withFunction: WithFunctionClauseSyntax
class NewArrayExpressionSyntax(ExpressionSyntax):
    closeBracket: pyslang.parsing.Token
    initializer: ParenthesizedExpressionSyntax
    newKeyword: NameSyntax
    openBracket: pyslang.parsing.Token
    sizeExpr: ExpressionSyntax
class NewClassExpressionSyntax(ExpressionSyntax):
    argList: ArgumentListSyntax
    scopedNew: NameSyntax
class NonAnsiPortListSyntax(PortListSyntax):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    ports: SeparatedSyntaxList
class NonAnsiPortSyntax(SyntaxNode):
    pass
class NonAnsiUdpPortListSyntax(UdpPortListSyntax):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    ports: SeparatedSyntaxList
    semi: pyslang.parsing.Token
class NumberPragmaExpressionSyntax(PragmaExpressionSyntax):
    base: pyslang.parsing.Token
    size: pyslang.parsing.Token
    value: pyslang.parsing.Token
class OneStepDelaySyntax(TimingControlSyntax):
    hash: pyslang.parsing.Token
    oneStep: pyslang.parsing.Token
class OrderedArgumentSyntax(ArgumentSyntax):
    expr: PropertyExprSyntax
class OrderedParamAssignmentSyntax(ParamAssignmentSyntax):
    expr: ExpressionSyntax
class OrderedPortConnectionSyntax(PortConnectionSyntax):
    expr: PropertyExprSyntax
class OrderedStructurePatternMemberSyntax(StructurePatternMemberSyntax):
    pattern: PatternSyntax
class PackageExportAllDeclarationSyntax(MemberSyntax):
    doubleColon: pyslang.parsing.Token
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    star1: pyslang.parsing.Token
    star2: pyslang.parsing.Token
class PackageExportDeclarationSyntax(MemberSyntax):
    items: SeparatedSyntaxList
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class PackageImportDeclarationSyntax(MemberSyntax):
    items: SeparatedSyntaxList
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class PackageImportItemSyntax(SyntaxNode):
    doubleColon: pyslang.parsing.Token
    item: pyslang.parsing.Token
    package: pyslang.parsing.Token
class ParamAssignmentSyntax(SyntaxNode):
    pass
class ParameterDeclarationBaseSyntax(SyntaxNode):
    keyword: pyslang.parsing.Token
class ParameterDeclarationStatementSyntax(MemberSyntax):
    parameter: ParameterDeclarationBaseSyntax
    semi: pyslang.parsing.Token
class ParameterDeclarationSyntax(ParameterDeclarationBaseSyntax):
    declarators: SeparatedSyntaxList
    type: DataTypeSyntax
class ParameterPortListSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    declarations: SeparatedSyntaxList
    hash: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class ParameterValueAssignmentSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    hash: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    parameters: SeparatedSyntaxList
class ParenExpressionListSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    expressions: SeparatedSyntaxList
    openParen: pyslang.parsing.Token
class ParenPragmaExpressionSyntax(PragmaExpressionSyntax):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    values: SeparatedSyntaxList
class ParenthesizedBinsSelectExprSyntax(BinsSelectExpressionSyntax):
    closeParen: pyslang.parsing.Token
    expr: BinsSelectExpressionSyntax
    openParen: pyslang.parsing.Token
class ParenthesizedConditionalDirectiveExpressionSyntax(ConditionalDirectiveExpressionSyntax):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    operand: ConditionalDirectiveExpressionSyntax
class ParenthesizedEventExpressionSyntax(EventExpressionSyntax):
    closeParen: pyslang.parsing.Token
    expr: EventExpressionSyntax
    openParen: pyslang.parsing.Token
class ParenthesizedExpressionSyntax(PrimaryExpressionSyntax):
    closeParen: pyslang.parsing.Token
    expression: ExpressionSyntax
    openParen: pyslang.parsing.Token
class ParenthesizedPatternSyntax(PatternSyntax):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    pattern: PatternSyntax
class ParenthesizedPropertyExprSyntax(PropertyExprSyntax):
    closeParen: pyslang.parsing.Token
    expr: PropertyExprSyntax
    matchList: SequenceMatchListSyntax
    openParen: pyslang.parsing.Token
class ParenthesizedSequenceExprSyntax(SequenceExprSyntax):
    closeParen: pyslang.parsing.Token
    expr: SequenceExprSyntax
    matchList: SequenceMatchListSyntax
    openParen: pyslang.parsing.Token
    repetition: SequenceRepetitionSyntax
class PathDeclarationSyntax(MemberSyntax):
    closeParen: pyslang.parsing.Token
    delays: SeparatedSyntaxList
    desc: PathDescriptionSyntax
    equals: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class PathDescriptionSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    edgeIdentifier: pyslang.parsing.Token
    inputs: SeparatedSyntaxList
    openParen: pyslang.parsing.Token
    pathOperator: pyslang.parsing.Token
    polarityOperator: pyslang.parsing.Token
    suffix: PathSuffixSyntax
class PathSuffixSyntax(SyntaxNode):
    pass
class PatternCaseItemSyntax(CaseItemSyntax):
    colon: pyslang.parsing.Token
    expr: ExpressionSyntax
    pattern: PatternSyntax
    statement: StatementSyntax
    tripleAnd: pyslang.parsing.Token
class PatternSyntax(SyntaxNode):
    pass
class PortConcatenationSyntax(PortExpressionSyntax):
    closeBrace: pyslang.parsing.Token
    openBrace: pyslang.parsing.Token
    references: SeparatedSyntaxList
class PortConnectionSyntax(SyntaxNode):
    attributes: SyntaxList
class PortDeclarationSyntax(MemberSyntax):
    declarators: SeparatedSyntaxList
    header: PortHeaderSyntax
    semi: pyslang.parsing.Token
class PortExpressionSyntax(SyntaxNode):
    pass
class PortHeaderSyntax(SyntaxNode):
    pass
class PortListSyntax(SyntaxNode):
    pass
class PortReferenceSyntax(PortExpressionSyntax):
    name: pyslang.parsing.Token
    select: ElementSelectSyntax
class PostfixUnaryExpressionSyntax(ExpressionSyntax):
    attributes: SyntaxList
    operand: ExpressionSyntax
    operatorToken: pyslang.parsing.Token
class PragmaDirectiveSyntax(DirectiveSyntax):
    args: SeparatedSyntaxList
    name: pyslang.parsing.Token
class PragmaExpressionSyntax(SyntaxNode):
    pass
class PrefixUnaryExpressionSyntax(ExpressionSyntax):
    attributes: SyntaxList
    operand: ExpressionSyntax
    operatorToken: pyslang.parsing.Token
class PrimaryBlockEventExpressionSyntax(BlockEventExpressionSyntax):
    keyword: pyslang.parsing.Token
    name: NameSyntax
class PrimaryExpressionSyntax(ExpressionSyntax):
    pass
class PrimitiveInstantiationSyntax(MemberSyntax):
    delay: TimingControlSyntax
    instances: SeparatedSyntaxList
    semi: pyslang.parsing.Token
    strength: NetStrengthSyntax
    type: pyslang.parsing.Token
class ProceduralAssignStatementSyntax(StatementSyntax):
    expr: ExpressionSyntax
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class ProceduralBlockSyntax(MemberSyntax):
    keyword: pyslang.parsing.Token
    statement: StatementSyntax
class ProceduralDeassignStatementSyntax(StatementSyntax):
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    variable: ExpressionSyntax
class ProductionSyntax(SyntaxNode):
    colon: pyslang.parsing.Token
    dataType: DataTypeSyntax
    name: pyslang.parsing.Token
    portList: FunctionPortListSyntax
    rules: SeparatedSyntaxList
    semi: pyslang.parsing.Token
class PropertyCaseItemSyntax(SyntaxNode):
    pass
class PropertyDeclarationSyntax(MemberSyntax):
    end: pyslang.parsing.Token
    endBlockName: NamedBlockClauseSyntax
    keyword: pyslang.parsing.Token
    name: pyslang.parsing.Token
    optionalSemi: pyslang.parsing.Token
    portList: AssertionItemPortListSyntax
    propertySpec: PropertySpecSyntax
    semi: pyslang.parsing.Token
    variables: SyntaxList
class PropertyExprSyntax(SyntaxNode):
    pass
class PropertySpecSyntax(SyntaxNode):
    clocking: TimingControlSyntax
    disable: DisableIffSyntax
    expr: PropertyExprSyntax
class PullStrengthSyntax(NetStrengthSyntax):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    strength: pyslang.parsing.Token
class PulseStyleDeclarationSyntax(MemberSyntax):
    inputs: SeparatedSyntaxList
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class QueueDimensionSpecifierSyntax(DimensionSpecifierSyntax):
    dollar: pyslang.parsing.Token
    maxSizeClause: ColonExpressionClauseSyntax
class RandCaseItemSyntax(SyntaxNode):
    colon: pyslang.parsing.Token
    expr: ExpressionSyntax
    statement: StatementSyntax
class RandCaseStatementSyntax(StatementSyntax):
    endCase: pyslang.parsing.Token
    items: SyntaxList
    randCase: pyslang.parsing.Token
class RandJoinClauseSyntax(SyntaxNode):
    expr: ParenthesizedExpressionSyntax
    join: pyslang.parsing.Token
    rand: pyslang.parsing.Token
class RandSequenceStatementSyntax(StatementSyntax):
    closeParen: pyslang.parsing.Token
    endsequence: pyslang.parsing.Token
    firstProduction: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    productions: SyntaxList
    randsequence: pyslang.parsing.Token
class RangeCoverageBinInitializerSyntax(CoverageBinInitializerSyntax):
    ranges: RangeListSyntax
    withClause: WithClauseSyntax
class RangeDimensionSpecifierSyntax(DimensionSpecifierSyntax):
    selector: SelectorSyntax
class RangeListSyntax(SyntaxNode):
    closeBrace: pyslang.parsing.Token
    openBrace: pyslang.parsing.Token
    valueRanges: SeparatedSyntaxList
class RangeSelectSyntax(SelectorSyntax):
    left: ExpressionSyntax
    range: pyslang.parsing.Token
    right: ExpressionSyntax
class RepeatedEventControlSyntax(TimingControlSyntax):
    closeParen: pyslang.parsing.Token
    eventControl: TimingControlSyntax
    expr: ExpressionSyntax
    openParen: pyslang.parsing.Token
    repeat: pyslang.parsing.Token
class ReplicatedAssignmentPatternSyntax(AssignmentPatternSyntax):
    closeBrace: pyslang.parsing.Token
    countExpr: ExpressionSyntax
    innerCloseBrace: pyslang.parsing.Token
    innerOpenBrace: pyslang.parsing.Token
    items: SeparatedSyntaxList
    openBrace: pyslang.parsing.Token
class ReturnStatementSyntax(StatementSyntax):
    returnKeyword: pyslang.parsing.Token
    returnValue: ExpressionSyntax
    semi: pyslang.parsing.Token
class RsCaseItemSyntax(SyntaxNode):
    pass
class RsCaseSyntax(RsProdSyntax):
    closeParen: pyslang.parsing.Token
    endcase: pyslang.parsing.Token
    expr: ExpressionSyntax
    items: SyntaxList
    keyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class RsCodeBlockSyntax(RsProdSyntax):
    closeBrace: pyslang.parsing.Token
    items: SyntaxList
    openBrace: pyslang.parsing.Token
class RsElseClauseSyntax(SyntaxNode):
    item: RsProdItemSyntax
    keyword: pyslang.parsing.Token
class RsIfElseSyntax(RsProdSyntax):
    closeParen: pyslang.parsing.Token
    condition: ExpressionSyntax
    elseClause: RsElseClauseSyntax
    ifItem: RsProdItemSyntax
    keyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class RsProdItemSyntax(RsProdSyntax):
    argList: ArgumentListSyntax
    name: pyslang.parsing.Token
class RsProdSyntax(SyntaxNode):
    pass
class RsRepeatSyntax(RsProdSyntax):
    closeParen: pyslang.parsing.Token
    expr: ExpressionSyntax
    item: RsProdItemSyntax
    keyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class RsRuleSyntax(SyntaxNode):
    prods: SyntaxList
    randJoin: RandJoinClauseSyntax
    weightClause: RsWeightClauseSyntax
class RsWeightClauseSyntax(SyntaxNode):
    codeBlock: RsProdSyntax
    colonEqual: pyslang.parsing.Token
    weight: ExpressionSyntax
class ScopedNameSyntax(NameSyntax):
    left: NameSyntax
    right: NameSyntax
    separator: pyslang.parsing.Token
class SelectorSyntax(SyntaxNode):
    pass
class SequenceDeclarationSyntax(MemberSyntax):
    end: pyslang.parsing.Token
    endBlockName: NamedBlockClauseSyntax
    keyword: pyslang.parsing.Token
    name: pyslang.parsing.Token
    optionalSemi: pyslang.parsing.Token
    portList: AssertionItemPortListSyntax
    semi: pyslang.parsing.Token
    seqExpr: SequenceExprSyntax
    variables: SyntaxList
class SequenceExprSyntax(SyntaxNode):
    pass
class SequenceMatchListSyntax(SyntaxNode):
    comma: pyslang.parsing.Token
    items: SeparatedSyntaxList
class SequenceRepetitionSyntax(SyntaxNode):
    closeBracket: pyslang.parsing.Token
    op: pyslang.parsing.Token
    openBracket: pyslang.parsing.Token
    selector: SelectorSyntax
class SignalEventExpressionSyntax(EventExpressionSyntax):
    edge: pyslang.parsing.Token
    expr: ExpressionSyntax
    iffClause: IffEventClauseSyntax
class SignedCastExpressionSyntax(ExpressionSyntax):
    apostrophe: pyslang.parsing.Token
    inner: ParenthesizedExpressionSyntax
    signing: pyslang.parsing.Token
class SimpleAssignmentPatternSyntax(AssignmentPatternSyntax):
    closeBrace: pyslang.parsing.Token
    items: SeparatedSyntaxList
    openBrace: pyslang.parsing.Token
class SimpleBinsSelectExprSyntax(BinsSelectExpressionSyntax):
    expr: ExpressionSyntax
    matchesClause: MatchesClauseSyntax
class SimpleDirectiveSyntax(DirectiveSyntax):
    pass
class SimplePathSuffixSyntax(PathSuffixSyntax):
    outputs: SeparatedSyntaxList
class SimplePragmaExpressionSyntax(PragmaExpressionSyntax):
    value: pyslang.parsing.Token
class SimplePropertyExprSyntax(PropertyExprSyntax):
    expr: SequenceExprSyntax
class SimpleSequenceExprSyntax(SequenceExprSyntax):
    expr: ExpressionSyntax
    repetition: SequenceRepetitionSyntax
class SolveBeforeConstraintSyntax(ConstraintItemSyntax):
    afterExpr: SeparatedSyntaxList
    before: pyslang.parsing.Token
    beforeExpr: SeparatedSyntaxList
    semi: pyslang.parsing.Token
    solve: pyslang.parsing.Token
class SpecifyBlockSyntax(MemberSyntax):
    endspecify: pyslang.parsing.Token
    items: SyntaxList
    specify: pyslang.parsing.Token
class SpecparamDeclarationSyntax(MemberSyntax):
    declarators: SeparatedSyntaxList
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    type: ImplicitTypeSyntax
class SpecparamDeclaratorSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    comma: pyslang.parsing.Token
    equals: pyslang.parsing.Token
    name: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    value1: ExpressionSyntax
    value2: ExpressionSyntax
class StandardCaseItemSyntax(CaseItemSyntax):
    clause: SyntaxNode
    colon: pyslang.parsing.Token
    expressions: SeparatedSyntaxList
class StandardPropertyCaseItemSyntax(PropertyCaseItemSyntax):
    colon: pyslang.parsing.Token
    expr: PropertyExprSyntax
    expressions: SeparatedSyntaxList
    semi: pyslang.parsing.Token
class StandardRsCaseItemSyntax(RsCaseItemSyntax):
    colon: pyslang.parsing.Token
    expressions: SeparatedSyntaxList
    item: RsProdItemSyntax
    semi: pyslang.parsing.Token
class StatementSyntax(SyntaxNode):
    attributes: SyntaxList
    label: NamedLabelSyntax
class StreamExpressionSyntax(SyntaxNode):
    expression: ExpressionSyntax
    withRange: StreamExpressionWithRangeSyntax
class StreamExpressionWithRangeSyntax(SyntaxNode):
    range: ElementSelectSyntax
    withKeyword: pyslang.parsing.Token
class StreamingConcatenationExpressionSyntax(PrimaryExpressionSyntax):
    closeBrace: pyslang.parsing.Token
    expressions: SeparatedSyntaxList
    innerCloseBrace: pyslang.parsing.Token
    innerOpenBrace: pyslang.parsing.Token
    openBrace: pyslang.parsing.Token
    operatorToken: pyslang.parsing.Token
    sliceSize: ExpressionSyntax
class StrongWeakPropertyExprSyntax(PropertyExprSyntax):
    closeParen: pyslang.parsing.Token
    expr: SequenceExprSyntax
    keyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
class StructUnionMemberSyntax(SyntaxNode):
    attributes: SyntaxList
    declarators: SeparatedSyntaxList
    randomQualifier: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    type: DataTypeSyntax
class StructUnionTypeSyntax(DataTypeSyntax):
    closeBrace: pyslang.parsing.Token
    dimensions: SyntaxList
    keyword: pyslang.parsing.Token
    members: SyntaxList
    openBrace: pyslang.parsing.Token
    packed: pyslang.parsing.Token
    signing: pyslang.parsing.Token
    taggedOrSoft: pyslang.parsing.Token
class StructurePatternMemberSyntax(SyntaxNode):
    pass
class StructurePatternSyntax(PatternSyntax):
    closeBrace: pyslang.parsing.Token
    members: SeparatedSyntaxList
    openBrace: pyslang.parsing.Token
class StructuredAssignmentPatternSyntax(AssignmentPatternSyntax):
    closeBrace: pyslang.parsing.Token
    items: SeparatedSyntaxList
    openBrace: pyslang.parsing.Token
class SuperNewDefaultedArgsExpressionSyntax(ExpressionSyntax):
    closeParen: pyslang.parsing.Token
    defaultKeyword: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    scopedNew: NameSyntax
class SyntaxFactory:
    """
    Factory for creating syntax nodes. Access via SyntaxRewriter.factory.
    """
    def acceptOnPropertyExpr(self, keyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, condition: ExpressionSyntax, closeParen: pyslang.parsing.Token, expr: PropertyExprSyntax) -> AcceptOnPropertyExprSyntax:
        ...
    def actionBlock(self, statement: StatementSyntax = None, elseClause: ElseClauseSyntax = None) -> ActionBlockSyntax:
        ...
    def anonymousProgram(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, semi: pyslang.parsing.Token, members: SyntaxList, endkeyword: pyslang.parsing.Token) -> AnonymousProgramSyntax:
        ...
    def ansiPortList(self, openParen: pyslang.parsing.Token, ports: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> AnsiPortListSyntax:
        ...
    def ansiUdpPortList(self, openParen: pyslang.parsing.Token, ports: SeparatedSyntaxList, closeParen: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> AnsiUdpPortListSyntax:
        ...
    def argumentList(self, openParen: pyslang.parsing.Token, parameters: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> ArgumentListSyntax:
        ...
    def arrayOrRandomizeMethodExpression(self, method: ExpressionSyntax, with: pyslang.parsing.Token, args: ParenExpressionListSyntax = None, constraints: ConstraintBlockSyntax = None) -> ArrayOrRandomizeMethodExpressionSyntax:
        ...
    def assertionItemPort(self, attributes: SyntaxList, local: pyslang.parsing.Token, direction: pyslang.parsing.Token, type: DataTypeSyntax, name: pyslang.parsing.Token, dimensions: SyntaxList, defaultValue: EqualsAssertionArgClauseSyntax = None) -> AssertionItemPortSyntax:
        ...
    def assertionItemPortList(self, openParen: pyslang.parsing.Token, ports: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> AssertionItemPortListSyntax:
        ...
    def assignmentPatternExpression(self, type: DataTypeSyntax = None, pattern: AssignmentPatternSyntax) -> AssignmentPatternExpressionSyntax:
        ...
    def assignmentPatternItem(self, key: ExpressionSyntax, colon: pyslang.parsing.Token, expr: ExpressionSyntax) -> AssignmentPatternItemSyntax:
        ...
    def attributeInstance(self, openParen: pyslang.parsing.Token, openStar: pyslang.parsing.Token, specs: SeparatedSyntaxList, closeStar: pyslang.parsing.Token, closeParen: pyslang.parsing.Token) -> AttributeInstanceSyntax:
        ...
    def attributeSpec(self, name: pyslang.parsing.Token, value: EqualsValueClauseSyntax = None) -> AttributeSpecSyntax:
        ...
    def badExpression(self, expr: ExpressionSyntax) -> BadExpressionSyntax:
        ...
    def beginKeywordsDirective(self, directive: pyslang.parsing.Token, versionSpecifier: pyslang.parsing.Token) -> BeginKeywordsDirectiveSyntax:
        ...
    def binSelectWithFilterExpr(self, expr: BinsSelectExpressionSyntax, with: pyslang.parsing.Token, openParen: pyslang.parsing.Token, filter: ExpressionSyntax, closeParen: pyslang.parsing.Token, matchesClause: MatchesClauseSyntax = None) -> BinSelectWithFilterExprSyntax:
        ...
    def binaryBinsSelectExpr(self, left: BinsSelectExpressionSyntax, op: pyslang.parsing.Token, right: BinsSelectExpressionSyntax) -> BinaryBinsSelectExprSyntax:
        ...
    def binaryBlockEventExpression(self, left: BlockEventExpressionSyntax, orKeyword: pyslang.parsing.Token, right: BlockEventExpressionSyntax) -> BinaryBlockEventExpressionSyntax:
        ...
    def binaryConditionalDirectiveExpression(self, left: ConditionalDirectiveExpressionSyntax, op: pyslang.parsing.Token, right: ConditionalDirectiveExpressionSyntax) -> BinaryConditionalDirectiveExpressionSyntax:
        ...
    def binaryEventExpression(self, left: EventExpressionSyntax, operatorToken: pyslang.parsing.Token, right: EventExpressionSyntax) -> BinaryEventExpressionSyntax:
        ...
    def binaryExpression(self, kind: SyntaxKind, left: ExpressionSyntax, operatorToken: pyslang.parsing.Token, attributes: SyntaxList, right: ExpressionSyntax) -> BinaryExpressionSyntax:
        ...
    def binaryPropertyExpr(self, kind: SyntaxKind, left: PropertyExprSyntax, op: pyslang.parsing.Token, right: PropertyExprSyntax) -> BinaryPropertyExprSyntax:
        ...
    def binarySequenceExpr(self, kind: SyntaxKind, left: SequenceExprSyntax, op: pyslang.parsing.Token, right: SequenceExprSyntax) -> BinarySequenceExprSyntax:
        ...
    def bindDirective(self, attributes: SyntaxList, bind: pyslang.parsing.Token, target: NameSyntax, targetInstances: BindTargetListSyntax = None, instantiation: MemberSyntax) -> BindDirectiveSyntax:
        ...
    def bindTargetList(self, colon: pyslang.parsing.Token, targets: SeparatedSyntaxList) -> BindTargetListSyntax:
        ...
    def binsSelectConditionExpr(self, binsof: pyslang.parsing.Token, openParen: pyslang.parsing.Token, name: NameSyntax, closeParen: pyslang.parsing.Token, intersects: IntersectClauseSyntax = None) -> BinsSelectConditionExprSyntax:
        ...
    def binsSelection(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, name: pyslang.parsing.Token, equals: pyslang.parsing.Token, expr: BinsSelectExpressionSyntax, iff: CoverageIffClauseSyntax = None, semi: pyslang.parsing.Token) -> BinsSelectionSyntax:
        ...
    def bitSelect(self, expr: ExpressionSyntax) -> BitSelectSyntax:
        ...
    def blockCoverageEvent(self, atat: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: BlockEventExpressionSyntax, closeParen: pyslang.parsing.Token) -> BlockCoverageEventSyntax:
        ...
    def blockStatement(self, kind: SyntaxKind, label: NamedLabelSyntax = None, attributes: SyntaxList, begin: pyslang.parsing.Token, blockName: NamedBlockClauseSyntax = None, items: SyntaxList, end: pyslang.parsing.Token, endBlockName: NamedBlockClauseSyntax = None) -> BlockStatementSyntax:
        ...
    def caseGenerate(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, condition: ExpressionSyntax, closeParen: pyslang.parsing.Token, items: SyntaxList, endCase: pyslang.parsing.Token) -> CaseGenerateSyntax:
        ...
    def casePropertyExpr(self, caseKeyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token, items: SyntaxList, endcase: pyslang.parsing.Token) -> CasePropertyExprSyntax:
        ...
    def caseStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, uniqueOrPriority: pyslang.parsing.Token, caseKeyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token, matchesOrInside: pyslang.parsing.Token, items: SyntaxList, endcase: pyslang.parsing.Token) -> CaseStatementSyntax:
        ...
    def castExpression(self, left: ExpressionSyntax, apostrophe: pyslang.parsing.Token, right: ParenthesizedExpressionSyntax) -> CastExpressionSyntax:
        ...
    def cellConfigRule(self, cell: pyslang.parsing.Token, name: ConfigCellIdentifierSyntax, ruleClause: ConfigRuleClauseSyntax, semi: pyslang.parsing.Token) -> CellConfigRuleSyntax:
        ...
    def chargeStrength(self, openParen: pyslang.parsing.Token, strength: pyslang.parsing.Token, closeParen: pyslang.parsing.Token) -> ChargeStrengthSyntax:
        ...
    def checkerDataDeclaration(self, attributes: SyntaxList, rand: pyslang.parsing.Token, data: DataDeclarationSyntax) -> CheckerDataDeclarationSyntax:
        ...
    def checkerDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, name: pyslang.parsing.Token, portList: AssertionItemPortListSyntax = None, semi: pyslang.parsing.Token, members: SyntaxList, end: pyslang.parsing.Token, endBlockName: NamedBlockClauseSyntax = None) -> CheckerDeclarationSyntax:
        ...
    def checkerInstanceStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, instance: CheckerInstantiationSyntax) -> CheckerInstanceStatementSyntax:
        ...
    def checkerInstantiation(self, attributes: SyntaxList, type: NameSyntax, parameters: ParameterValueAssignmentSyntax = None, instances: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> CheckerInstantiationSyntax:
        ...
    def classDeclaration(self, attributes: SyntaxList, virtualOrInterface: pyslang.parsing.Token, classKeyword: pyslang.parsing.Token, finalSpecifier: ClassSpecifierSyntax = None, name: pyslang.parsing.Token, parameters: ParameterPortListSyntax = None, extendsClause: ExtendsClauseSyntax = None, implementsClause: ImplementsClauseSyntax = None, semi: pyslang.parsing.Token, items: SyntaxList, endClass: pyslang.parsing.Token, endBlockName: NamedBlockClauseSyntax = None) -> ClassDeclarationSyntax:
        ...
    def classMethodDeclaration(self, attributes: SyntaxList, qualifiers: TokenList, declaration: FunctionDeclarationSyntax) -> ClassMethodDeclarationSyntax:
        ...
    def classMethodPrototype(self, attributes: SyntaxList, qualifiers: TokenList, prototype: FunctionPrototypeSyntax, semi: pyslang.parsing.Token) -> ClassMethodPrototypeSyntax:
        ...
    def className(self, identifier: pyslang.parsing.Token, parameters: ParameterValueAssignmentSyntax) -> ClassNameSyntax:
        ...
    def classPropertyDeclaration(self, attributes: SyntaxList, qualifiers: TokenList, declaration: MemberSyntax) -> ClassPropertyDeclarationSyntax:
        ...
    def classSpecifier(self, colon: pyslang.parsing.Token, keyword: pyslang.parsing.Token) -> ClassSpecifierSyntax:
        ...
    def clockingDeclaration(self, attributes: SyntaxList, globalOrDefault: pyslang.parsing.Token, clocking: pyslang.parsing.Token, blockName: pyslang.parsing.Token, at: pyslang.parsing.Token, event: EventExpressionSyntax, semi: pyslang.parsing.Token, items: SyntaxList, endClocking: pyslang.parsing.Token, endBlockName: NamedBlockClauseSyntax = None) -> ClockingDeclarationSyntax:
        ...
    def clockingDirection(self, input: pyslang.parsing.Token, inputSkew: ClockingSkewSyntax = None, output: pyslang.parsing.Token, outputSkew: ClockingSkewSyntax = None) -> ClockingDirectionSyntax:
        ...
    def clockingItem(self, attributes: SyntaxList, direction: ClockingDirectionSyntax, decls: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> ClockingItemSyntax:
        ...
    def clockingPropertyExpr(self, event: TimingControlSyntax, expr: PropertyExprSyntax = None) -> ClockingPropertyExprSyntax:
        ...
    def clockingSequenceExpr(self, event: TimingControlSyntax, expr: SequenceExprSyntax) -> ClockingSequenceExprSyntax:
        ...
    def clockingSkew(self, edge: pyslang.parsing.Token, delay: TimingControlSyntax = None) -> ClockingSkewSyntax:
        ...
    def colonExpressionClause(self, colon: pyslang.parsing.Token, expr: ExpressionSyntax) -> ColonExpressionClauseSyntax:
        ...
    def compilationUnit(self, members: SyntaxList, endOfFile: pyslang.parsing.Token) -> CompilationUnitSyntax:
        ...
    def concatenationExpression(self, openBrace: pyslang.parsing.Token, expressions: SeparatedSyntaxList, closeBrace: pyslang.parsing.Token) -> ConcatenationExpressionSyntax:
        ...
    def concurrentAssertionMember(self, attributes: SyntaxList, statement: ConcurrentAssertionStatementSyntax) -> ConcurrentAssertionMemberSyntax:
        ...
    def concurrentAssertionStatement(self, kind: SyntaxKind, label: NamedLabelSyntax = None, attributes: SyntaxList, keyword: pyslang.parsing.Token, propertyOrSequence: pyslang.parsing.Token, openParen: pyslang.parsing.Token, propertySpec: PropertySpecSyntax, closeParen: pyslang.parsing.Token, action: ActionBlockSyntax) -> ConcurrentAssertionStatementSyntax:
        ...
    def conditionalBranchDirective(self, kind: SyntaxKind, directive: pyslang.parsing.Token, expr: ConditionalDirectiveExpressionSyntax, disabledTokens: TokenList) -> ConditionalBranchDirectiveSyntax:
        ...
    def conditionalConstraint(self, ifKeyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, condition: ExpressionSyntax, closeParen: pyslang.parsing.Token, constraints: ConstraintItemSyntax, elseClause: ElseConstraintClauseSyntax = None) -> ConditionalConstraintSyntax:
        ...
    def conditionalExpression(self, predicate: ConditionalPredicateSyntax, question: pyslang.parsing.Token, attributes: SyntaxList, left: ExpressionSyntax, colon: pyslang.parsing.Token, right: ExpressionSyntax) -> ConditionalExpressionSyntax:
        ...
    def conditionalPathDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, predicate: ExpressionSyntax, closeParen: pyslang.parsing.Token, path: PathDeclarationSyntax) -> ConditionalPathDeclarationSyntax:
        ...
    def conditionalPattern(self, expr: ExpressionSyntax, matchesClause: MatchesClauseSyntax = None) -> ConditionalPatternSyntax:
        ...
    def conditionalPredicate(self, conditions: SeparatedSyntaxList) -> ConditionalPredicateSyntax:
        ...
    def conditionalPropertyExpr(self, ifKeyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, condition: ExpressionSyntax, closeParen: pyslang.parsing.Token, expr: PropertyExprSyntax, elseClause: ElsePropertyClauseSyntax = None) -> ConditionalPropertyExprSyntax:
        ...
    def conditionalStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, uniqueOrPriority: pyslang.parsing.Token, ifKeyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, predicate: ConditionalPredicateSyntax, closeParen: pyslang.parsing.Token, statement: StatementSyntax, elseClause: ElseClauseSyntax = None) -> ConditionalStatementSyntax:
        ...
    def configCellIdentifier(self, library: pyslang.parsing.Token, dot: pyslang.parsing.Token, cell: pyslang.parsing.Token) -> ConfigCellIdentifierSyntax:
        ...
    def configDeclaration(self, attributes: SyntaxList, config: pyslang.parsing.Token, name: pyslang.parsing.Token, semi1: pyslang.parsing.Token, localparams: SyntaxList, design: pyslang.parsing.Token, topCells: SyntaxList, semi2: pyslang.parsing.Token, rules: SyntaxList, endconfig: pyslang.parsing.Token, blockName: NamedBlockClauseSyntax = None) -> ConfigDeclarationSyntax:
        ...
    def configInstanceIdentifier(self, dot: pyslang.parsing.Token, name: pyslang.parsing.Token) -> ConfigInstanceIdentifierSyntax:
        ...
    def configLiblist(self, liblist: pyslang.parsing.Token, libraries: TokenList) -> ConfigLiblistSyntax:
        ...
    def configUseClause(self, use: pyslang.parsing.Token, name: ConfigCellIdentifierSyntax = None, paramAssignments: ParameterValueAssignmentSyntax = None, colon: pyslang.parsing.Token, config: pyslang.parsing.Token) -> ConfigUseClauseSyntax:
        ...
    def constraintBlock(self, openBrace: pyslang.parsing.Token, items: SyntaxList, closeBrace: pyslang.parsing.Token) -> ConstraintBlockSyntax:
        ...
    def constraintDeclaration(self, attributes: SyntaxList, qualifiers: TokenList, keyword: pyslang.parsing.Token, specifiers: SyntaxList, name: NameSyntax, block: ConstraintBlockSyntax) -> ConstraintDeclarationSyntax:
        ...
    def constraintPrototype(self, attributes: SyntaxList, qualifiers: TokenList, keyword: pyslang.parsing.Token, specifiers: SyntaxList, name: NameSyntax, semi: pyslang.parsing.Token) -> ConstraintPrototypeSyntax:
        ...
    def continuousAssign(self, attributes: SyntaxList, assign: pyslang.parsing.Token, strength: DriveStrengthSyntax = None, delay: TimingControlSyntax = None, assignments: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> ContinuousAssignSyntax:
        ...
    def copyClassExpression(self, scopedNew: NameSyntax, expr: ExpressionSyntax) -> CopyClassExpressionSyntax:
        ...
    def coverCross(self, attributes: SyntaxList, label: NamedLabelSyntax = None, cross: pyslang.parsing.Token, items: SeparatedSyntaxList, iff: CoverageIffClauseSyntax = None, openBrace: pyslang.parsing.Token, members: SyntaxList, closeBrace: pyslang.parsing.Token, emptySemi: pyslang.parsing.Token) -> CoverCrossSyntax:
        ...
    def coverageBins(self, attributes: SyntaxList, wildcard: pyslang.parsing.Token, keyword: pyslang.parsing.Token, name: pyslang.parsing.Token, size: CoverageBinsArraySizeSyntax = None, equals: pyslang.parsing.Token, initializer: CoverageBinInitializerSyntax, iff: CoverageIffClauseSyntax = None, semi: pyslang.parsing.Token) -> CoverageBinsSyntax:
        ...
    def coverageBinsArraySize(self, openBracket: pyslang.parsing.Token, expr: ExpressionSyntax = None, closeBracket: pyslang.parsing.Token) -> CoverageBinsArraySizeSyntax:
        ...
    def coverageIffClause(self, iff: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token) -> CoverageIffClauseSyntax:
        ...
    def coverageOption(self, attributes: SyntaxList, expr: ExpressionSyntax, semi: pyslang.parsing.Token) -> CoverageOptionSyntax:
        ...
    def covergroupDeclaration(self, attributes: SyntaxList, covergroup: pyslang.parsing.Token, extends: pyslang.parsing.Token, name: pyslang.parsing.Token, portList: FunctionPortListSyntax = None, event: SyntaxNode = None, semi: pyslang.parsing.Token, members: SyntaxList, endgroup: pyslang.parsing.Token, endBlockName: NamedBlockClauseSyntax = None) -> CovergroupDeclarationSyntax:
        ...
    def coverpoint(self, attributes: SyntaxList, type: DataTypeSyntax, label: NamedLabelSyntax = None, coverpoint: pyslang.parsing.Token, expr: ExpressionSyntax, iff: CoverageIffClauseSyntax = None, openBrace: pyslang.parsing.Token, members: SyntaxList, closeBrace: pyslang.parsing.Token, emptySemi: pyslang.parsing.Token) -> CoverpointSyntax:
        ...
    def dPIExport(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, specString: pyslang.parsing.Token, c_identifier: pyslang.parsing.Token, equals: pyslang.parsing.Token, functionOrTask: pyslang.parsing.Token, name: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> DPIExportSyntax:
        ...
    def dPIImport(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, specString: pyslang.parsing.Token, property: pyslang.parsing.Token, c_identifier: pyslang.parsing.Token, equals: pyslang.parsing.Token, method: FunctionPrototypeSyntax, semi: pyslang.parsing.Token) -> DPIImportSyntax:
        ...
    def dataDeclaration(self, attributes: SyntaxList, modifiers: TokenList, type: DataTypeSyntax, declarators: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> DataDeclarationSyntax:
        ...
    def declarator(self, name: pyslang.parsing.Token, dimensions: SyntaxList, initializer: EqualsValueClauseSyntax = None) -> DeclaratorSyntax:
        ...
    def defParam(self, attributes: SyntaxList, defparam: pyslang.parsing.Token, assignments: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> DefParamSyntax:
        ...
    def defParamAssignment(self, name: NameSyntax, setter: EqualsValueClauseSyntax) -> DefParamAssignmentSyntax:
        ...
    def defaultCaseItem(self, defaultKeyword: pyslang.parsing.Token, colon: pyslang.parsing.Token, clause: SyntaxNode) -> DefaultCaseItemSyntax:
        ...
    def defaultClockingReference(self, attributes: SyntaxList, defaultKeyword: pyslang.parsing.Token, clocking: pyslang.parsing.Token, name: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> DefaultClockingReferenceSyntax:
        ...
    def defaultConfigRule(self, defaultKeyword: pyslang.parsing.Token, liblist: ConfigLiblistSyntax, semi: pyslang.parsing.Token) -> DefaultConfigRuleSyntax:
        ...
    def defaultCoverageBinInitializer(self, defaultKeyword: pyslang.parsing.Token, sequenceKeyword: pyslang.parsing.Token) -> DefaultCoverageBinInitializerSyntax:
        ...
    def defaultDecayTimeDirective(self, directive: pyslang.parsing.Token, time: pyslang.parsing.Token) -> DefaultDecayTimeDirectiveSyntax:
        ...
    def defaultDisableDeclaration(self, attributes: SyntaxList, defaultKeyword: pyslang.parsing.Token, disableKeyword: pyslang.parsing.Token, iffKeyword: pyslang.parsing.Token, expr: ExpressionSyntax, semi: pyslang.parsing.Token) -> DefaultDisableDeclarationSyntax:
        ...
    def defaultDistItem(self, defaultKeyword: pyslang.parsing.Token, weight: DistWeightSyntax = None) -> DefaultDistItemSyntax:
        ...
    def defaultExtendsClauseArg(self, openParen: pyslang.parsing.Token, defaultKeyword: pyslang.parsing.Token, closeParen: pyslang.parsing.Token) -> DefaultExtendsClauseArgSyntax:
        ...
    def defaultFunctionPort(self, keyword: pyslang.parsing.Token) -> DefaultFunctionPortSyntax:
        ...
    def defaultNetTypeDirective(self, directive: pyslang.parsing.Token, netType: pyslang.parsing.Token) -> DefaultNetTypeDirectiveSyntax:
        ...
    def defaultPropertyCaseItem(self, defaultKeyword: pyslang.parsing.Token, colon: pyslang.parsing.Token, expr: PropertyExprSyntax, semi: pyslang.parsing.Token) -> DefaultPropertyCaseItemSyntax:
        ...
    def defaultRsCaseItem(self, defaultKeyword: pyslang.parsing.Token, colon: pyslang.parsing.Token, item: RsProdItemSyntax, semi: pyslang.parsing.Token) -> DefaultRsCaseItemSyntax:
        ...
    def defaultSkewItem(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, direction: ClockingDirectionSyntax, semi: pyslang.parsing.Token) -> DefaultSkewItemSyntax:
        ...
    def defaultTriregStrengthDirective(self, directive: pyslang.parsing.Token, strength: pyslang.parsing.Token) -> DefaultTriregStrengthDirectiveSyntax:
        ...
    def deferredAssertion(self, hash: pyslang.parsing.Token, zero: pyslang.parsing.Token, finalKeyword: pyslang.parsing.Token) -> DeferredAssertionSyntax:
        ...
    def defineDirective(self, directive: pyslang.parsing.Token, name: pyslang.parsing.Token, formalArguments: MacroFormalArgumentListSyntax = None, body: TokenList) -> DefineDirectiveSyntax:
        ...
    def delay(self, kind: SyntaxKind, hash: pyslang.parsing.Token, delayValue: ExpressionSyntax) -> DelaySyntax:
        ...
    def delay3(self, hash: pyslang.parsing.Token, openParen: pyslang.parsing.Token, delay1: ExpressionSyntax, comma1: pyslang.parsing.Token, delay2: ExpressionSyntax = None, comma2: pyslang.parsing.Token, delay3: ExpressionSyntax = None, closeParen: pyslang.parsing.Token) -> Delay3Syntax:
        ...
    def delayedSequenceElement(self, doubleHash: pyslang.parsing.Token, delayVal: ExpressionSyntax = None, openBracket: pyslang.parsing.Token, op: pyslang.parsing.Token, range: SelectorSyntax = None, closeBracket: pyslang.parsing.Token, expr: SequenceExprSyntax) -> DelayedSequenceElementSyntax:
        ...
    def delayedSequenceExpr(self, first: SequenceExprSyntax = None, elements: SyntaxList) -> DelayedSequenceExprSyntax:
        ...
    def disableConstraint(self, disable: pyslang.parsing.Token, soft: pyslang.parsing.Token, name: ExpressionSyntax, semi: pyslang.parsing.Token) -> DisableConstraintSyntax:
        ...
    def disableForkStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, disable: pyslang.parsing.Token, fork: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> DisableForkStatementSyntax:
        ...
    def disableIff(self, disable: pyslang.parsing.Token, iff: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token) -> DisableIffSyntax:
        ...
    def disableStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, disable: pyslang.parsing.Token, name: NameSyntax, semi: pyslang.parsing.Token) -> DisableStatementSyntax:
        ...
    def distConstraintList(self, dist: pyslang.parsing.Token, openBrace: pyslang.parsing.Token, items: SeparatedSyntaxList, closeBrace: pyslang.parsing.Token) -> DistConstraintListSyntax:
        ...
    def distItem(self, range: ExpressionSyntax, weight: DistWeightSyntax = None) -> DistItemSyntax:
        ...
    def distWeight(self, op: pyslang.parsing.Token, extraOp: pyslang.parsing.Token, expr: ExpressionSyntax) -> DistWeightSyntax:
        ...
    def dividerClause(self, divide: pyslang.parsing.Token, value: pyslang.parsing.Token) -> DividerClauseSyntax:
        ...
    def doWhileStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, doKeyword: pyslang.parsing.Token, statement: StatementSyntax, whileKeyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> DoWhileStatementSyntax:
        ...
    def dotMemberClause(self, dot: pyslang.parsing.Token, member: pyslang.parsing.Token) -> DotMemberClauseSyntax:
        ...
    def driveStrength(self, openParen: pyslang.parsing.Token, strength0: pyslang.parsing.Token, comma: pyslang.parsing.Token, strength1: pyslang.parsing.Token, closeParen: pyslang.parsing.Token) -> DriveStrengthSyntax:
        ...
    def edgeControlSpecifier(self, openBracket: pyslang.parsing.Token, descriptors: SeparatedSyntaxList, closeBracket: pyslang.parsing.Token) -> EdgeControlSpecifierSyntax:
        ...
    def edgeDescriptor(self, t1: pyslang.parsing.Token, t2: pyslang.parsing.Token) -> EdgeDescriptorSyntax:
        ...
    def edgeSensitivePathSuffix(self, openParen: pyslang.parsing.Token, outputs: SeparatedSyntaxList, polarityOperator: pyslang.parsing.Token, colon: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token) -> EdgeSensitivePathSuffixSyntax:
        ...
    def elabSystemTask(self, attributes: SyntaxList, name: pyslang.parsing.Token, arguments: ArgumentListSyntax = None, semi: pyslang.parsing.Token) -> ElabSystemTaskSyntax:
        ...
    def elementSelect(self, openBracket: pyslang.parsing.Token, selector: SelectorSyntax = None, closeBracket: pyslang.parsing.Token) -> ElementSelectSyntax:
        ...
    def elementSelectExpression(self, left: ExpressionSyntax, select: ElementSelectSyntax) -> ElementSelectExpressionSyntax:
        ...
    def elseClause(self, elseKeyword: pyslang.parsing.Token, clause: SyntaxNode) -> ElseClauseSyntax:
        ...
    def elseConstraintClause(self, elseKeyword: pyslang.parsing.Token, constraints: ConstraintItemSyntax) -> ElseConstraintClauseSyntax:
        ...
    def elsePropertyClause(self, elseKeyword: pyslang.parsing.Token, expr: PropertyExprSyntax) -> ElsePropertyClauseSyntax:
        ...
    def emptyArgument(self, placeholder: pyslang.parsing.Token) -> EmptyArgumentSyntax:
        ...
    def emptyIdentifierName(self, placeholder: pyslang.parsing.Token) -> EmptyIdentifierNameSyntax:
        ...
    def emptyMember(self, attributes: SyntaxList, qualifiers: TokenList, semi: pyslang.parsing.Token) -> EmptyMemberSyntax:
        ...
    def emptyNonAnsiPort(self, placeholder: pyslang.parsing.Token) -> EmptyNonAnsiPortSyntax:
        ...
    def emptyPortConnection(self, attributes: SyntaxList, placeholder: pyslang.parsing.Token) -> EmptyPortConnectionSyntax:
        ...
    def emptyQueueExpression(self, openBrace: pyslang.parsing.Token, closeBrace: pyslang.parsing.Token) -> EmptyQueueExpressionSyntax:
        ...
    def emptyStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, semicolon: pyslang.parsing.Token) -> EmptyStatementSyntax:
        ...
    def emptyTimingCheckArg(self, placeholder: pyslang.parsing.Token) -> EmptyTimingCheckArgSyntax:
        ...
    def enumType(self, keyword: pyslang.parsing.Token, baseType: DataTypeSyntax = None, openBrace: pyslang.parsing.Token, members: SeparatedSyntaxList, closeBrace: pyslang.parsing.Token, dimensions: SyntaxList) -> EnumTypeSyntax:
        ...
    def equalsAssertionArgClause(self, equals: pyslang.parsing.Token, expr: PropertyExprSyntax) -> EqualsAssertionArgClauseSyntax:
        ...
    def equalsTypeClause(self, equals: pyslang.parsing.Token, type: DataTypeSyntax) -> EqualsTypeClauseSyntax:
        ...
    def equalsValueClause(self, equals: pyslang.parsing.Token, expr: ExpressionSyntax) -> EqualsValueClauseSyntax:
        ...
    def eventControl(self, at: pyslang.parsing.Token, eventName: ExpressionSyntax) -> EventControlSyntax:
        ...
    def eventControlWithExpression(self, at: pyslang.parsing.Token, expr: EventExpressionSyntax) -> EventControlWithExpressionSyntax:
        ...
    def eventTriggerStatement(self, kind: SyntaxKind, label: NamedLabelSyntax = None, attributes: SyntaxList, trigger: pyslang.parsing.Token, timing: TimingControlSyntax = None, name: NameSyntax, semi: pyslang.parsing.Token) -> EventTriggerStatementSyntax:
        ...
    def explicitAnsiPort(self, attributes: SyntaxList, direction: pyslang.parsing.Token, dot: pyslang.parsing.Token, name: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax = None, closeParen: pyslang.parsing.Token) -> ExplicitAnsiPortSyntax:
        ...
    def explicitNonAnsiPort(self, dot: pyslang.parsing.Token, name: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: PortExpressionSyntax = None, closeParen: pyslang.parsing.Token) -> ExplicitNonAnsiPortSyntax:
        ...
    def expressionConstraint(self, soft: pyslang.parsing.Token, expr: ExpressionSyntax, semi: pyslang.parsing.Token) -> ExpressionConstraintSyntax:
        ...
    def expressionCoverageBinInitializer(self, expr: ExpressionSyntax) -> ExpressionCoverageBinInitializerSyntax:
        ...
    def expressionOrDist(self, expr: ExpressionSyntax, distribution: DistConstraintListSyntax) -> ExpressionOrDistSyntax:
        ...
    def expressionPattern(self, expr: ExpressionSyntax) -> ExpressionPatternSyntax:
        ...
    def expressionStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, expr: ExpressionSyntax, semi: pyslang.parsing.Token) -> ExpressionStatementSyntax:
        ...
    def expressionTimingCheckArg(self, expr: ExpressionSyntax) -> ExpressionTimingCheckArgSyntax:
        ...
    def extendsClause(self, keyword: pyslang.parsing.Token, baseName: NameSyntax, arguments: ArgumentListSyntax = None, defaultedArg: DefaultExtendsClauseArgSyntax = None) -> ExtendsClauseSyntax:
        ...
    def externInterfaceMethod(self, attributes: SyntaxList, externKeyword: pyslang.parsing.Token, forkJoin: pyslang.parsing.Token, prototype: FunctionPrototypeSyntax, semi: pyslang.parsing.Token) -> ExternInterfaceMethodSyntax:
        ...
    def externModuleDecl(self, attributes: SyntaxList, externKeyword: pyslang.parsing.Token, actualAttributes: SyntaxList, header: ModuleHeaderSyntax) -> ExternModuleDeclSyntax:
        ...
    def externUdpDecl(self, attributes: SyntaxList, externKeyword: pyslang.parsing.Token, actualAttributes: SyntaxList, primitive: pyslang.parsing.Token, name: pyslang.parsing.Token, portList: UdpPortListSyntax) -> ExternUdpDeclSyntax:
        ...
    def filePathSpec(self, path: pyslang.parsing.Token) -> FilePathSpecSyntax:
        ...
    def firstMatchSequenceExpr(self, first_match: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: SequenceExprSyntax, matchList: SequenceMatchListSyntax = None, closeParen: pyslang.parsing.Token) -> FirstMatchSequenceExprSyntax:
        ...
    def forLoopStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, forKeyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, initializers: SeparatedSyntaxList, semi1: pyslang.parsing.Token, stopExpr: ExpressionSyntax = None, semi2: pyslang.parsing.Token, steps: SeparatedSyntaxList, closeParen: pyslang.parsing.Token, statement: StatementSyntax) -> ForLoopStatementSyntax:
        ...
    def forVariableDeclaration(self, varKeyword: pyslang.parsing.Token, type: DataTypeSyntax = None, declarator: DeclaratorSyntax) -> ForVariableDeclarationSyntax:
        ...
    def foreachLoopList(self, openParen: pyslang.parsing.Token, arrayName: ExpressionSyntax, openBracket: pyslang.parsing.Token, loopVariables: SeparatedSyntaxList, closeBracket: pyslang.parsing.Token, closeParen: pyslang.parsing.Token) -> ForeachLoopListSyntax:
        ...
    def foreachLoopStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, keyword: pyslang.parsing.Token, loopList: ForeachLoopListSyntax, statement: StatementSyntax) -> ForeachLoopStatementSyntax:
        ...
    def foreverStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, foreverKeyword: pyslang.parsing.Token, statement: StatementSyntax) -> ForeverStatementSyntax:
        ...
    def forwardTypeRestriction(self, keyword1: pyslang.parsing.Token, keyword2: pyslang.parsing.Token) -> ForwardTypeRestrictionSyntax:
        ...
    def forwardTypedefDeclaration(self, attributes: SyntaxList, typedefKeyword: pyslang.parsing.Token, typeRestriction: ForwardTypeRestrictionSyntax = None, name: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> ForwardTypedefDeclarationSyntax:
        ...
    def functionDeclaration(self, kind: SyntaxKind, attributes: SyntaxList, prototype: FunctionPrototypeSyntax, semi: pyslang.parsing.Token, items: SyntaxList, end: pyslang.parsing.Token, endBlockName: NamedBlockClauseSyntax = None) -> FunctionDeclarationSyntax:
        ...
    def functionPort(self, attributes: SyntaxList, constKeyword: pyslang.parsing.Token, direction: pyslang.parsing.Token, staticKeyword: pyslang.parsing.Token, varKeyword: pyslang.parsing.Token, dataType: DataTypeSyntax = None, declarator: DeclaratorSyntax) -> FunctionPortSyntax:
        ...
    def functionPortList(self, openParen: pyslang.parsing.Token, ports: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> FunctionPortListSyntax:
        ...
    def functionPrototype(self, keyword: pyslang.parsing.Token, specifiers: SyntaxList, lifetime: pyslang.parsing.Token, returnType: DataTypeSyntax, name: NameSyntax, portList: FunctionPortListSyntax = None) -> FunctionPrototypeSyntax:
        ...
    def generateBlock(self, attributes: SyntaxList, label: NamedLabelSyntax = None, begin: pyslang.parsing.Token, beginName: NamedBlockClauseSyntax = None, members: SyntaxList, end: pyslang.parsing.Token, endName: NamedBlockClauseSyntax = None) -> GenerateBlockSyntax:
        ...
    def generateRegion(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, members: SyntaxList, endgenerate: pyslang.parsing.Token) -> GenerateRegionSyntax:
        ...
    def genvarDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, identifiers: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> GenvarDeclarationSyntax:
        ...
    def hierarchicalInstance(self, decl: InstanceNameSyntax = None, openParen: pyslang.parsing.Token, connections: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> HierarchicalInstanceSyntax:
        ...
    def hierarchyInstantiation(self, attributes: SyntaxList, type: pyslang.parsing.Token, parameters: ParameterValueAssignmentSyntax = None, instances: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> HierarchyInstantiationSyntax:
        ...
    def idWithExprCoverageBinInitializer(self, id: pyslang.parsing.Token, withClause: WithClauseSyntax) -> IdWithExprCoverageBinInitializerSyntax:
        ...
    def identifierName(self, identifier: pyslang.parsing.Token) -> IdentifierNameSyntax:
        ...
    def identifierSelectName(self, identifier: pyslang.parsing.Token, selectors: SyntaxList) -> IdentifierSelectNameSyntax:
        ...
    def ifGenerate(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, condition: ExpressionSyntax, closeParen: pyslang.parsing.Token, block: MemberSyntax, elseClause: ElseClauseSyntax = None) -> IfGenerateSyntax:
        ...
    def ifNonePathDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, path: PathDeclarationSyntax) -> IfNonePathDeclarationSyntax:
        ...
    def iffEventClause(self, iff: pyslang.parsing.Token, expr: ExpressionSyntax) -> IffEventClauseSyntax:
        ...
    def immediateAssertionMember(self, attributes: SyntaxList, statement: ImmediateAssertionStatementSyntax) -> ImmediateAssertionMemberSyntax:
        ...
    def immediateAssertionStatement(self, kind: SyntaxKind, label: NamedLabelSyntax = None, attributes: SyntaxList, keyword: pyslang.parsing.Token, delay: DeferredAssertionSyntax = None, expr: ParenthesizedExpressionSyntax, action: ActionBlockSyntax) -> ImmediateAssertionStatementSyntax:
        ...
    def implementsClause(self, keyword: pyslang.parsing.Token, interfaces: SeparatedSyntaxList) -> ImplementsClauseSyntax:
        ...
    def implicationConstraint(self, left: ExpressionSyntax, arrow: pyslang.parsing.Token, constraints: ConstraintItemSyntax) -> ImplicationConstraintSyntax:
        ...
    def implicitAnsiPort(self, attributes: SyntaxList, header: PortHeaderSyntax, declarator: DeclaratorSyntax) -> ImplicitAnsiPortSyntax:
        ...
    def implicitEventControl(self, at: pyslang.parsing.Token, openParen: pyslang.parsing.Token, star: pyslang.parsing.Token, closeParen: pyslang.parsing.Token) -> ImplicitEventControlSyntax:
        ...
    def implicitNonAnsiPort(self, expr: PortExpressionSyntax) -> ImplicitNonAnsiPortSyntax:
        ...
    def implicitType(self, signing: pyslang.parsing.Token, dimensions: SyntaxList, placeholder: pyslang.parsing.Token) -> ImplicitTypeSyntax:
        ...
    def includeDirective(self, directive: pyslang.parsing.Token, fileName: pyslang.parsing.Token) -> IncludeDirectiveSyntax:
        ...
    def insideExpression(self, expr: ExpressionSyntax, inside: pyslang.parsing.Token, ranges: RangeListSyntax) -> InsideExpressionSyntax:
        ...
    def instanceConfigRule(self, instance: pyslang.parsing.Token, topModule: pyslang.parsing.Token, instanceNames: SyntaxList, ruleClause: ConfigRuleClauseSyntax, semi: pyslang.parsing.Token) -> InstanceConfigRuleSyntax:
        ...
    def instanceName(self, name: pyslang.parsing.Token, dimensions: SyntaxList) -> InstanceNameSyntax:
        ...
    def integerType(self, kind: SyntaxKind, keyword: pyslang.parsing.Token, signing: pyslang.parsing.Token, dimensions: SyntaxList) -> IntegerTypeSyntax:
        ...
    def integerVectorExpression(self, size: pyslang.parsing.Token, base: pyslang.parsing.Token, value: pyslang.parsing.Token) -> IntegerVectorExpressionSyntax:
        ...
    def interfacePortHeader(self, nameOrKeyword: pyslang.parsing.Token, modport: DotMemberClauseSyntax = None) -> InterfacePortHeaderSyntax:
        ...
    def intersectClause(self, intersect: pyslang.parsing.Token, ranges: RangeListSyntax) -> IntersectClauseSyntax:
        ...
    def invocationExpression(self, left: ExpressionSyntax, attributes: SyntaxList, arguments: ArgumentListSyntax = None) -> InvocationExpressionSyntax:
        ...
    def jumpStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, breakOrContinue: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> JumpStatementSyntax:
        ...
    def keywordName(self, kind: SyntaxKind, keyword: pyslang.parsing.Token) -> KeywordNameSyntax:
        ...
    def keywordType(self, kind: SyntaxKind, keyword: pyslang.parsing.Token) -> KeywordTypeSyntax:
        ...
    def letDeclaration(self, attributes: SyntaxList, let: pyslang.parsing.Token, identifier: pyslang.parsing.Token, portList: AssertionItemPortListSyntax = None, equals: pyslang.parsing.Token, expr: ExpressionSyntax, semi: pyslang.parsing.Token) -> LetDeclarationSyntax:
        ...
    def libraryDeclaration(self, attributes: SyntaxList, library: pyslang.parsing.Token, name: pyslang.parsing.Token, filePaths: SeparatedSyntaxList, incDirClause: LibraryIncDirClauseSyntax = None, semi: pyslang.parsing.Token) -> LibraryDeclarationSyntax:
        ...
    def libraryIncDirClause(self, minus: pyslang.parsing.Token, incdir: pyslang.parsing.Token, filePaths: SeparatedSyntaxList) -> LibraryIncDirClauseSyntax:
        ...
    def libraryIncludeStatement(self, attributes: SyntaxList, include: pyslang.parsing.Token, filePath: FilePathSpecSyntax, semi: pyslang.parsing.Token) -> LibraryIncludeStatementSyntax:
        ...
    def libraryMap(self, members: SyntaxList, endOfFile: pyslang.parsing.Token) -> LibraryMapSyntax:
        ...
    def lineDirective(self, directive: pyslang.parsing.Token, lineNumber: pyslang.parsing.Token, fileName: pyslang.parsing.Token, level: pyslang.parsing.Token) -> LineDirectiveSyntax:
        ...
    def literalExpression(self, kind: SyntaxKind, literal: pyslang.parsing.Token) -> LiteralExpressionSyntax:
        ...
    def localVariableDeclaration(self, attributes: SyntaxList, var: pyslang.parsing.Token, type: DataTypeSyntax, declarators: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> LocalVariableDeclarationSyntax:
        ...
    def loopConstraint(self, foreachKeyword: pyslang.parsing.Token, loopList: ForeachLoopListSyntax, constraints: ConstraintItemSyntax) -> LoopConstraintSyntax:
        ...
    def loopGenerate(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, genvar: pyslang.parsing.Token, identifier: pyslang.parsing.Token, equals: pyslang.parsing.Token, initialExpr: ExpressionSyntax, semi1: pyslang.parsing.Token, stopExpr: ExpressionSyntax, semi2: pyslang.parsing.Token, iterationExpr: ExpressionSyntax, closeParen: pyslang.parsing.Token, block: MemberSyntax) -> LoopGenerateSyntax:
        ...
    def loopStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, repeatOrWhile: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token, statement: StatementSyntax) -> LoopStatementSyntax:
        ...
    def macroActualArgument(self, tokens: TokenList) -> MacroActualArgumentSyntax:
        ...
    def macroActualArgumentList(self, openParen: pyslang.parsing.Token, args: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> MacroActualArgumentListSyntax:
        ...
    def macroArgumentDefault(self, equals: pyslang.parsing.Token, tokens: TokenList) -> MacroArgumentDefaultSyntax:
        ...
    def macroFormalArgument(self, name: pyslang.parsing.Token, defaultValue: MacroArgumentDefaultSyntax = None) -> MacroFormalArgumentSyntax:
        ...
    def macroFormalArgumentList(self, openParen: pyslang.parsing.Token, args: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> MacroFormalArgumentListSyntax:
        ...
    def macroUsage(self, directive: pyslang.parsing.Token, args: MacroActualArgumentListSyntax = None) -> MacroUsageSyntax:
        ...
    def matchesClause(self, matchesKeyword: pyslang.parsing.Token, pattern: PatternSyntax) -> MatchesClauseSyntax:
        ...
    def memberAccessExpression(self, left: ExpressionSyntax, dot: pyslang.parsing.Token, name: pyslang.parsing.Token) -> MemberAccessExpressionSyntax:
        ...
    def minTypMaxExpression(self, min: ExpressionSyntax, colon1: pyslang.parsing.Token, typ: ExpressionSyntax, colon2: pyslang.parsing.Token, max: ExpressionSyntax) -> MinTypMaxExpressionSyntax:
        ...
    def modportClockingPort(self, attributes: SyntaxList, clocking: pyslang.parsing.Token, name: pyslang.parsing.Token) -> ModportClockingPortSyntax:
        ...
    def modportDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, items: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> ModportDeclarationSyntax:
        ...
    def modportExplicitPort(self, dot: pyslang.parsing.Token, name: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax = None, closeParen: pyslang.parsing.Token) -> ModportExplicitPortSyntax:
        ...
    def modportItem(self, name: pyslang.parsing.Token, ports: AnsiPortListSyntax) -> ModportItemSyntax:
        ...
    def modportNamedPort(self, name: pyslang.parsing.Token) -> ModportNamedPortSyntax:
        ...
    def modportSimplePortList(self, attributes: SyntaxList, direction: pyslang.parsing.Token, ports: SeparatedSyntaxList) -> ModportSimplePortListSyntax:
        ...
    def modportSubroutinePort(self, prototype: FunctionPrototypeSyntax) -> ModportSubroutinePortSyntax:
        ...
    def modportSubroutinePortList(self, attributes: SyntaxList, importExport: pyslang.parsing.Token, ports: SeparatedSyntaxList) -> ModportSubroutinePortListSyntax:
        ...
    def moduleDeclaration(self, kind: SyntaxKind, attributes: SyntaxList, header: ModuleHeaderSyntax, members: SyntaxList, endmodule: pyslang.parsing.Token, blockName: NamedBlockClauseSyntax = None) -> ModuleDeclarationSyntax:
        ...
    def moduleHeader(self, kind: SyntaxKind, moduleKeyword: pyslang.parsing.Token, lifetime: pyslang.parsing.Token, name: pyslang.parsing.Token, imports: SyntaxList, parameters: ParameterPortListSyntax = None, ports: PortListSyntax = None, semi: pyslang.parsing.Token) -> ModuleHeaderSyntax:
        ...
    def multipleConcatenationExpression(self, openBrace: pyslang.parsing.Token, expression: ExpressionSyntax, concatenation: ConcatenationExpressionSyntax, closeBrace: pyslang.parsing.Token) -> MultipleConcatenationExpressionSyntax:
        ...
    def nameValuePragmaExpression(self, name: pyslang.parsing.Token, equals: pyslang.parsing.Token, value: PragmaExpressionSyntax) -> NameValuePragmaExpressionSyntax:
        ...
    def namedArgument(self, dot: pyslang.parsing.Token, name: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: PropertyExprSyntax = None, closeParen: pyslang.parsing.Token) -> NamedArgumentSyntax:
        ...
    def namedBlockClause(self, colon: pyslang.parsing.Token, name: pyslang.parsing.Token) -> NamedBlockClauseSyntax:
        ...
    def namedConditionalDirectiveExpression(self, name: pyslang.parsing.Token) -> NamedConditionalDirectiveExpressionSyntax:
        ...
    def namedLabel(self, name: pyslang.parsing.Token, colon: pyslang.parsing.Token) -> NamedLabelSyntax:
        ...
    def namedParamAssignment(self, dot: pyslang.parsing.Token, name: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax = None, closeParen: pyslang.parsing.Token) -> NamedParamAssignmentSyntax:
        ...
    def namedPortConnection(self, attributes: SyntaxList, dot: pyslang.parsing.Token, name: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: PropertyExprSyntax = None, closeParen: pyslang.parsing.Token) -> NamedPortConnectionSyntax:
        ...
    def namedStructurePatternMember(self, name: pyslang.parsing.Token, colon: pyslang.parsing.Token, pattern: PatternSyntax) -> NamedStructurePatternMemberSyntax:
        ...
    def namedType(self, name: NameSyntax) -> NamedTypeSyntax:
        ...
    def netAlias(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, nets: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> NetAliasSyntax:
        ...
    def netDeclaration(self, attributes: SyntaxList, netType: pyslang.parsing.Token, strength: NetStrengthSyntax = None, expansionHint: pyslang.parsing.Token, type: DataTypeSyntax, delay: TimingControlSyntax = None, declarators: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> NetDeclarationSyntax:
        ...
    def netPortHeader(self, direction: pyslang.parsing.Token, netType: pyslang.parsing.Token, dataType: DataTypeSyntax) -> NetPortHeaderSyntax:
        ...
    def netTypeDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, type: DataTypeSyntax, name: pyslang.parsing.Token, withFunction: WithFunctionClauseSyntax = None, semi: pyslang.parsing.Token) -> NetTypeDeclarationSyntax:
        ...
    def newArrayExpression(self, newKeyword: NameSyntax, openBracket: pyslang.parsing.Token, sizeExpr: ExpressionSyntax, closeBracket: pyslang.parsing.Token, initializer: ParenthesizedExpressionSyntax = None) -> NewArrayExpressionSyntax:
        ...
    def newClassExpression(self, scopedNew: NameSyntax, argList: ArgumentListSyntax = None) -> NewClassExpressionSyntax:
        ...
    def nonAnsiPortList(self, openParen: pyslang.parsing.Token, ports: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> NonAnsiPortListSyntax:
        ...
    def nonAnsiUdpPortList(self, openParen: pyslang.parsing.Token, ports: SeparatedSyntaxList, closeParen: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> NonAnsiUdpPortListSyntax:
        ...
    def numberPragmaExpression(self, size: pyslang.parsing.Token, base: pyslang.parsing.Token, value: pyslang.parsing.Token) -> NumberPragmaExpressionSyntax:
        ...
    def oneStepDelay(self, hash: pyslang.parsing.Token, oneStep: pyslang.parsing.Token) -> OneStepDelaySyntax:
        ...
    def orderedArgument(self, expr: PropertyExprSyntax) -> OrderedArgumentSyntax:
        ...
    def orderedParamAssignment(self, expr: ExpressionSyntax) -> OrderedParamAssignmentSyntax:
        ...
    def orderedPortConnection(self, attributes: SyntaxList, expr: PropertyExprSyntax) -> OrderedPortConnectionSyntax:
        ...
    def orderedStructurePatternMember(self, pattern: PatternSyntax) -> OrderedStructurePatternMemberSyntax:
        ...
    def packageExportAllDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, star1: pyslang.parsing.Token, doubleColon: pyslang.parsing.Token, star2: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> PackageExportAllDeclarationSyntax:
        ...
    def packageExportDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, items: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> PackageExportDeclarationSyntax:
        ...
    def packageImportDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, items: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> PackageImportDeclarationSyntax:
        ...
    def packageImportItem(self, package: pyslang.parsing.Token, doubleColon: pyslang.parsing.Token, item: pyslang.parsing.Token) -> PackageImportItemSyntax:
        ...
    def parameterDeclaration(self, keyword: pyslang.parsing.Token, type: DataTypeSyntax, declarators: SeparatedSyntaxList) -> ParameterDeclarationSyntax:
        ...
    def parameterDeclarationStatement(self, attributes: SyntaxList, parameter: ParameterDeclarationBaseSyntax, semi: pyslang.parsing.Token) -> ParameterDeclarationStatementSyntax:
        ...
    def parameterPortList(self, hash: pyslang.parsing.Token, openParen: pyslang.parsing.Token, declarations: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> ParameterPortListSyntax:
        ...
    def parameterValueAssignment(self, hash: pyslang.parsing.Token, openParen: pyslang.parsing.Token, parameters: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> ParameterValueAssignmentSyntax:
        ...
    def parenExpressionList(self, openParen: pyslang.parsing.Token, expressions: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> ParenExpressionListSyntax:
        ...
    def parenPragmaExpression(self, openParen: pyslang.parsing.Token, values: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> ParenPragmaExpressionSyntax:
        ...
    def parenthesizedBinsSelectExpr(self, openParen: pyslang.parsing.Token, expr: BinsSelectExpressionSyntax, closeParen: pyslang.parsing.Token) -> ParenthesizedBinsSelectExprSyntax:
        ...
    def parenthesizedConditionalDirectiveExpression(self, openParen: pyslang.parsing.Token, operand: ConditionalDirectiveExpressionSyntax, closeParen: pyslang.parsing.Token) -> ParenthesizedConditionalDirectiveExpressionSyntax:
        ...
    def parenthesizedEventExpression(self, openParen: pyslang.parsing.Token, expr: EventExpressionSyntax, closeParen: pyslang.parsing.Token) -> ParenthesizedEventExpressionSyntax:
        ...
    def parenthesizedExpression(self, openParen: pyslang.parsing.Token, expression: ExpressionSyntax, closeParen: pyslang.parsing.Token) -> ParenthesizedExpressionSyntax:
        ...
    def parenthesizedPattern(self, openParen: pyslang.parsing.Token, pattern: PatternSyntax, closeParen: pyslang.parsing.Token) -> ParenthesizedPatternSyntax:
        ...
    def parenthesizedPropertyExpr(self, openParen: pyslang.parsing.Token, expr: PropertyExprSyntax, matchList: SequenceMatchListSyntax = None, closeParen: pyslang.parsing.Token) -> ParenthesizedPropertyExprSyntax:
        ...
    def parenthesizedSequenceExpr(self, openParen: pyslang.parsing.Token, expr: SequenceExprSyntax, matchList: SequenceMatchListSyntax = None, closeParen: pyslang.parsing.Token, repetition: SequenceRepetitionSyntax = None) -> ParenthesizedSequenceExprSyntax:
        ...
    def pathDeclaration(self, attributes: SyntaxList, desc: PathDescriptionSyntax, equals: pyslang.parsing.Token, openParen: pyslang.parsing.Token, delays: SeparatedSyntaxList, closeParen: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> PathDeclarationSyntax:
        ...
    def pathDescription(self, openParen: pyslang.parsing.Token, edgeIdentifier: pyslang.parsing.Token, inputs: SeparatedSyntaxList, polarityOperator: pyslang.parsing.Token, pathOperator: pyslang.parsing.Token, suffix: PathSuffixSyntax, closeParen: pyslang.parsing.Token) -> PathDescriptionSyntax:
        ...
    def patternCaseItem(self, pattern: PatternSyntax, tripleAnd: pyslang.parsing.Token, expr: ExpressionSyntax = None, colon: pyslang.parsing.Token, statement: StatementSyntax) -> PatternCaseItemSyntax:
        ...
    def portConcatenation(self, openBrace: pyslang.parsing.Token, references: SeparatedSyntaxList, closeBrace: pyslang.parsing.Token) -> PortConcatenationSyntax:
        ...
    def portDeclaration(self, attributes: SyntaxList, header: PortHeaderSyntax, declarators: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> PortDeclarationSyntax:
        ...
    def portReference(self, name: pyslang.parsing.Token, select: ElementSelectSyntax = None) -> PortReferenceSyntax:
        ...
    def postfixUnaryExpression(self, kind: SyntaxKind, operand: ExpressionSyntax, attributes: SyntaxList, operatorToken: pyslang.parsing.Token) -> PostfixUnaryExpressionSyntax:
        ...
    def pragmaDirective(self, directive: pyslang.parsing.Token, name: pyslang.parsing.Token, args: SeparatedSyntaxList) -> PragmaDirectiveSyntax:
        ...
    def prefixUnaryExpression(self, kind: SyntaxKind, operatorToken: pyslang.parsing.Token, attributes: SyntaxList, operand: ExpressionSyntax) -> PrefixUnaryExpressionSyntax:
        ...
    def primaryBlockEventExpression(self, keyword: pyslang.parsing.Token, name: NameSyntax) -> PrimaryBlockEventExpressionSyntax:
        ...
    def primitiveInstantiation(self, attributes: SyntaxList, type: pyslang.parsing.Token, strength: NetStrengthSyntax = None, delay: TimingControlSyntax = None, instances: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> PrimitiveInstantiationSyntax:
        ...
    def proceduralAssignStatement(self, kind: SyntaxKind, label: NamedLabelSyntax = None, attributes: SyntaxList, keyword: pyslang.parsing.Token, expr: ExpressionSyntax, semi: pyslang.parsing.Token) -> ProceduralAssignStatementSyntax:
        ...
    def proceduralBlock(self, kind: SyntaxKind, attributes: SyntaxList, keyword: pyslang.parsing.Token, statement: StatementSyntax) -> ProceduralBlockSyntax:
        ...
    def proceduralDeassignStatement(self, kind: SyntaxKind, label: NamedLabelSyntax = None, attributes: SyntaxList, keyword: pyslang.parsing.Token, variable: ExpressionSyntax, semi: pyslang.parsing.Token) -> ProceduralDeassignStatementSyntax:
        ...
    def production(self, dataType: DataTypeSyntax = None, name: pyslang.parsing.Token, portList: FunctionPortListSyntax = None, colon: pyslang.parsing.Token, rules: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> ProductionSyntax:
        ...
    def propertyDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, name: pyslang.parsing.Token, portList: AssertionItemPortListSyntax = None, semi: pyslang.parsing.Token, variables: SyntaxList, propertySpec: PropertySpecSyntax, optionalSemi: pyslang.parsing.Token, end: pyslang.parsing.Token, endBlockName: NamedBlockClauseSyntax = None) -> PropertyDeclarationSyntax:
        ...
    def propertySpec(self, clocking: TimingControlSyntax = None, disable: DisableIffSyntax = None, expr: PropertyExprSyntax) -> PropertySpecSyntax:
        ...
    def pullStrength(self, openParen: pyslang.parsing.Token, strength: pyslang.parsing.Token, closeParen: pyslang.parsing.Token) -> PullStrengthSyntax:
        ...
    def pulseStyleDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, inputs: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> PulseStyleDeclarationSyntax:
        ...
    def queueDimensionSpecifier(self, dollar: pyslang.parsing.Token, maxSizeClause: ColonExpressionClauseSyntax = None) -> QueueDimensionSpecifierSyntax:
        ...
    def randCaseItem(self, expr: ExpressionSyntax, colon: pyslang.parsing.Token, statement: StatementSyntax) -> RandCaseItemSyntax:
        ...
    def randCaseStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, randCase: pyslang.parsing.Token, items: SyntaxList, endCase: pyslang.parsing.Token) -> RandCaseStatementSyntax:
        ...
    def randJoinClause(self, rand: pyslang.parsing.Token, join: pyslang.parsing.Token, expr: ParenthesizedExpressionSyntax = None) -> RandJoinClauseSyntax:
        ...
    def randSequenceStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, randsequence: pyslang.parsing.Token, openParen: pyslang.parsing.Token, firstProduction: pyslang.parsing.Token, closeParen: pyslang.parsing.Token, productions: SyntaxList, endsequence: pyslang.parsing.Token) -> RandSequenceStatementSyntax:
        ...
    def rangeCoverageBinInitializer(self, ranges: RangeListSyntax, withClause: WithClauseSyntax = None) -> RangeCoverageBinInitializerSyntax:
        ...
    def rangeDimensionSpecifier(self, selector: SelectorSyntax) -> RangeDimensionSpecifierSyntax:
        ...
    def rangeList(self, openBrace: pyslang.parsing.Token, valueRanges: SeparatedSyntaxList, closeBrace: pyslang.parsing.Token) -> RangeListSyntax:
        ...
    def rangeSelect(self, kind: SyntaxKind, left: ExpressionSyntax, range: pyslang.parsing.Token, right: ExpressionSyntax) -> RangeSelectSyntax:
        ...
    def repeatedEventControl(self, repeat: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token, eventControl: TimingControlSyntax = None) -> RepeatedEventControlSyntax:
        ...
    def replicatedAssignmentPattern(self, openBrace: pyslang.parsing.Token, countExpr: ExpressionSyntax, innerOpenBrace: pyslang.parsing.Token, items: SeparatedSyntaxList, innerCloseBrace: pyslang.parsing.Token, closeBrace: pyslang.parsing.Token) -> ReplicatedAssignmentPatternSyntax:
        ...
    def returnStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, returnKeyword: pyslang.parsing.Token, returnValue: ExpressionSyntax = None, semi: pyslang.parsing.Token) -> ReturnStatementSyntax:
        ...
    def rsCase(self, keyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token, items: SyntaxList, endcase: pyslang.parsing.Token) -> RsCaseSyntax:
        ...
    def rsCodeBlock(self, openBrace: pyslang.parsing.Token, items: SyntaxList, closeBrace: pyslang.parsing.Token) -> RsCodeBlockSyntax:
        ...
    def rsElseClause(self, keyword: pyslang.parsing.Token, item: RsProdItemSyntax) -> RsElseClauseSyntax:
        ...
    def rsIfElse(self, keyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, condition: ExpressionSyntax, closeParen: pyslang.parsing.Token, ifItem: RsProdItemSyntax, elseClause: RsElseClauseSyntax = None) -> RsIfElseSyntax:
        ...
    def rsProdItem(self, name: pyslang.parsing.Token, argList: ArgumentListSyntax = None) -> RsProdItemSyntax:
        ...
    def rsRepeat(self, keyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token, item: RsProdItemSyntax) -> RsRepeatSyntax:
        ...
    def rsRule(self, randJoin: RandJoinClauseSyntax = None, prods: SyntaxList, weightClause: RsWeightClauseSyntax = None) -> RsRuleSyntax:
        ...
    def rsWeightClause(self, colonEqual: pyslang.parsing.Token, weight: ExpressionSyntax, codeBlock: RsProdSyntax = None) -> RsWeightClauseSyntax:
        ...
    def scopedName(self, left: NameSyntax, separator: pyslang.parsing.Token, right: NameSyntax) -> ScopedNameSyntax:
        ...
    def sequenceDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, name: pyslang.parsing.Token, portList: AssertionItemPortListSyntax = None, semi: pyslang.parsing.Token, variables: SyntaxList, seqExpr: SequenceExprSyntax, optionalSemi: pyslang.parsing.Token, end: pyslang.parsing.Token, endBlockName: NamedBlockClauseSyntax = None) -> SequenceDeclarationSyntax:
        ...
    def sequenceMatchList(self, comma: pyslang.parsing.Token, items: SeparatedSyntaxList) -> SequenceMatchListSyntax:
        ...
    def sequenceRepetition(self, openBracket: pyslang.parsing.Token, op: pyslang.parsing.Token, selector: SelectorSyntax = None, closeBracket: pyslang.parsing.Token) -> SequenceRepetitionSyntax:
        ...
    def signalEventExpression(self, edge: pyslang.parsing.Token, expr: ExpressionSyntax, iffClause: IffEventClauseSyntax = None) -> SignalEventExpressionSyntax:
        ...
    def signedCastExpression(self, signing: pyslang.parsing.Token, apostrophe: pyslang.parsing.Token, inner: ParenthesizedExpressionSyntax) -> SignedCastExpressionSyntax:
        ...
    def simpleAssignmentPattern(self, openBrace: pyslang.parsing.Token, items: SeparatedSyntaxList, closeBrace: pyslang.parsing.Token) -> SimpleAssignmentPatternSyntax:
        ...
    def simpleBinsSelectExpr(self, expr: ExpressionSyntax, matchesClause: MatchesClauseSyntax = None) -> SimpleBinsSelectExprSyntax:
        ...
    def simpleDirective(self, kind: SyntaxKind, directive: pyslang.parsing.Token) -> SimpleDirectiveSyntax:
        ...
    def simplePathSuffix(self, outputs: SeparatedSyntaxList) -> SimplePathSuffixSyntax:
        ...
    def simplePragmaExpression(self, value: pyslang.parsing.Token) -> SimplePragmaExpressionSyntax:
        ...
    def simplePropertyExpr(self, expr: SequenceExprSyntax) -> SimplePropertyExprSyntax:
        ...
    def simpleSequenceExpr(self, expr: ExpressionSyntax, repetition: SequenceRepetitionSyntax = None) -> SimpleSequenceExprSyntax:
        ...
    def solveBeforeConstraint(self, solve: pyslang.parsing.Token, beforeExpr: SeparatedSyntaxList, before: pyslang.parsing.Token, afterExpr: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> SolveBeforeConstraintSyntax:
        ...
    def specifyBlock(self, attributes: SyntaxList, specify: pyslang.parsing.Token, items: SyntaxList, endspecify: pyslang.parsing.Token) -> SpecifyBlockSyntax:
        ...
    def specparamDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, type: ImplicitTypeSyntax, declarators: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> SpecparamDeclarationSyntax:
        ...
    def specparamDeclarator(self, name: pyslang.parsing.Token, equals: pyslang.parsing.Token, openParen: pyslang.parsing.Token, value1: ExpressionSyntax, comma: pyslang.parsing.Token, value2: ExpressionSyntax = None, closeParen: pyslang.parsing.Token) -> SpecparamDeclaratorSyntax:
        ...
    def standardCaseItem(self, expressions: SeparatedSyntaxList, colon: pyslang.parsing.Token, clause: SyntaxNode) -> StandardCaseItemSyntax:
        ...
    def standardPropertyCaseItem(self, expressions: SeparatedSyntaxList, colon: pyslang.parsing.Token, expr: PropertyExprSyntax, semi: pyslang.parsing.Token) -> StandardPropertyCaseItemSyntax:
        ...
    def standardRsCaseItem(self, expressions: SeparatedSyntaxList, colon: pyslang.parsing.Token, item: RsProdItemSyntax, semi: pyslang.parsing.Token) -> StandardRsCaseItemSyntax:
        ...
    def streamExpression(self, expression: ExpressionSyntax, withRange: StreamExpressionWithRangeSyntax = None) -> StreamExpressionSyntax:
        ...
    def streamExpressionWithRange(self, withKeyword: pyslang.parsing.Token, range: ElementSelectSyntax) -> StreamExpressionWithRangeSyntax:
        ...
    def streamingConcatenationExpression(self, openBrace: pyslang.parsing.Token, operatorToken: pyslang.parsing.Token, sliceSize: ExpressionSyntax = None, innerOpenBrace: pyslang.parsing.Token, expressions: SeparatedSyntaxList, innerCloseBrace: pyslang.parsing.Token, closeBrace: pyslang.parsing.Token) -> StreamingConcatenationExpressionSyntax:
        ...
    def strongWeakPropertyExpr(self, keyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: SequenceExprSyntax, closeParen: pyslang.parsing.Token) -> StrongWeakPropertyExprSyntax:
        ...
    def structUnionMember(self, attributes: SyntaxList, randomQualifier: pyslang.parsing.Token, type: DataTypeSyntax, declarators: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> StructUnionMemberSyntax:
        ...
    def structUnionType(self, kind: SyntaxKind, keyword: pyslang.parsing.Token, taggedOrSoft: pyslang.parsing.Token, packed: pyslang.parsing.Token, signing: pyslang.parsing.Token, openBrace: pyslang.parsing.Token, members: SyntaxList, closeBrace: pyslang.parsing.Token, dimensions: SyntaxList) -> StructUnionTypeSyntax:
        ...
    def structurePattern(self, openBrace: pyslang.parsing.Token, members: SeparatedSyntaxList, closeBrace: pyslang.parsing.Token) -> StructurePatternSyntax:
        ...
    def structuredAssignmentPattern(self, openBrace: pyslang.parsing.Token, items: SeparatedSyntaxList, closeBrace: pyslang.parsing.Token) -> StructuredAssignmentPatternSyntax:
        ...
    def superNewDefaultedArgsExpression(self, scopedNew: NameSyntax, openParen: pyslang.parsing.Token, defaultKeyword: pyslang.parsing.Token, closeParen: pyslang.parsing.Token) -> SuperNewDefaultedArgsExpressionSyntax:
        ...
    def systemName(self, systemIdentifier: pyslang.parsing.Token) -> SystemNameSyntax:
        ...
    def systemTimingCheck(self, attributes: SyntaxList, name: pyslang.parsing.Token, openParen: pyslang.parsing.Token, args: SeparatedSyntaxList, closeParen: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> SystemTimingCheckSyntax:
        ...
    def taggedPattern(self, tagged: pyslang.parsing.Token, memberName: pyslang.parsing.Token, pattern: PatternSyntax = None) -> TaggedPatternSyntax:
        ...
    def taggedUnionExpression(self, tagged: pyslang.parsing.Token, member: pyslang.parsing.Token, expr: ExpressionSyntax = None) -> TaggedUnionExpressionSyntax:
        ...
    def timeScaleDirective(self, directive: pyslang.parsing.Token, timeUnit: pyslang.parsing.Token, slash: pyslang.parsing.Token, timePrecision: pyslang.parsing.Token) -> TimeScaleDirectiveSyntax:
        ...
    def timeUnitsDeclaration(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, time: pyslang.parsing.Token, divider: DividerClauseSyntax = None, semi: pyslang.parsing.Token) -> TimeUnitsDeclarationSyntax:
        ...
    def timingCheckEventArg(self, edge: pyslang.parsing.Token, controlSpecifier: EdgeControlSpecifierSyntax = None, terminal: ExpressionSyntax, condition: TimingCheckEventConditionSyntax = None) -> TimingCheckEventArgSyntax:
        ...
    def timingCheckEventCondition(self, tripleAnd: pyslang.parsing.Token, expr: ExpressionSyntax) -> TimingCheckEventConditionSyntax:
        ...
    def timingControlExpression(self, timing: TimingControlSyntax, expr: ExpressionSyntax) -> TimingControlExpressionSyntax:
        ...
    def timingControlStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, timingControl: TimingControlSyntax, statement: StatementSyntax) -> TimingControlStatementSyntax:
        ...
    def transListCoverageBinInitializer(self, sets: SeparatedSyntaxList) -> TransListCoverageBinInitializerSyntax:
        ...
    def transRange(self, items: SeparatedSyntaxList, repeat: TransRepeatRangeSyntax = None) -> TransRangeSyntax:
        ...
    def transRepeatRange(self, openBracket: pyslang.parsing.Token, specifier: pyslang.parsing.Token, selector: SelectorSyntax = None, closeBracket: pyslang.parsing.Token) -> TransRepeatRangeSyntax:
        ...
    def transSet(self, openParen: pyslang.parsing.Token, ranges: SeparatedSyntaxList, closeParen: pyslang.parsing.Token) -> TransSetSyntax:
        ...
    def typeAssignment(self, name: pyslang.parsing.Token, assignment: EqualsTypeClauseSyntax = None) -> TypeAssignmentSyntax:
        ...
    def typeParameterDeclaration(self, keyword: pyslang.parsing.Token, typeKeyword: pyslang.parsing.Token, typeRestriction: ForwardTypeRestrictionSyntax = None, declarators: SeparatedSyntaxList) -> TypeParameterDeclarationSyntax:
        ...
    def typeReference(self, typeKeyword: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token) -> TypeReferenceSyntax:
        ...
    def typedefDeclaration(self, attributes: SyntaxList, typedefKeyword: pyslang.parsing.Token, type: DataTypeSyntax, name: pyslang.parsing.Token, dimensions: SyntaxList, semi: pyslang.parsing.Token) -> TypedefDeclarationSyntax:
        ...
    def udpBody(self, portDecls: SeparatedSyntaxList, initialStmt: UdpInitialStmtSyntax = None, table: pyslang.parsing.Token, entries: SyntaxList, endtable: pyslang.parsing.Token) -> UdpBodySyntax:
        ...
    def udpDeclaration(self, attributes: SyntaxList, primitive: pyslang.parsing.Token, name: pyslang.parsing.Token, portList: UdpPortListSyntax, body: UdpBodySyntax, endprimitive: pyslang.parsing.Token, endBlockName: NamedBlockClauseSyntax = None) -> UdpDeclarationSyntax:
        ...
    def udpEdgeField(self, openParen: pyslang.parsing.Token, first: pyslang.parsing.Token, second: pyslang.parsing.Token, closeParen: pyslang.parsing.Token) -> UdpEdgeFieldSyntax:
        ...
    def udpEntry(self, inputs: SyntaxList, colon1: pyslang.parsing.Token, current: UdpFieldBaseSyntax = None, colon2: pyslang.parsing.Token, next: UdpFieldBaseSyntax = None, semi: pyslang.parsing.Token) -> UdpEntrySyntax:
        ...
    def udpInitialStmt(self, initial: pyslang.parsing.Token, name: pyslang.parsing.Token, equals: pyslang.parsing.Token, value: ExpressionSyntax, semi: pyslang.parsing.Token) -> UdpInitialStmtSyntax:
        ...
    def udpInputPortDecl(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, names: SeparatedSyntaxList) -> UdpInputPortDeclSyntax:
        ...
    def udpOutputPortDecl(self, attributes: SyntaxList, keyword: pyslang.parsing.Token, reg: pyslang.parsing.Token, name: pyslang.parsing.Token, initializer: EqualsValueClauseSyntax = None) -> UdpOutputPortDeclSyntax:
        ...
    def udpSimpleField(self, field: pyslang.parsing.Token) -> UdpSimpleFieldSyntax:
        ...
    def unaryBinsSelectExpr(self, op: pyslang.parsing.Token, expr: BinsSelectConditionExprSyntax) -> UnaryBinsSelectExprSyntax:
        ...
    def unaryConditionalDirectiveExpression(self, op: pyslang.parsing.Token, operand: ConditionalDirectiveExpressionSyntax) -> UnaryConditionalDirectiveExpressionSyntax:
        ...
    def unaryPropertyExpr(self, op: pyslang.parsing.Token, expr: PropertyExprSyntax) -> UnaryPropertyExprSyntax:
        ...
    def unarySelectPropertyExpr(self, op: pyslang.parsing.Token, openBracket: pyslang.parsing.Token, selector: SelectorSyntax = None, closeBracket: pyslang.parsing.Token, expr: PropertyExprSyntax) -> UnarySelectPropertyExprSyntax:
        ...
    def unconditionalBranchDirective(self, kind: SyntaxKind, directive: pyslang.parsing.Token, disabledTokens: TokenList) -> UnconditionalBranchDirectiveSyntax:
        ...
    def unconnectedDriveDirective(self, directive: pyslang.parsing.Token, strength: pyslang.parsing.Token) -> UnconnectedDriveDirectiveSyntax:
        ...
    def undefDirective(self, directive: pyslang.parsing.Token, name: pyslang.parsing.Token) -> UndefDirectiveSyntax:
        ...
    def uniquenessConstraint(self, unique: pyslang.parsing.Token, ranges: RangeListSyntax, semi: pyslang.parsing.Token) -> UniquenessConstraintSyntax:
        ...
    def userDefinedNetDeclaration(self, attributes: SyntaxList, netType: pyslang.parsing.Token, delay: TimingControlSyntax, declarators: SeparatedSyntaxList, semi: pyslang.parsing.Token) -> UserDefinedNetDeclarationSyntax:
        ...
    def valueRangeExpression(self, openBracket: pyslang.parsing.Token, left: ExpressionSyntax, op: pyslang.parsing.Token, right: ExpressionSyntax, closeBracket: pyslang.parsing.Token) -> ValueRangeExpressionSyntax:
        ...
    def variableDimension(self, openBracket: pyslang.parsing.Token, specifier: DimensionSpecifierSyntax = None, closeBracket: pyslang.parsing.Token) -> VariableDimensionSyntax:
        ...
    def variablePattern(self, dot: pyslang.parsing.Token, variableName: pyslang.parsing.Token) -> VariablePatternSyntax:
        ...
    def variablePortHeader(self, constKeyword: pyslang.parsing.Token, direction: pyslang.parsing.Token, varKeyword: pyslang.parsing.Token, dataType: DataTypeSyntax) -> VariablePortHeaderSyntax:
        ...
    def virtualInterfaceType(self, virtualKeyword: pyslang.parsing.Token, interfaceKeyword: pyslang.parsing.Token, name: pyslang.parsing.Token, parameters: ParameterValueAssignmentSyntax = None, modport: DotMemberClauseSyntax = None) -> VirtualInterfaceTypeSyntax:
        ...
    def voidCastedCallStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, voidKeyword: pyslang.parsing.Token, apostrophe: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> VoidCastedCallStatementSyntax:
        ...
    def waitForkStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, wait: pyslang.parsing.Token, fork: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> WaitForkStatementSyntax:
        ...
    def waitOrderStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, wait_order: pyslang.parsing.Token, openParen: pyslang.parsing.Token, names: SeparatedSyntaxList, closeParen: pyslang.parsing.Token, action: ActionBlockSyntax) -> WaitOrderStatementSyntax:
        ...
    def waitStatement(self, label: NamedLabelSyntax = None, attributes: SyntaxList, wait: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token, statement: StatementSyntax) -> WaitStatementSyntax:
        ...
    def wildcardDimensionSpecifier(self, star: pyslang.parsing.Token) -> WildcardDimensionSpecifierSyntax:
        ...
    def wildcardPattern(self, dot: pyslang.parsing.Token, star: pyslang.parsing.Token) -> WildcardPatternSyntax:
        ...
    def wildcardPortConnection(self, attributes: SyntaxList, dot: pyslang.parsing.Token, star: pyslang.parsing.Token) -> WildcardPortConnectionSyntax:
        ...
    def wildcardPortList(self, openParen: pyslang.parsing.Token, dot: pyslang.parsing.Token, star: pyslang.parsing.Token, closeParen: pyslang.parsing.Token) -> WildcardPortListSyntax:
        ...
    def wildcardUdpPortList(self, openParen: pyslang.parsing.Token, dot: pyslang.parsing.Token, star: pyslang.parsing.Token, closeParen: pyslang.parsing.Token, semi: pyslang.parsing.Token) -> WildcardUdpPortListSyntax:
        ...
    def withClause(self, with: pyslang.parsing.Token, openParen: pyslang.parsing.Token, expr: ExpressionSyntax, closeParen: pyslang.parsing.Token) -> WithClauseSyntax:
        ...
    def withFunctionClause(self, with: pyslang.parsing.Token, name: NameSyntax) -> WithFunctionClauseSyntax:
        ...
    def withFunctionSample(self, with: pyslang.parsing.Token, function: pyslang.parsing.Token, sample: pyslang.parsing.Token, portList: FunctionPortListSyntax = None) -> WithFunctionSampleSyntax:
        ...
class SyntaxKind(enum.Enum):
    AcceptOnPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AcceptOnPropertyExpr: 1>
    ActionBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ActionBlock: 2>
    AddAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AddAssignmentExpression: 3>
    AddExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AddExpression: 4>
    AlwaysBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AlwaysBlock: 5>
    AlwaysCombBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AlwaysCombBlock: 6>
    AlwaysFFBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AlwaysFFBlock: 7>
    AlwaysLatchBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AlwaysLatchBlock: 8>
    AndAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AndAssignmentExpression: 9>
    AndPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AndPropertyExpr: 10>
    AndSequenceExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AndSequenceExpr: 11>
    AnonymousProgram: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AnonymousProgram: 12>
    AnsiPortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AnsiPortList: 13>
    AnsiUdpPortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AnsiUdpPortList: 14>
    ArgumentList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ArgumentList: 15>
    ArithmeticLeftShiftAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ArithmeticLeftShiftAssignmentExpression: 16>
    ArithmeticRightShiftAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ArithmeticRightShiftAssignmentExpression: 17>
    ArithmeticShiftLeftExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ArithmeticShiftLeftExpression: 18>
    ArithmeticShiftRightExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ArithmeticShiftRightExpression: 19>
    ArrayAndMethod: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ArrayAndMethod: 20>
    ArrayOrMethod: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ArrayOrMethod: 21>
    ArrayOrRandomizeMethodExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ArrayOrRandomizeMethodExpression: 22>
    ArrayUniqueMethod: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ArrayUniqueMethod: 23>
    ArrayXorMethod: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ArrayXorMethod: 24>
    AscendingRangeSelect: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AscendingRangeSelect: 25>
    AssertPropertyStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AssertPropertyStatement: 26>
    AssertionItemPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AssertionItemPort: 27>
    AssertionItemPortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AssertionItemPortList: 28>
    AssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AssignmentExpression: 29>
    AssignmentPatternExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AssignmentPatternExpression: 30>
    AssignmentPatternItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AssignmentPatternItem: 31>
    AssumePropertyStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AssumePropertyStatement: 32>
    AttributeInstance: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AttributeInstance: 33>
    AttributeSpec: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.AttributeSpec: 34>
    BadExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BadExpression: 35>
    BeginKeywordsDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BeginKeywordsDirective: 36>
    BinSelectWithFilterExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinSelectWithFilterExpr: 37>
    BinaryAndExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinaryAndExpression: 38>
    BinaryBinsSelectExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinaryBinsSelectExpr: 39>
    BinaryBlockEventExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinaryBlockEventExpression: 40>
    BinaryConditionalDirectiveExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinaryConditionalDirectiveExpression: 41>
    BinaryEventExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinaryEventExpression: 42>
    BinaryOrExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinaryOrExpression: 43>
    BinaryXnorExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinaryXnorExpression: 44>
    BinaryXorExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinaryXorExpression: 45>
    BindDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BindDirective: 46>
    BindTargetList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BindTargetList: 47>
    BinsSelectConditionExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinsSelectConditionExpr: 48>
    BinsSelection: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BinsSelection: 49>
    BitSelect: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BitSelect: 50>
    BitType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BitType: 51>
    BlockCoverageEvent: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BlockCoverageEvent: 52>
    BlockingEventTriggerStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.BlockingEventTriggerStatement: 53>
    ByteType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ByteType: 54>
    CHandleType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CHandleType: 55>
    CaseEqualityExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CaseEqualityExpression: 56>
    CaseGenerate: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CaseGenerate: 57>
    CaseInequalityExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CaseInequalityExpression: 58>
    CasePropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CasePropertyExpr: 59>
    CaseStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CaseStatement: 60>
    CastExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CastExpression: 61>
    CellConfigRule: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CellConfigRule: 62>
    CellDefineDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CellDefineDirective: 63>
    ChargeStrength: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ChargeStrength: 64>
    CheckerDataDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CheckerDataDeclaration: 65>
    CheckerDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CheckerDeclaration: 66>
    CheckerInstanceStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CheckerInstanceStatement: 67>
    CheckerInstantiation: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CheckerInstantiation: 68>
    ClassDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClassDeclaration: 69>
    ClassMethodDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClassMethodDeclaration: 70>
    ClassMethodPrototype: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClassMethodPrototype: 71>
    ClassName: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClassName: 72>
    ClassPropertyDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClassPropertyDeclaration: 73>
    ClassSpecifier: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClassSpecifier: 74>
    ClockingDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClockingDeclaration: 75>
    ClockingDirection: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClockingDirection: 76>
    ClockingItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClockingItem: 77>
    ClockingPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClockingPropertyExpr: 78>
    ClockingSequenceExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClockingSequenceExpr: 79>
    ClockingSkew: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ClockingSkew: 80>
    ColonExpressionClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ColonExpressionClause: 81>
    CompilationUnit: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CompilationUnit: 82>
    ConcatenationExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConcatenationExpression: 83>
    ConcurrentAssertionMember: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConcurrentAssertionMember: 84>
    ConditionalConstraint: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConditionalConstraint: 85>
    ConditionalExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConditionalExpression: 86>
    ConditionalPathDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConditionalPathDeclaration: 87>
    ConditionalPattern: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConditionalPattern: 88>
    ConditionalPredicate: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConditionalPredicate: 89>
    ConditionalPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConditionalPropertyExpr: 90>
    ConditionalStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConditionalStatement: 91>
    ConfigCellIdentifier: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConfigCellIdentifier: 92>
    ConfigDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConfigDeclaration: 93>
    ConfigInstanceIdentifier: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConfigInstanceIdentifier: 94>
    ConfigLiblist: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConfigLiblist: 95>
    ConfigUseClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConfigUseClause: 96>
    ConstraintBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConstraintBlock: 97>
    ConstraintDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConstraintDeclaration: 98>
    ConstraintPrototype: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConstraintPrototype: 99>
    ConstructorName: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ConstructorName: 100>
    ContinuousAssign: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ContinuousAssign: 101>
    CopyClassExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CopyClassExpression: 102>
    CoverCross: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CoverCross: 103>
    CoverPropertyStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CoverPropertyStatement: 104>
    CoverSequenceStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CoverSequenceStatement: 105>
    CoverageBins: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CoverageBins: 106>
    CoverageBinsArraySize: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CoverageBinsArraySize: 107>
    CoverageIffClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CoverageIffClause: 108>
    CoverageOption: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CoverageOption: 109>
    CovergroupDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CovergroupDeclaration: 110>
    Coverpoint: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.Coverpoint: 111>
    CycleDelay: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.CycleDelay: 112>
    DPIExport: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DPIExport: 113>
    DPIImport: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DPIImport: 114>
    DataDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DataDeclaration: 115>
    Declarator: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.Declarator: 116>
    DefParam: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefParam: 117>
    DefParamAssignment: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefParamAssignment: 118>
    DefaultCaseItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultCaseItem: 119>
    DefaultClockingReference: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultClockingReference: 120>
    DefaultConfigRule: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultConfigRule: 121>
    DefaultCoverageBinInitializer: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultCoverageBinInitializer: 122>
    DefaultDecayTimeDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultDecayTimeDirective: 123>
    DefaultDisableDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultDisableDeclaration: 124>
    DefaultDistItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultDistItem: 125>
    DefaultExtendsClauseArg: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultExtendsClauseArg: 126>
    DefaultFunctionPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultFunctionPort: 127>
    DefaultNetTypeDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultNetTypeDirective: 128>
    DefaultPatternKeyExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultPatternKeyExpression: 129>
    DefaultPropertyCaseItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultPropertyCaseItem: 130>
    DefaultRsCaseItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultRsCaseItem: 131>
    DefaultSkewItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultSkewItem: 132>
    DefaultTriregStrengthDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefaultTriregStrengthDirective: 133>
    DeferredAssertion: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DeferredAssertion: 134>
    DefineDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DefineDirective: 135>
    Delay3: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.Delay3: 136>
    DelayControl: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DelayControl: 137>
    DelayModeDistributedDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DelayModeDistributedDirective: 138>
    DelayModePathDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DelayModePathDirective: 139>
    DelayModeUnitDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DelayModeUnitDirective: 140>
    DelayModeZeroDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DelayModeZeroDirective: 141>
    DelayedSequenceElement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DelayedSequenceElement: 142>
    DelayedSequenceExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DelayedSequenceExpr: 143>
    DescendingRangeSelect: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DescendingRangeSelect: 144>
    DisableConstraint: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DisableConstraint: 145>
    DisableForkStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DisableForkStatement: 146>
    DisableIff: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DisableIff: 147>
    DisableStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DisableStatement: 148>
    DistConstraintList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DistConstraintList: 149>
    DistItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DistItem: 150>
    DistWeight: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DistWeight: 151>
    DivideAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DivideAssignmentExpression: 152>
    DivideExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DivideExpression: 153>
    DividerClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DividerClause: 154>
    DoWhileStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DoWhileStatement: 155>
    DotMemberClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DotMemberClause: 156>
    DriveStrength: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.DriveStrength: 157>
    EdgeControlSpecifier: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EdgeControlSpecifier: 158>
    EdgeDescriptor: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EdgeDescriptor: 159>
    EdgeSensitivePathSuffix: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EdgeSensitivePathSuffix: 160>
    ElabSystemTask: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ElabSystemTask: 161>
    ElementSelect: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ElementSelect: 162>
    ElementSelectExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ElementSelectExpression: 163>
    ElsIfDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ElsIfDirective: 164>
    ElseClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ElseClause: 165>
    ElseConstraintClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ElseConstraintClause: 166>
    ElseDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ElseDirective: 167>
    ElsePropertyClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ElsePropertyClause: 168>
    EmptyArgument: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EmptyArgument: 169>
    EmptyIdentifierName: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EmptyIdentifierName: 170>
    EmptyMember: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EmptyMember: 171>
    EmptyNonAnsiPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EmptyNonAnsiPort: 172>
    EmptyPortConnection: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EmptyPortConnection: 173>
    EmptyQueueExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EmptyQueueExpression: 174>
    EmptyStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EmptyStatement: 175>
    EmptyTimingCheckArg: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EmptyTimingCheckArg: 176>
    EndCellDefineDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EndCellDefineDirective: 177>
    EndIfDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EndIfDirective: 178>
    EndKeywordsDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EndKeywordsDirective: 179>
    EndProtectDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EndProtectDirective: 180>
    EndProtectedDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EndProtectedDirective: 181>
    EnumType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EnumType: 182>
    EqualityExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EqualityExpression: 183>
    EqualsAssertionArgClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EqualsAssertionArgClause: 184>
    EqualsTypeClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EqualsTypeClause: 185>
    EqualsValueClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EqualsValueClause: 186>
    EventControl: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EventControl: 187>
    EventControlWithExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EventControlWithExpression: 188>
    EventType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.EventType: 189>
    ExpectPropertyStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExpectPropertyStatement: 190>
    ExplicitAnsiPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExplicitAnsiPort: 191>
    ExplicitNonAnsiPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExplicitNonAnsiPort: 192>
    ExpressionConstraint: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExpressionConstraint: 193>
    ExpressionCoverageBinInitializer: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExpressionCoverageBinInitializer: 194>
    ExpressionOrDist: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExpressionOrDist: 195>
    ExpressionPattern: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExpressionPattern: 196>
    ExpressionStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExpressionStatement: 197>
    ExpressionTimingCheckArg: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExpressionTimingCheckArg: 198>
    ExtendsClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExtendsClause: 199>
    ExternInterfaceMethod: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExternInterfaceMethod: 200>
    ExternModuleDecl: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExternModuleDecl: 201>
    ExternUdpDecl: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ExternUdpDecl: 202>
    FilePathSpec: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.FilePathSpec: 203>
    FinalBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.FinalBlock: 204>
    FirstMatchSequenceExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.FirstMatchSequenceExpr: 205>
    FollowedByPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.FollowedByPropertyExpr: 206>
    ForLoopStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ForLoopStatement: 207>
    ForVariableDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ForVariableDeclaration: 208>
    ForeachLoopList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ForeachLoopList: 209>
    ForeachLoopStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ForeachLoopStatement: 210>
    ForeverStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ForeverStatement: 211>
    ForwardTypeRestriction: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ForwardTypeRestriction: 212>
    ForwardTypedefDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ForwardTypedefDeclaration: 213>
    FunctionDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.FunctionDeclaration: 214>
    FunctionPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.FunctionPort: 215>
    FunctionPortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.FunctionPortList: 216>
    FunctionPrototype: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.FunctionPrototype: 217>
    GenerateBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.GenerateBlock: 218>
    GenerateRegion: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.GenerateRegion: 219>
    GenvarDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.GenvarDeclaration: 220>
    GreaterThanEqualExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.GreaterThanEqualExpression: 221>
    GreaterThanExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.GreaterThanExpression: 222>
    HierarchicalInstance: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.HierarchicalInstance: 223>
    HierarchyInstantiation: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.HierarchyInstantiation: 224>
    IdWithExprCoverageBinInitializer: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IdWithExprCoverageBinInitializer: 225>
    IdentifierName: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IdentifierName: 226>
    IdentifierSelectName: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IdentifierSelectName: 227>
    IfDefDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IfDefDirective: 228>
    IfGenerate: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IfGenerate: 229>
    IfNDefDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IfNDefDirective: 230>
    IfNonePathDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IfNonePathDeclaration: 231>
    IffEventClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IffEventClause: 232>
    IffPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IffPropertyExpr: 233>
    ImmediateAssertStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImmediateAssertStatement: 234>
    ImmediateAssertionMember: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImmediateAssertionMember: 235>
    ImmediateAssumeStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImmediateAssumeStatement: 236>
    ImmediateCoverStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImmediateCoverStatement: 237>
    ImplementsClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImplementsClause: 238>
    ImplicationConstraint: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImplicationConstraint: 239>
    ImplicationPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImplicationPropertyExpr: 240>
    ImplicitAnsiPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImplicitAnsiPort: 241>
    ImplicitEventControl: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImplicitEventControl: 242>
    ImplicitNonAnsiPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImplicitNonAnsiPort: 243>
    ImplicitType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImplicitType: 244>
    ImpliesPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ImpliesPropertyExpr: 245>
    IncludeDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IncludeDirective: 246>
    InequalityExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.InequalityExpression: 247>
    InitialBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.InitialBlock: 248>
    InsideExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.InsideExpression: 249>
    InstanceConfigRule: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.InstanceConfigRule: 250>
    InstanceName: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.InstanceName: 251>
    IntType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IntType: 252>
    IntegerLiteralExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IntegerLiteralExpression: 253>
    IntegerType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IntegerType: 254>
    IntegerVectorExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IntegerVectorExpression: 255>
    InterfaceDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.InterfaceDeclaration: 256>
    InterfaceHeader: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.InterfaceHeader: 257>
    InterfacePortHeader: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.InterfacePortHeader: 258>
    IntersectClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IntersectClause: 259>
    IntersectSequenceExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.IntersectSequenceExpr: 260>
    InvocationExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.InvocationExpression: 261>
    JumpStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.JumpStatement: 262>
    LessThanEqualExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LessThanEqualExpression: 263>
    LessThanExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LessThanExpression: 264>
    LetDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LetDeclaration: 265>
    LibraryDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LibraryDeclaration: 266>
    LibraryIncDirClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LibraryIncDirClause: 267>
    LibraryIncludeStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LibraryIncludeStatement: 268>
    LibraryMap: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LibraryMap: 269>
    LineDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LineDirective: 270>
    LocalScope: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LocalScope: 271>
    LocalVariableDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LocalVariableDeclaration: 272>
    LogicType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LogicType: 273>
    LogicalAndExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LogicalAndExpression: 274>
    LogicalEquivalenceExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LogicalEquivalenceExpression: 275>
    LogicalImplicationExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LogicalImplicationExpression: 276>
    LogicalLeftShiftAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LogicalLeftShiftAssignmentExpression: 277>
    LogicalOrExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LogicalOrExpression: 278>
    LogicalRightShiftAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LogicalRightShiftAssignmentExpression: 279>
    LogicalShiftLeftExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LogicalShiftLeftExpression: 280>
    LogicalShiftRightExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LogicalShiftRightExpression: 281>
    LongIntType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LongIntType: 282>
    LoopConstraint: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LoopConstraint: 283>
    LoopGenerate: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LoopGenerate: 284>
    LoopStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.LoopStatement: 285>
    MacroActualArgument: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MacroActualArgument: 286>
    MacroActualArgumentList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MacroActualArgumentList: 287>
    MacroArgumentDefault: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MacroArgumentDefault: 288>
    MacroFormalArgument: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MacroFormalArgument: 289>
    MacroFormalArgumentList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MacroFormalArgumentList: 290>
    MacroUsage: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MacroUsage: 291>
    MatchesClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MatchesClause: 292>
    MemberAccessExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MemberAccessExpression: 293>
    MinTypMaxExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MinTypMaxExpression: 294>
    ModAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModAssignmentExpression: 295>
    ModExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModExpression: 296>
    ModportClockingPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModportClockingPort: 297>
    ModportDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModportDeclaration: 298>
    ModportExplicitPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModportExplicitPort: 299>
    ModportItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModportItem: 300>
    ModportNamedPort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModportNamedPort: 301>
    ModportSimplePortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModportSimplePortList: 302>
    ModportSubroutinePort: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModportSubroutinePort: 303>
    ModportSubroutinePortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModportSubroutinePortList: 304>
    ModuleDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModuleDeclaration: 305>
    ModuleHeader: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ModuleHeader: 306>
    MultipleConcatenationExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MultipleConcatenationExpression: 307>
    MultiplyAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MultiplyAssignmentExpression: 308>
    MultiplyExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.MultiplyExpression: 309>
    NameValuePragmaExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NameValuePragmaExpression: 310>
    NamedArgument: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NamedArgument: 311>
    NamedBlockClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NamedBlockClause: 312>
    NamedConditionalDirectiveExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NamedConditionalDirectiveExpression: 313>
    NamedLabel: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NamedLabel: 314>
    NamedParamAssignment: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NamedParamAssignment: 315>
    NamedPortConnection: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NamedPortConnection: 316>
    NamedStructurePatternMember: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NamedStructurePatternMember: 317>
    NamedType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NamedType: 318>
    NetAlias: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NetAlias: 319>
    NetDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NetDeclaration: 320>
    NetPortHeader: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NetPortHeader: 321>
    NetTypeDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NetTypeDeclaration: 322>
    NewArrayExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NewArrayExpression: 323>
    NewClassExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NewClassExpression: 324>
    NoUnconnectedDriveDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NoUnconnectedDriveDirective: 325>
    NonAnsiPortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NonAnsiPortList: 326>
    NonAnsiUdpPortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NonAnsiUdpPortList: 327>
    NonblockingAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NonblockingAssignmentExpression: 328>
    NonblockingEventTriggerStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NonblockingEventTriggerStatement: 329>
    NullLiteralExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NullLiteralExpression: 330>
    NumberPragmaExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.NumberPragmaExpression: 331>
    OneStepDelay: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.OneStepDelay: 332>
    OrAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.OrAssignmentExpression: 333>
    OrPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.OrPropertyExpr: 334>
    OrSequenceExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.OrSequenceExpr: 335>
    OrderedArgument: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.OrderedArgument: 336>
    OrderedParamAssignment: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.OrderedParamAssignment: 337>
    OrderedPortConnection: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.OrderedPortConnection: 338>
    OrderedStructurePatternMember: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.OrderedStructurePatternMember: 339>
    PackageDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PackageDeclaration: 340>
    PackageExportAllDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PackageExportAllDeclaration: 341>
    PackageExportDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PackageExportDeclaration: 342>
    PackageHeader: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PackageHeader: 343>
    PackageImportDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PackageImportDeclaration: 344>
    PackageImportItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PackageImportItem: 345>
    ParallelBlockStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParallelBlockStatement: 346>
    ParameterDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParameterDeclaration: 347>
    ParameterDeclarationStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParameterDeclarationStatement: 348>
    ParameterPortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParameterPortList: 349>
    ParameterValueAssignment: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParameterValueAssignment: 350>
    ParenExpressionList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParenExpressionList: 351>
    ParenPragmaExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParenPragmaExpression: 352>
    ParenthesizedBinsSelectExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParenthesizedBinsSelectExpr: 353>
    ParenthesizedConditionalDirectiveExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParenthesizedConditionalDirectiveExpression: 354>
    ParenthesizedEventExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParenthesizedEventExpression: 355>
    ParenthesizedExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParenthesizedExpression: 356>
    ParenthesizedPattern: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParenthesizedPattern: 357>
    ParenthesizedPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParenthesizedPropertyExpr: 358>
    ParenthesizedSequenceExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ParenthesizedSequenceExpr: 359>
    PathDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PathDeclaration: 360>
    PathDescription: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PathDescription: 361>
    PatternCaseItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PatternCaseItem: 362>
    PortConcatenation: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PortConcatenation: 363>
    PortDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PortDeclaration: 364>
    PortReference: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PortReference: 365>
    PostdecrementExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PostdecrementExpression: 366>
    PostincrementExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PostincrementExpression: 367>
    PowerExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PowerExpression: 368>
    PragmaDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PragmaDirective: 369>
    PrimaryBlockEventExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PrimaryBlockEventExpression: 370>
    PrimitiveInstantiation: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PrimitiveInstantiation: 371>
    ProceduralAssignStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ProceduralAssignStatement: 372>
    ProceduralDeassignStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ProceduralDeassignStatement: 373>
    ProceduralForceStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ProceduralForceStatement: 374>
    ProceduralReleaseStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ProceduralReleaseStatement: 375>
    Production: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.Production: 376>
    ProgramDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ProgramDeclaration: 377>
    ProgramHeader: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ProgramHeader: 378>
    PropertyDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PropertyDeclaration: 379>
    PropertySpec: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PropertySpec: 380>
    PropertyType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PropertyType: 381>
    ProtectDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ProtectDirective: 382>
    ProtectedDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ProtectedDirective: 383>
    PullStrength: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PullStrength: 384>
    PulseStyleDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.PulseStyleDeclaration: 385>
    QueueDimensionSpecifier: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.QueueDimensionSpecifier: 386>
    RandCaseItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RandCaseItem: 387>
    RandCaseStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RandCaseStatement: 388>
    RandJoinClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RandJoinClause: 389>
    RandSequenceStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RandSequenceStatement: 390>
    RangeCoverageBinInitializer: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RangeCoverageBinInitializer: 391>
    RangeDimensionSpecifier: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RangeDimensionSpecifier: 392>
    RangeList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RangeList: 393>
    RealLiteralExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RealLiteralExpression: 394>
    RealTimeType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RealTimeType: 395>
    RealType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RealType: 396>
    RegType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RegType: 397>
    RepeatedEventControl: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RepeatedEventControl: 398>
    ReplicatedAssignmentPattern: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ReplicatedAssignmentPattern: 399>
    ResetAllDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ResetAllDirective: 400>
    RestrictPropertyStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RestrictPropertyStatement: 401>
    ReturnStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ReturnStatement: 402>
    RootScope: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RootScope: 403>
    RsCase: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RsCase: 404>
    RsCodeBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RsCodeBlock: 405>
    RsElseClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RsElseClause: 406>
    RsIfElse: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RsIfElse: 407>
    RsProdItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RsProdItem: 408>
    RsRepeat: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RsRepeat: 409>
    RsRule: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RsRule: 410>
    RsWeightClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.RsWeightClause: 411>
    SUntilPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SUntilPropertyExpr: 412>
    SUntilWithPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SUntilWithPropertyExpr: 413>
    ScopedName: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ScopedName: 414>
    SequenceDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SequenceDeclaration: 415>
    SequenceMatchList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SequenceMatchList: 416>
    SequenceRepetition: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SequenceRepetition: 417>
    SequenceType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SequenceType: 418>
    SequentialBlockStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SequentialBlockStatement: 419>
    ShortIntType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ShortIntType: 420>
    ShortRealType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ShortRealType: 421>
    SignalEventExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SignalEventExpression: 422>
    SignedCastExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SignedCastExpression: 423>
    SimpleAssignmentPattern: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SimpleAssignmentPattern: 424>
    SimpleBinsSelectExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SimpleBinsSelectExpr: 425>
    SimplePathSuffix: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SimplePathSuffix: 426>
    SimplePragmaExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SimplePragmaExpression: 427>
    SimplePropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SimplePropertyExpr: 428>
    SimpleRangeSelect: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SimpleRangeSelect: 429>
    SimpleSequenceExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SimpleSequenceExpr: 430>
    SolveBeforeConstraint: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SolveBeforeConstraint: 431>
    SpecifyBlock: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SpecifyBlock: 432>
    SpecparamDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SpecparamDeclaration: 433>
    SpecparamDeclarator: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SpecparamDeclarator: 434>
    StandardCaseItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StandardCaseItem: 435>
    StandardPropertyCaseItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StandardPropertyCaseItem: 436>
    StandardRsCaseItem: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StandardRsCaseItem: 437>
    StreamExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StreamExpression: 438>
    StreamExpressionWithRange: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StreamExpressionWithRange: 439>
    StreamingConcatenationExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StreamingConcatenationExpression: 440>
    StringLiteralExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StringLiteralExpression: 441>
    StringType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StringType: 442>
    StrongWeakPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StrongWeakPropertyExpr: 443>
    StructType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StructType: 444>
    StructUnionMember: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StructUnionMember: 445>
    StructurePattern: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StructurePattern: 446>
    StructuredAssignmentPattern: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.StructuredAssignmentPattern: 447>
    SubtractAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SubtractAssignmentExpression: 448>
    SubtractExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SubtractExpression: 449>
    SuperHandle: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SuperHandle: 450>
    SuperNewDefaultedArgsExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SuperNewDefaultedArgsExpression: 451>
    SystemName: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SystemName: 452>
    SystemTimingCheck: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.SystemTimingCheck: 453>
    TaggedPattern: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TaggedPattern: 454>
    TaggedUnionExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TaggedUnionExpression: 455>
    TaskDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TaskDeclaration: 456>
    ThisHandle: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ThisHandle: 457>
    ThroughoutSequenceExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ThroughoutSequenceExpr: 458>
    TimeLiteralExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TimeLiteralExpression: 459>
    TimeScaleDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TimeScaleDirective: 460>
    TimeType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TimeType: 461>
    TimeUnitsDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TimeUnitsDeclaration: 462>
    TimingCheckEventArg: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TimingCheckEventArg: 463>
    TimingCheckEventCondition: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TimingCheckEventCondition: 464>
    TimingControlExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TimingControlExpression: 465>
    TimingControlStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TimingControlStatement: 466>
    TransListCoverageBinInitializer: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TransListCoverageBinInitializer: 467>
    TransRange: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TransRange: 468>
    TransRepeatRange: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TransRepeatRange: 469>
    TransSet: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TransSet: 470>
    TypeAssignment: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TypeAssignment: 471>
    TypeParameterDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TypeParameterDeclaration: 472>
    TypeReference: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TypeReference: 473>
    TypedefDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.TypedefDeclaration: 474>
    UdpBody: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UdpBody: 475>
    UdpDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UdpDeclaration: 476>
    UdpEdgeField: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UdpEdgeField: 477>
    UdpEntry: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UdpEntry: 478>
    UdpInitialStmt: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UdpInitialStmt: 479>
    UdpInputPortDecl: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UdpInputPortDecl: 480>
    UdpOutputPortDecl: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UdpOutputPortDecl: 481>
    UdpSimpleField: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UdpSimpleField: 482>
    UnaryBinsSelectExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryBinsSelectExpr: 483>
    UnaryBitwiseAndExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryBitwiseAndExpression: 484>
    UnaryBitwiseNandExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryBitwiseNandExpression: 485>
    UnaryBitwiseNorExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryBitwiseNorExpression: 486>
    UnaryBitwiseNotExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryBitwiseNotExpression: 487>
    UnaryBitwiseOrExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryBitwiseOrExpression: 488>
    UnaryBitwiseXnorExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryBitwiseXnorExpression: 489>
    UnaryBitwiseXorExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryBitwiseXorExpression: 490>
    UnaryConditionalDirectiveExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryConditionalDirectiveExpression: 491>
    UnaryLogicalNotExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryLogicalNotExpression: 492>
    UnaryMinusExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryMinusExpression: 493>
    UnaryPlusExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryPlusExpression: 494>
    UnaryPredecrementExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryPredecrementExpression: 495>
    UnaryPreincrementExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryPreincrementExpression: 496>
    UnaryPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnaryPropertyExpr: 497>
    UnarySelectPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnarySelectPropertyExpr: 498>
    UnbasedUnsizedLiteralExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnbasedUnsizedLiteralExpression: 499>
    UnconnectedDriveDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnconnectedDriveDirective: 500>
    UndefDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UndefDirective: 501>
    UndefineAllDirective: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UndefineAllDirective: 502>
    UnionType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnionType: 503>
    UniquenessConstraint: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UniquenessConstraint: 504>
    UnitScope: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UnitScope: 505>
    Unknown: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.Unknown: 0>
    UntilPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UntilPropertyExpr: 506>
    UntilWithPropertyExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UntilWithPropertyExpr: 507>
    Untyped: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.Untyped: 508>
    UserDefinedNetDeclaration: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.UserDefinedNetDeclaration: 509>
    ValueRangeExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.ValueRangeExpression: 510>
    VariableDimension: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.VariableDimension: 511>
    VariablePattern: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.VariablePattern: 512>
    VariablePortHeader: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.VariablePortHeader: 513>
    VirtualInterfaceType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.VirtualInterfaceType: 514>
    VoidCastedCallStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.VoidCastedCallStatement: 515>
    VoidType: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.VoidType: 516>
    WaitForkStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WaitForkStatement: 517>
    WaitOrderStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WaitOrderStatement: 518>
    WaitStatement: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WaitStatement: 519>
    WildcardDimensionSpecifier: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WildcardDimensionSpecifier: 520>
    WildcardEqualityExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WildcardEqualityExpression: 521>
    WildcardInequalityExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WildcardInequalityExpression: 522>
    WildcardLiteralExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WildcardLiteralExpression: 523>
    WildcardPattern: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WildcardPattern: 524>
    WildcardPortConnection: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WildcardPortConnection: 525>
    WildcardPortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WildcardPortList: 526>
    WildcardUdpPortList: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WildcardUdpPortList: 527>
    WithClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WithClause: 528>
    WithFunctionClause: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WithFunctionClause: 529>
    WithFunctionSample: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WithFunctionSample: 530>
    WithinSequenceExpr: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.WithinSequenceExpr: 531>
    XorAssignmentExpression: typing.ClassVar[SyntaxKind]  # value = <SyntaxKind.XorAssignmentExpression: 532>
class SyntaxNode:
    def __getitem__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> typing.Any:
        ...
    def __iter__(self) -> collections.abc.Iterator[typing.Any]:
        ...
    def __len__(self) -> int:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def getFirstToken(self) -> pyslang.parsing.Token:
        ...
    def getLastToken(self) -> pyslang.parsing.Token:
        ...
    def isEquivalentTo(self, other: SyntaxNode) -> bool:
        ...
    def to_json(self, mode: CSTJsonMode = ...) -> str:
        """
        Convert this syntax node to JSON string with optional formatting mode
        """
    def visit(self, f: typing.Any = None, lookup_table: typing.Any = None) -> None:
        """
        Visit a pyslang object with a callback function `f` or a `lookup_table` dict.
        
        At least one of `f` or `lookup_table` must be provided (both default to `None`). If both are provided, 'lookup_table' will be used to decide which callback to use.
        
        When `f` is provided without `lookup_table`, it is called for every node visited. The callback should take a single argument (the current node). Its return value controls traversal: `pyslang.VisitAction.Interrupt` aborts the visit, `pyslang.VisitAction.Skip` skips child nodes, and any other return value (including `pyslang.VisitAction.Advance` or `None`) continues normally.
        
        When `lookup_table` is provided, it should be a dict mapping node kind enum values to handler functions. The C++ side checks each node's kind before crossing the Python boundary, calling only the matching handler. Nodes not in the table are traversed without invoking Python. `f` is not called in this mode.
        """
    @property
    def kind(self) -> SyntaxKind:
        ...
    @property
    def parent(self) -> SyntaxNode:
        ...
    @property
    def sourceRange(self) -> pyslang.SourceRange:
        ...
class SyntaxPrinter:
    @staticmethod
    def printFile(tree: SyntaxTree) -> str:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, sourceManager: pyslang.SourceManager) -> None:
        ...
    def append(self, text: str) -> SyntaxPrinter:
        ...
    @typing.overload
    def print(self, trivia: pyslang.parsing.Trivia) -> SyntaxPrinter:
        ...
    @typing.overload
    def print(self, token: pyslang.parsing.Token) -> SyntaxPrinter:
        ...
    @typing.overload
    def print(self, node: SyntaxNode) -> SyntaxPrinter:
        ...
    @typing.overload
    def print(self, tree: SyntaxTree) -> SyntaxPrinter:
        ...
    def setExpandIncludes(self, expand: bool) -> SyntaxPrinter:
        ...
    def setExpandMacros(self, expand: bool) -> SyntaxPrinter:
        ...
    def setIncludeComments(self, include: bool) -> SyntaxPrinter:
        ...
    def setIncludeDirectives(self, include: bool) -> SyntaxPrinter:
        ...
    def setIncludeMissing(self, include: bool) -> SyntaxPrinter:
        ...
    def setIncludeSkipped(self, include: bool) -> SyntaxPrinter:
        ...
    def setIncludeTrivia(self, include: bool) -> SyntaxPrinter:
        ...
    def setSquashNewlines(self, include: bool) -> SyntaxPrinter:
        ...
    def str(self) -> str:
        ...
class SyntaxRewriter:
    def clone(self, node: SyntaxNode) -> SyntaxNode:
        """
        Create a shallow clone of the given syntax node
        """
    def deepClone(self, node: SyntaxNode) -> SyntaxNode:
        """
        Create a deep clone of the given syntax node and all its children
        """
    def insertAfter(self, arg0: SyntaxNode, arg1: SyntaxNode) -> None:
        ...
    @typing.overload
    def insertAtBack(self, list: SyntaxList, newNode: SyntaxNode, separator: pyslang.parsing.Token = ...) -> None:
        ...
    @typing.overload
    def insertAtBack(self, list: SeparatedSyntaxList, newNode: SyntaxNode, separator: pyslang.parsing.Token = ...) -> None:
        ...
    @typing.overload
    def insertAtFront(self, list: SyntaxList, newNode: SyntaxNode, separator: pyslang.parsing.Token = ...) -> None:
        ...
    @typing.overload
    def insertAtFront(self, list: SeparatedSyntaxList, newNode: SyntaxNode, separator: pyslang.parsing.Token = ...) -> None:
        ...
    def insertBefore(self, arg0: SyntaxNode, arg1: SyntaxNode) -> None:
        ...
    def makeComma(self) -> pyslang.parsing.Token:
        """
        Create a comma token
        """
    def makeId(self, text: str, trivia: span[pyslang.parsing.Trivia] = []) -> pyslang.parsing.Token:
        """
        Create an identifier token
        """
    def makeList(self, items: list) -> SyntaxList:
        """
        Create a SyntaxList from a list of syntax nodes
        """
    def makeSeparatedList(self, items: list) -> SeparatedSyntaxList:
        """
        Create a SeparatedSyntaxList from a list of syntax nodes and separator tokens
        """
    @typing.overload
    def makeToken(self, kind: pyslang.parsing.TokenKind, text: str, trivia: span[pyslang.parsing.Trivia] = []) -> pyslang.parsing.Token:
        """
        Create a new token with the given kind and text
        """
    @typing.overload
    def makeToken(self, kind: pyslang.parsing.TokenKind, trivia: span[pyslang.parsing.Trivia] = []) -> pyslang.parsing.Token:
        """
        Create a token with text inferred from kind (for keywords/punctuation)
        """
    def makeTokenList(self, items: list) -> TokenList:
        """
        Create a TokenList from a list of tokens
        """
    def makeTrivia(self, kind: pyslang.parsing.TriviaKind, text: str) -> pyslang.parsing.Trivia:
        """
        Create a trivia with text allocated in the rewriter's allocator
        """
    def remove(self, arg0: SyntaxNode) -> None:
        ...
    def replace(self, oldNode: SyntaxNode, newNode: SyntaxNode, preserveTrivia: bool = False) -> None:
        ...
    @property
    def alloc(self) -> pyslang.BumpAllocator:
        """
        Get the allocator for creating tokens and trivia
        """
    @property
    def factory(self) -> ...:
        """
        Get the SyntaxFactory for creating new syntax nodes
        """
class SyntaxTree:
    @staticmethod
    def fromBuffer(buffer: pyslang.SourceBuffer, sourceManager: pyslang.SourceManager, options: pyslang.Bag = ..., inheritedMacros: span[...] = []) -> SyntaxTree:
        ...
    @staticmethod
    def fromBuffers(buffers: span[pyslang.SourceBuffer], sourceManager: pyslang.SourceManager, options: pyslang.Bag = ..., inheritedMacros: span[...] = []) -> SyntaxTree:
        ...
    @staticmethod
    @typing.overload
    def fromFile(path: str) -> SyntaxTree:
        ...
    @staticmethod
    @typing.overload
    def fromFile(path: str, sourceManager: pyslang.SourceManager, options: pyslang.Bag = ...) -> SyntaxTree:
        ...
    @staticmethod
    def fromFileInMemory(text: str, sourceManager: pyslang.SourceManager, name: str = 'source', path: str = '', options: pyslang.Bag = ...) -> SyntaxTree:
        ...
    @staticmethod
    @typing.overload
    def fromFiles(paths: span[str]) -> SyntaxTree:
        ...
    @staticmethod
    @typing.overload
    def fromFiles(paths: span[str], sourceManager: pyslang.SourceManager, options: pyslang.Bag = ...) -> SyntaxTree:
        ...
    @staticmethod
    def fromLibraryMapBuffer(buffer: pyslang.SourceBuffer, sourceManager: pyslang.SourceManager, options: pyslang.Bag = ...) -> SyntaxTree:
        ...
    @staticmethod
    def fromLibraryMapFile(path: str, sourceManager: pyslang.SourceManager, options: pyslang.Bag = ...) -> SyntaxTree:
        ...
    @staticmethod
    def fromLibraryMapText(text: str, sourceManager: pyslang.SourceManager, name: str = 'source', path: str = '', options: pyslang.Bag = ...) -> SyntaxTree:
        ...
    @staticmethod
    @typing.overload
    def fromText(text: str, name: str = 'source', path: str = '') -> SyntaxTree:
        ...
    @staticmethod
    @typing.overload
    def fromText(text: str, sourceManager: pyslang.SourceManager, name: str = 'source', path: str = '', options: pyslang.Bag = ..., library: pyslang.SourceLibrary = None) -> SyntaxTree:
        ...
    @staticmethod
    def getDefaultSourceManager() -> pyslang.SourceManager:
        ...
    def getIncludeDirectives(self) -> span[IncludeMetadata]:
        ...
    def to_json(self, mode: CSTJsonMode = ...) -> str:
        """
        Convert this syntax tree to JSON string with optional formatting mode
        """
    def validate(self) -> bool:
        ...
    @property
    def diagnostics(self) -> pyslang.Diagnostics:
        ...
    @property
    def isLibraryUnit(self) -> bool:
        ...
    @property
    def options(self) -> pyslang.Bag:
        ...
    @property
    def root(self) -> SyntaxNode:
        ...
    @property
    def sourceLibrary(self) -> pyslang.SourceLibrary:
        ...
    @property
    def sourceManager(self) -> pyslang.SourceManager:
        ...
class SystemNameSyntax(NameSyntax):
    systemIdentifier: pyslang.parsing.Token
class SystemTimingCheckSyntax(MemberSyntax):
    args: SeparatedSyntaxList
    closeParen: pyslang.parsing.Token
    name: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class TaggedPatternSyntax(PatternSyntax):
    memberName: pyslang.parsing.Token
    pattern: PatternSyntax
    tagged: pyslang.parsing.Token
class TaggedUnionExpressionSyntax(ExpressionSyntax):
    expr: ExpressionSyntax
    member: pyslang.parsing.Token
    tagged: pyslang.parsing.Token
class TimeScaleDirectiveSyntax(DirectiveSyntax):
    slash: pyslang.parsing.Token
    timePrecision: pyslang.parsing.Token
    timeUnit: pyslang.parsing.Token
class TimeUnitsDeclarationSyntax(MemberSyntax):
    divider: DividerClauseSyntax
    keyword: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    time: pyslang.parsing.Token
class TimingCheckArgSyntax(SyntaxNode):
    pass
class TimingCheckEventArgSyntax(TimingCheckArgSyntax):
    condition: TimingCheckEventConditionSyntax
    controlSpecifier: EdgeControlSpecifierSyntax
    edge: pyslang.parsing.Token
    terminal: ExpressionSyntax
class TimingCheckEventConditionSyntax(SyntaxNode):
    expr: ExpressionSyntax
    tripleAnd: pyslang.parsing.Token
class TimingControlExpressionSyntax(ExpressionSyntax):
    expr: ExpressionSyntax
    timing: TimingControlSyntax
class TimingControlStatementSyntax(StatementSyntax):
    statement: StatementSyntax
    timingControl: TimingControlSyntax
class TimingControlSyntax(SyntaxNode):
    pass
class TransListCoverageBinInitializerSyntax(CoverageBinInitializerSyntax):
    sets: SeparatedSyntaxList
class TransRangeSyntax(SyntaxNode):
    items: SeparatedSyntaxList
    repeat: TransRepeatRangeSyntax
class TransRepeatRangeSyntax(SyntaxNode):
    closeBracket: pyslang.parsing.Token
    openBracket: pyslang.parsing.Token
    selector: SelectorSyntax
    specifier: pyslang.parsing.Token
class TransSetSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    ranges: SeparatedSyntaxList
class TypeAssignmentSyntax(SyntaxNode):
    assignment: EqualsTypeClauseSyntax
    name: pyslang.parsing.Token
class TypeParameterDeclarationSyntax(ParameterDeclarationBaseSyntax):
    declarators: SeparatedSyntaxList
    typeKeyword: pyslang.parsing.Token
    typeRestriction: ForwardTypeRestrictionSyntax
class TypeReferenceSyntax(DataTypeSyntax):
    closeParen: pyslang.parsing.Token
    expr: ExpressionSyntax
    openParen: pyslang.parsing.Token
    typeKeyword: pyslang.parsing.Token
class TypedefDeclarationSyntax(MemberSyntax):
    dimensions: SyntaxList
    name: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    type: DataTypeSyntax
    typedefKeyword: pyslang.parsing.Token
class UdpBodySyntax(SyntaxNode):
    endtable: pyslang.parsing.Token
    entries: SyntaxList
    initialStmt: UdpInitialStmtSyntax
    portDecls: SeparatedSyntaxList
    table: pyslang.parsing.Token
class UdpDeclarationSyntax(MemberSyntax):
    body: UdpBodySyntax
    endBlockName: NamedBlockClauseSyntax
    endprimitive: pyslang.parsing.Token
    name: pyslang.parsing.Token
    portList: UdpPortListSyntax
    primitive: pyslang.parsing.Token
class UdpEdgeFieldSyntax(UdpFieldBaseSyntax):
    closeParen: pyslang.parsing.Token
    first: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    second: pyslang.parsing.Token
class UdpEntrySyntax(SyntaxNode):
    colon1: pyslang.parsing.Token
    colon2: pyslang.parsing.Token
    current: UdpFieldBaseSyntax
    inputs: SyntaxList
    next: UdpFieldBaseSyntax
    semi: pyslang.parsing.Token
class UdpFieldBaseSyntax(SyntaxNode):
    pass
class UdpInitialStmtSyntax(SyntaxNode):
    equals: pyslang.parsing.Token
    initial: pyslang.parsing.Token
    name: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    value: ExpressionSyntax
class UdpInputPortDeclSyntax(UdpPortDeclSyntax):
    keyword: pyslang.parsing.Token
    names: SeparatedSyntaxList
class UdpOutputPortDeclSyntax(UdpPortDeclSyntax):
    initializer: EqualsValueClauseSyntax
    keyword: pyslang.parsing.Token
    name: pyslang.parsing.Token
    reg: pyslang.parsing.Token
class UdpPortDeclSyntax(SyntaxNode):
    attributes: SyntaxList
class UdpPortListSyntax(SyntaxNode):
    pass
class UdpSimpleFieldSyntax(UdpFieldBaseSyntax):
    field: pyslang.parsing.Token
class UnaryBinsSelectExprSyntax(BinsSelectExpressionSyntax):
    expr: BinsSelectConditionExprSyntax
    op: pyslang.parsing.Token
class UnaryConditionalDirectiveExpressionSyntax(ConditionalDirectiveExpressionSyntax):
    op: pyslang.parsing.Token
    operand: ConditionalDirectiveExpressionSyntax
class UnaryPropertyExprSyntax(PropertyExprSyntax):
    expr: PropertyExprSyntax
    op: pyslang.parsing.Token
class UnarySelectPropertyExprSyntax(PropertyExprSyntax):
    closeBracket: pyslang.parsing.Token
    expr: PropertyExprSyntax
    op: pyslang.parsing.Token
    openBracket: pyslang.parsing.Token
    selector: SelectorSyntax
class UnconditionalBranchDirectiveSyntax(DirectiveSyntax):
    disabledTokens: TokenList
class UnconnectedDriveDirectiveSyntax(DirectiveSyntax):
    strength: pyslang.parsing.Token
class UndefDirectiveSyntax(DirectiveSyntax):
    name: pyslang.parsing.Token
class UniquenessConstraintSyntax(ConstraintItemSyntax):
    ranges: RangeListSyntax
    semi: pyslang.parsing.Token
    unique: pyslang.parsing.Token
class UserDefinedNetDeclarationSyntax(MemberSyntax):
    declarators: SeparatedSyntaxList
    delay: TimingControlSyntax
    netType: pyslang.parsing.Token
    semi: pyslang.parsing.Token
class ValueRangeExpressionSyntax(ExpressionSyntax):
    closeBracket: pyslang.parsing.Token
    left: ExpressionSyntax
    op: pyslang.parsing.Token
    openBracket: pyslang.parsing.Token
    right: ExpressionSyntax
class VariableDimensionSyntax(SyntaxNode):
    closeBracket: pyslang.parsing.Token
    openBracket: pyslang.parsing.Token
    specifier: DimensionSpecifierSyntax
class VariablePatternSyntax(PatternSyntax):
    dot: pyslang.parsing.Token
    variableName: pyslang.parsing.Token
class VariablePortHeaderSyntax(PortHeaderSyntax):
    constKeyword: pyslang.parsing.Token
    dataType: DataTypeSyntax
    direction: pyslang.parsing.Token
    varKeyword: pyslang.parsing.Token
class VirtualInterfaceTypeSyntax(DataTypeSyntax):
    interfaceKeyword: pyslang.parsing.Token
    modport: DotMemberClauseSyntax
    name: pyslang.parsing.Token
    parameters: ParameterValueAssignmentSyntax
    virtualKeyword: pyslang.parsing.Token
class VoidCastedCallStatementSyntax(StatementSyntax):
    apostrophe: pyslang.parsing.Token
    closeParen: pyslang.parsing.Token
    expr: ExpressionSyntax
    openParen: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    voidKeyword: pyslang.parsing.Token
class WaitForkStatementSyntax(StatementSyntax):
    fork: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    wait: pyslang.parsing.Token
class WaitOrderStatementSyntax(StatementSyntax):
    action: ActionBlockSyntax
    closeParen: pyslang.parsing.Token
    names: SeparatedSyntaxList
    openParen: pyslang.parsing.Token
    wait_order: pyslang.parsing.Token
class WaitStatementSyntax(StatementSyntax):
    closeParen: pyslang.parsing.Token
    expr: ExpressionSyntax
    openParen: pyslang.parsing.Token
    statement: StatementSyntax
    wait: pyslang.parsing.Token
class WildcardDimensionSpecifierSyntax(DimensionSpecifierSyntax):
    star: pyslang.parsing.Token
class WildcardPatternSyntax(PatternSyntax):
    dot: pyslang.parsing.Token
    star: pyslang.parsing.Token
class WildcardPortConnectionSyntax(PortConnectionSyntax):
    dot: pyslang.parsing.Token
    star: pyslang.parsing.Token
class WildcardPortListSyntax(PortListSyntax):
    closeParen: pyslang.parsing.Token
    dot: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    star: pyslang.parsing.Token
class WildcardUdpPortListSyntax(UdpPortListSyntax):
    closeParen: pyslang.parsing.Token
    dot: pyslang.parsing.Token
    openParen: pyslang.parsing.Token
    semi: pyslang.parsing.Token
    star: pyslang.parsing.Token
class WithClauseSyntax(SyntaxNode):
    closeParen: pyslang.parsing.Token
    expr: ExpressionSyntax
    openParen: pyslang.parsing.Token
    with_: pyslang.parsing.Token
class WithFunctionClauseSyntax(SyntaxNode):
    name: NameSyntax
    with_: pyslang.parsing.Token
class WithFunctionSampleSyntax(SyntaxNode):
    function: pyslang.parsing.Token
    portList: FunctionPortListSyntax
    sample: pyslang.parsing.Token
    with_: pyslang.parsing.Token
def clone(node: SyntaxNode, alloc: pyslang.BumpAllocator) -> SyntaxNode:
    """
    Create a shallow clone of the given syntax node
    """
def deepClone(node: SyntaxNode, alloc: pyslang.BumpAllocator) -> SyntaxNode:
    """
    Create a deep clone of the given syntax node and all its children
    """
def rewrite(tree: SyntaxTree, handler: collections.abc.Callable) -> SyntaxTree:
    ...
