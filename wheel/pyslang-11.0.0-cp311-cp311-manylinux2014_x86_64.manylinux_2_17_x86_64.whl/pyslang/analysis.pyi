"""
Code analysis utilities
"""
from __future__ import annotations
import collections.abc
import enum
import typing
__all__: list[str] = ['AnalysisFlags', 'AnalysisManager', 'AnalysisOptions', 'AnalyzedAssertion', 'AnalyzedProcedure', 'AnalyzedScope', 'DriverFlags', 'DriverKind', 'DriverSource', 'FlowAnalysis', 'ImplicitEventReadSet', 'ReadRange', 'SensitivityList', 'SensitivityListKind', 'ValueDriver']
class AnalysisFlags(enum.Flag):
    AllowDupInitialDrivers: typing.ClassVar[AnalysisFlags]  # value = <AnalysisFlags.AllowDupInitialDrivers: 16>
    AllowMultiDrivenLocals: typing.ClassVar[AnalysisFlags]  # value = <AnalysisFlags.AllowMultiDrivenLocals: 8>
    AlwaysStarUsesLSPs: typing.ClassVar[AnalysisFlags]  # value = <AnalysisFlags.AlwaysStarUsesLSPs: 128>
    CheckShadow: typing.ClassVar[AnalysisFlags]  # value = <AnalysisFlags.CheckShadow: 32>
    CheckUnused: typing.ClassVar[AnalysisFlags]  # value = <AnalysisFlags.CheckUnused: 1>
    ContAssignUsesLSPs: typing.ClassVar[AnalysisFlags]  # value = <AnalysisFlags.ContAssignUsesLSPs: 256>
    FullCaseFourState: typing.ClassVar[AnalysisFlags]  # value = <AnalysisFlags.FullCaseFourState: 4>
    FullCaseUniquePriority: typing.ClassVar[AnalysisFlags]  # value = <AnalysisFlags.FullCaseUniquePriority: 2>
    InlineContAssignFunctionReads: typing.ClassVar[AnalysisFlags]  # value = <AnalysisFlags.InlineContAssignFunctionReads: 64>
class AnalysisManager:
    def __init__(self, options: AnalysisOptions = ...) -> None:
        ...
    def addAssertionListener(self, listener: collections.abc.Callable) -> None:
        ...
    def addProcListener(self, listener: collections.abc.Callable) -> None:
        ...
    def addScopeListener(self, listener: collections.abc.Callable) -> None:
        ...
    def analyze(self, compilation: ...) -> None:
        ...
    def getAnalyzedAssertions(self, symbol: ...) -> list[...]:
        ...
    def getAnalyzedScope(self, scope: ...) -> AnalyzedScope:
        ...
    def getAnalyzedSubroutine(self, symbol: ...) -> ...:
        ...
    def getDiagnostics(self) -> ...:
        ...
    def getDrivers(self, symbol: ...) -> list[ValueDriver]:
        ...
    @property
    def options(self) -> AnalysisOptions:
        ...
class AnalysisOptions:
    flags: AnalysisFlags
    def __init__(self) -> None:
        ...
    @property
    def maxCaseAnalysisSteps(self) -> int:
        ...
    @maxCaseAnalysisSteps.setter
    def maxCaseAnalysisSteps(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def maxLoopAnalysisSteps(self) -> int:
        ...
    @maxLoopAnalysisSteps.setter
    def maxLoopAnalysisSteps(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
class AnalyzedAssertion:
    def getClock(self, expr: ...) -> ...:
        ...
    @property
    def astNode(self) -> ... | ...:
        ...
    @property
    def containingSymbol(self) -> ...:
        ...
    @property
    def procedure(self) -> AnalyzedProcedure:
        ...
    @property
    def root(self) -> ...:
        ...
    @property
    def semanticLeadingClock(self) -> ...:
        ...
class AnalyzedProcedure:
    @property
    def analyzedSymbol(self) -> ...:
        ...
    @property
    def callExpressions(self) -> span[...]:
        ...
    @property
    def drivers(self) -> span[ValueDriver]:
        ...
    @property
    def implicitEventReadSets(self) -> span[ImplicitEventReadSet]:
        ...
    @property
    def inferredClock(self) -> ...:
        ...
    @property
    def parentProcedure(self) -> AnalyzedProcedure:
        ...
    @property
    def readSet(self) -> span[ReadRange]:
        ...
    @property
    def sensitivityList(self) -> SensitivityList:
        ...
    @property
    def timingControls(self) -> span[...]:
        ...
class AnalyzedScope:
    @property
    def procedures(self) -> list[...]:
        ...
    @property
    def scope(self) -> ...:
        ...
class DriverFlags(enum.Flag):
    ClockVar: typing.ClassVar[DriverFlags]  # value = <DriverFlags.ClockVar: 4>
    FromSideEffect: typing.ClassVar[DriverFlags]  # value = <DriverFlags.FromSideEffect: 16>
    HasOverrideRange: typing.ClassVar[DriverFlags]  # value = <DriverFlags.HasOverrideRange: 32>
    Initializer: typing.ClassVar[DriverFlags]  # value = <DriverFlags.Initializer: 8>
    InputPort: typing.ClassVar[DriverFlags]  # value = <DriverFlags.InputPort: 1>
    OutputPort: typing.ClassVar[DriverFlags]  # value = <DriverFlags.OutputPort: 2>
    ViaIndirectPort: typing.ClassVar[DriverFlags]  # value = <DriverFlags.ViaIndirectPort: 64>
class DriverKind(enum.Enum):
    Continuous: typing.ClassVar[DriverKind]  # value = <DriverKind.Continuous: 1>
    Procedural: typing.ClassVar[DriverKind]  # value = <DriverKind.Procedural: 0>
class DriverSource(enum.Enum):
    Always: typing.ClassVar[DriverSource]  # value = <DriverSource.Always: 2>
    AlwaysComb: typing.ClassVar[DriverSource]  # value = <DriverSource.AlwaysComb: 3>
    AlwaysFF: typing.ClassVar[DriverSource]  # value = <DriverSource.AlwaysFF: 5>
    AlwaysLatch: typing.ClassVar[DriverSource]  # value = <DriverSource.AlwaysLatch: 4>
    Final: typing.ClassVar[DriverSource]  # value = <DriverSource.Final: 1>
    Initial: typing.ClassVar[DriverSource]  # value = <DriverSource.Initial: 0>
    Other: typing.ClassVar[DriverSource]  # value = <DriverSource.Other: 7>
    Subroutine: typing.ClassVar[DriverSource]  # value = <DriverSource.Subroutine: 6>
class FlowAnalysis:
    """
    A flow analysis visitor that walks statements with proper control flow handling.
    
    Set callback attributes before calling run():
    - onAssignment: called for each assignment expression
    - onVariableRef: called for each variable reference (NamedValueExpression)
    - onCallExpression: called for each function/task call
    - onConditionalBegin: called when entering an if/else
    - onCaseBegin: called when entering a case statement
    - onLoopBegin: called when entering any loop statement
    - onBranchMerge: called when control flow paths merge (state1, state2) -> merged_state
    - onStateCopy: called to copy state when forking (state) -> copied_state
    - createTopState: called to create initial state () -> state
    """
    def __init__(self, symbol: ..., options: AnalysisOptions = ...) -> None:
        """
        Create a flow analysis for the given symbol (procedural block, subroutine, etc.)
        """
    @typing.overload
    def run(self, stmt: ...) -> None:
        """
        Run the analysis on a statement
        """
    @typing.overload
    def run(self, expr: ...) -> None:
        """
        Run the analysis on an expression
        """
    @property
    def bad(self) -> bool:
        """
        True if the analysis detected an error
        """
    @property
    def createTopState(self) -> typing.Any:
        """
        Callback to create initial state: () -> state
        """
    @createTopState.setter
    def createTopState(self, arg0: typing.Any) -> None:
        ...
    @property
    def currentState(self) -> typing.Any:
        """
        The current flow state's user data
        """
    @currentState.setter
    def currentState(self, arg1: typing.Any) -> None:
        ...
    @property
    def evalContext(self) -> ...:
        """
        The evaluation context for use during analysis
        """
    @property
    def onAssignment(self) -> typing.Any:
        """
        Callback for assignment expressions: (AssignmentExpression) -> None
        """
    @onAssignment.setter
    def onAssignment(self, arg0: typing.Any) -> None:
        ...
    @property
    def onBranchMerge(self) -> typing.Any:
        """
        Callback when branches merge: (state1, state2) -> merged_state
        """
    @onBranchMerge.setter
    def onBranchMerge(self, arg0: typing.Any) -> None:
        ...
    @property
    def onCallExpression(self) -> typing.Any:
        """
        Callback for function/task calls: (CallExpression) -> None
        """
    @onCallExpression.setter
    def onCallExpression(self, arg0: typing.Any) -> None:
        ...
    @property
    def onCaseBegin(self) -> typing.Any:
        """
        Callback when entering case: (CaseStatement) -> None
        """
    @onCaseBegin.setter
    def onCaseBegin(self, arg0: typing.Any) -> None:
        ...
    @property
    def onConditionalBegin(self) -> typing.Any:
        """
        Callback when entering conditional: (ConditionalStatement) -> None
        """
    @onConditionalBegin.setter
    def onConditionalBegin(self, arg0: typing.Any) -> None:
        ...
    @property
    def onLoopBegin(self) -> typing.Any:
        """
        Callback when entering any loop: (Statement) -> None
        """
    @onLoopBegin.setter
    def onLoopBegin(self, arg0: typing.Any) -> None:
        ...
    @property
    def onStateCopy(self) -> typing.Any:
        """
        Callback to copy state: (state) -> copied_state
        """
    @onStateCopy.setter
    def onStateCopy(self, arg0: typing.Any) -> None:
        ...
    @property
    def onVariableRef(self) -> typing.Any:
        """
        Callback for variable references: (NamedValueExpression) -> None
        """
    @onVariableRef.setter
    def onVariableRef(self, arg0: typing.Any) -> None:
        ...
class ImplicitEventReadSet:
    @property
    def reads(self) -> span[ReadRange]:
        ...
    @property
    def statement(self) -> ...:
        ...
class ReadRange:
    @property
    def bitRange(self) -> tuple[int, int]:
        ...
    @property
    def symbol(self) -> ...:
        ...
class SensitivityList:
    @property
    def kind(self) -> SensitivityListKind:
        ...
    @property
    def reads(self) -> span[ReadRange]:
        ...
    @property
    def timingControl(self) -> ...:
        ...
class SensitivityListKind(enum.Enum):
    Dynamic: typing.ClassVar[SensitivityListKind]  # value = <SensitivityListKind.Dynamic: 3>
    Explicit: typing.ClassVar[SensitivityListKind]  # value = <SensitivityListKind.Explicit: 1>
    Implicit: typing.ClassVar[SensitivityListKind]  # value = <SensitivityListKind.Implicit: 2>
    None_: typing.ClassVar[SensitivityListKind]  # value = <SensitivityListKind.None_: 0>
class ValueDriver:
    @property
    def bounds(self) -> tuple[int, int]:
        ...
    @property
    def containingSymbol(self) -> ...:
        ...
    @property
    def flags(self) -> DriverFlags:
        ...
    @property
    def isClockVar(self) -> bool:
        ...
    @property
    def isInSingleDriverProcedure(self) -> bool:
        ...
    @property
    def isInputPort(self) -> bool:
        ...
    @property
    def isUnidirectionalPort(self) -> bool:
        ...
    @property
    def kind(self) -> DriverKind:
        ...
    @property
    def overrideRange(self) -> ...:
        ...
    @property
    def path(self) -> ...:
        ...
    @property
    def source(self) -> DriverSource:
        ...
    @property
    def sourceRange(self) -> ...:
        ...
    @property
    def symbol(self) -> ...:
        ...
