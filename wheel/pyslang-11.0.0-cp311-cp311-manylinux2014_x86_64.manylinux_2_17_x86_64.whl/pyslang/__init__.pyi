"""
Python bindings for slang, the SystemVerilog compiler library
"""
from __future__ import annotations
import collections.abc
import enum
import pathlib
import typing
from . import analysis
from . import ast
from . import driver
from . import parsing
from . import syntax
__all__: list[str] = ['Bag', 'BufferID', 'BufferKind', 'BumpAllocator', 'ColumnUnit', 'ConstantRange', 'ConstantValue', 'DiagCode', 'DiagGroup', 'DiagSubsystem', 'Diagnostic', 'DiagnosticClient', 'DiagnosticEngine', 'DiagnosticSeverity', 'Diagnostics', 'Diags', 'LanguageVersion', 'LiteralBase', 'Null', 'PreprocessOutputFlags', 'ReportedDiagnostic', 'SVInt', 'SourceBuffer', 'SourceLibrary', 'SourceLocation', 'SourceManager', 'SourceRange', 'TextDiagnosticClient', 'TimeScale', 'TimeScaleMagnitude', 'TimeScaleValue', 'TimeUnit', 'Unbounded', 'VersionInfo', 'analysis', 'ast', 'clog2', 'driver', 'literalBaseFromChar', 'logic_t', 'parsing', 'syntax']
class Bag:
    compilationOptions: ast.CompilationOptions
    lexerOptions: ...
    parserOptions: ...
    preprocessorOptions: ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, list: list) -> None:
        ...
class BufferID:
    placeholder: typing.ClassVar[BufferID]  # value = BufferID(4294967295)
    @staticmethod
    def getPlaceholder() -> BufferID:
        ...
    def __bool__(self) -> bool:
        ...
    def __eq__(self, arg0: BufferID) -> bool:
        ...
    def __ge__(self, arg0: BufferID) -> bool:
        ...
    def __gt__(self, arg0: BufferID) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    def __init__(self) -> None:
        ...
    def __le__(self, arg0: BufferID) -> bool:
        ...
    def __lt__(self, arg0: BufferID) -> bool:
        ...
    def __ne__(self, arg0: BufferID) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def id(self) -> int:
        ...
class BufferKind(enum.Enum):
    DesignFile: typing.ClassVar[BufferKind]  # value = <BufferKind.DesignFile: 1>
    IncludeFile: typing.ClassVar[BufferKind]  # value = <BufferKind.IncludeFile: 4>
    LibraryFile: typing.ClassVar[BufferKind]  # value = <BufferKind.LibraryFile: 2>
    LibraryMap: typing.ClassVar[BufferKind]  # value = <BufferKind.LibraryMap: 3>
    Macro: typing.ClassVar[BufferKind]  # value = <BufferKind.Macro: 5>
    MacroArg: typing.ClassVar[BufferKind]  # value = <BufferKind.MacroArg: 6>
    Unknown: typing.ClassVar[BufferKind]  # value = <BufferKind.Unknown: 0>
class BumpAllocator:
    def __init__(self) -> None:
        ...
class ColumnUnit(enum.Enum):
    Byte: typing.ClassVar[ColumnUnit]  # value = <ColumnUnit.Byte: 0>
    Display: typing.ClassVar[ColumnUnit]  # value = <ColumnUnit.Display: 1>
class ConstantRange:
    __hash__: typing.ClassVar[None] = None
    def __eq__(self, arg0: ConstantRange) -> bool:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, left: typing.SupportsInt | typing.SupportsIndex, right: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __ne__(self, arg0: ConstantRange) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def containsPoint(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> bool:
        ...
    def getIndexedRange(self: typing.SupportsInt | typing.SupportsIndex, arg0: typing.SupportsInt | typing.SupportsIndex, arg1: bool, arg2: bool) -> pyslang.ConstantRange | None:
        ...
    def overlaps(self, arg0: ConstantRange) -> bool:
        ...
    def reverse(self) -> ConstantRange:
        ...
    def subrange(self, arg0: ConstantRange) -> ConstantRange:
        ...
    def translateIndex(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> int:
        ...
    @property
    def isDescending(self) -> bool:
        ...
    @property
    def left(self) -> int:
        ...
    @left.setter
    def left(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def lower(self) -> int:
        ...
    @property
    def right(self) -> int:
        ...
    @right.setter
    def right(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def upper(self) -> int:
        ...
    @property
    def width(self) -> int:
        ...
class ConstantValue:
    def __bool__(self) -> bool:
        ...
    def __eq__(self, arg0: ConstantValue) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, integer: SVInt) -> None:
        ...
    @typing.overload
    def __init__(self, str: str) -> None:
        ...
    @typing.overload
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @typing.overload
    def __init__(self, value: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    def __ne__(self, arg0: ConstantValue) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def bitstreamWidth(self) -> int:
        ...
    def convertToByteArray(self, size: typing.SupportsInt | typing.SupportsIndex, isSigned: bool) -> ConstantValue:
        ...
    def convertToByteQueue(self, isSigned: bool) -> ConstantValue:
        ...
    @typing.overload
    def convertToInt(self) -> ConstantValue:
        ...
    @typing.overload
    def convertToInt(self, width: typing.SupportsInt | typing.SupportsIndex, isSigned: bool, isFourState: bool) -> ConstantValue:
        ...
    def convertToReal(self) -> ConstantValue:
        ...
    def convertToShortReal(self) -> ConstantValue:
        ...
    def convertToStr(self) -> ConstantValue:
        ...
    def empty(self) -> bool:
        ...
    def getSlice(self, upper: typing.SupportsInt | typing.SupportsIndex, lower: typing.SupportsInt | typing.SupportsIndex, defaultValue: ConstantValue) -> ConstantValue:
        ...
    def hasUnknown(self) -> bool:
        ...
    def isContainer(self) -> bool:
        ...
    def isFalse(self) -> bool:
        ...
    def isTrue(self) -> bool:
        ...
    def size(self) -> int:
        ...
    @property
    def value(self) -> typing.Any:
        ...
class DiagCode:
    def __bool__(self) -> bool:
        ...
    def __eq__(self, arg0: DiagCode) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, subsystem: DiagSubsystem, code: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __ne__(self, arg0: DiagCode) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def getCode(self) -> int:
        ...
    def getSubsystem(self) -> DiagSubsystem:
        ...
class DiagGroup:
    def __init__(self, name: str, diags: collections.abc.Sequence[DiagCode]) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def getDiags(self) -> span[DiagCode]:
        ...
    def getName(self) -> str:
        ...
class DiagSubsystem(enum.Enum):
    Analysis: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Analysis: 14>
    Compilation: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Compilation: 13>
    ConstEval: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.ConstEval: 12>
    Declarations: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Declarations: 6>
    Driver: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Driver: 16>
    Expressions: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Expressions: 7>
    General: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.General: 1>
    Invalid: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Invalid: 0>
    Lexer: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Lexer: 2>
    Lookup: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Lookup: 10>
    Meta: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Meta: 15>
    Netlist: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Netlist: 18>
    Numeric: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Numeric: 3>
    Parser: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Parser: 5>
    Preprocessor: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Preprocessor: 4>
    Statements: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Statements: 8>
    SysFuncs: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.SysFuncs: 11>
    Tidy: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Tidy: 17>
    Types: typing.ClassVar[DiagSubsystem]  # value = <DiagSubsystem.Types: 9>
class Diagnostic:
    __hash__: typing.ClassVar[None] = None
    def __eq__(self, arg0: Diagnostic) -> bool:
        ...
    def __init__(self, code: DiagCode, location: ...) -> None:
        ...
    def __ne__(self, arg0: Diagnostic) -> bool:
        ...
    def isError(self) -> bool:
        ...
    @property
    def args(self) -> list[typing.Any]:
        ...
    @property
    def code(self) -> DiagCode:
        ...
    @property
    def location(self) -> ...:
        ...
    @property
    def ranges(self) -> list[...]:
        ...
    @property
    def symbol(self) -> ...:
        ...
class DiagnosticClient:
    def report(self, diagnostic: ReportedDiagnostic) -> None:
        ...
    def setEngine(self, engine: DiagnosticEngine) -> None:
        ...
    def showAbsPaths(self, show: bool) -> None:
        ...
class DiagnosticEngine:
    @staticmethod
    def reportAll(sourceManager: ..., diag: span[Diagnostic]) -> str:
        ...
    def __init__(self, sourceManager: ...) -> None:
        ...
    def addClient(self, client: ...) -> None:
        ...
    def clearClients(self) -> None:
        ...
    def clearCounts(self) -> None:
        ...
    @typing.overload
    def clearMappings(self) -> None:
        ...
    @typing.overload
    def clearMappings(self, severity: DiagnosticSeverity) -> None:
        ...
    def findDiagGroup(self, name: str) -> DiagGroup:
        ...
    def findFromOptionName(self, optionName: str) -> span[DiagCode]:
        ...
    def formatArg(self, arg0: typing.Any) -> str:
        ...
    def formatMessage(self, diag: Diagnostic) -> str:
        ...
    def getMessage(self, code: DiagCode) -> str:
        ...
    def getOptionName(self, code: DiagCode) -> str:
        ...
    def getSeverity(self, code: DiagCode, location: ...) -> DiagnosticSeverity:
        ...
    @typing.overload
    def issue(self, diagnostic: Diagnostic) -> None:
        ...
    @typing.overload
    def issue(self, diagnostics: Diagnostics) -> None:
        ...
    def setBaselineSeverity(self, code: DiagCode, severity: DiagnosticSeverity) -> None:
        ...
    def setErrorLimit(self, limit: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def setErrorsAsFatal(self, set: bool) -> None:
        ...
    def setFatalsAsErrors(self, set: bool) -> None:
        ...
    def setIgnoreAllNotes(self, set: bool) -> None:
        ...
    def setIgnoreAllWarnings(self, set: bool) -> None:
        ...
    @typing.overload
    def setMappingsFromPragmas(self) -> Diagnostics:
        ...
    @typing.overload
    def setMappingsFromPragmas(self, buffer: ...) -> Diagnostics:
        ...
    def setMessage(self, code: DiagCode, message: str) -> None:
        ...
    def setSeverity(self, code: DiagCode, severity: DiagnosticSeverity) -> None:
        ...
    def setWarningOptions(self, options: span[str]) -> Diagnostics:
        ...
    def setWarningsAsErrors(self, set: bool) -> None:
        ...
    @property
    def numErrors(self) -> int:
        ...
    @property
    def numWarnings(self) -> int:
        ...
    @property
    def sourceManager(self) -> ...:
        ...
class DiagnosticSeverity(enum.Enum):
    Error: typing.ClassVar[DiagnosticSeverity]  # value = <DiagnosticSeverity.Error: 3>
    Fatal: typing.ClassVar[DiagnosticSeverity]  # value = <DiagnosticSeverity.Fatal: 4>
    Ignored: typing.ClassVar[DiagnosticSeverity]  # value = <DiagnosticSeverity.Ignored: 0>
    Note: typing.ClassVar[DiagnosticSeverity]  # value = <DiagnosticSeverity.Note: 1>
    Warning: typing.ClassVar[DiagnosticSeverity]  # value = <DiagnosticSeverity.Warning: 2>
class Diagnostics:
    def __getitem__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> Diagnostic:
        ...
    def __init__(self) -> None:
        ...
    def __iter__(self) -> collections.abc.Iterator[Diagnostic]:
        ...
    def __len__(self) -> int:
        ...
    @typing.overload
    def add(self, code: DiagCode, location: ...) -> Diagnostic:
        ...
    @typing.overload
    def add(self, code: DiagCode, range: ...) -> Diagnostic:
        ...
    @typing.overload
    def add(self, source: ..., code: DiagCode, location: ...) -> Diagnostic:
        ...
    @typing.overload
    def add(self, source: ..., code: DiagCode, range: ...) -> Diagnostic:
        ...
    def sort(self, sourceManager: ...) -> None:
        ...
class Diags:
    AlwaysFFEventControl: typing.ClassVar[DiagCode]  # value = DiagCode(AlwaysFFEventControl)
    AlwaysInChecker: typing.ClassVar[DiagCode]  # value = DiagCode(AlwaysInChecker)
    AlwaysWithoutTimingControl: typing.ClassVar[DiagCode]  # value = DiagCode(AlwaysWithoutTimingControl)
    AmbiguousWildcardImport: typing.ClassVar[DiagCode]  # value = DiagCode(AmbiguousWildcardImport)
    AnsiIfacePortDefault: typing.ClassVar[DiagCode]  # value = DiagCode(AnsiIfacePortDefault)
    ArgCannotBeEmpty: typing.ClassVar[DiagCode]  # value = DiagCode(ArgCannotBeEmpty)
    ArgDoesNotExist: typing.ClassVar[DiagCode]  # value = DiagCode(ArgDoesNotExist)
    ArithInShift: typing.ClassVar[DiagCode]  # value = DiagCode(ArithInShift)
    ArithOpMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(ArithOpMismatch)
    ArrayDimTooLarge: typing.ClassVar[DiagCode]  # value = DiagCode(ArrayDimTooLarge)
    ArrayLocatorWithClause: typing.ClassVar[DiagCode]  # value = DiagCode(ArrayLocatorWithClause)
    ArrayMethodComparable: typing.ClassVar[DiagCode]  # value = DiagCode(ArrayMethodComparable)
    ArrayMethodIntegral: typing.ClassVar[DiagCode]  # value = DiagCode(ArrayMethodIntegral)
    AssertionArgNeedsRegExpr: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionArgNeedsRegExpr)
    AssertionArgTypeMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionArgTypeMismatch)
    AssertionArgTypeSequence: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionArgTypeSequence)
    AssertionDelayFormalType: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionDelayFormalType)
    AssertionExprType: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionExprType)
    AssertionFormalMultiAssign: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionFormalMultiAssign)
    AssertionFormalUnassigned: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionFormalUnassigned)
    AssertionFuncArg: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionFuncArg)
    AssertionLocalUnassigned: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionLocalUnassigned)
    AssertionNoClock: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionNoClock)
    AssertionOutputLocalVar: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionOutputLocalVar)
    AssertionPortDirNoLocal: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionPortDirNoLocal)
    AssertionPortOutputDefault: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionPortOutputDefault)
    AssertionPortPropOutput: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionPortPropOutput)
    AssertionPortRef: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionPortRef)
    AssertionPortTypedLValue: typing.ClassVar[DiagCode]  # value = DiagCode(AssertionPortTypedLValue)
    AssignToCHandle: typing.ClassVar[DiagCode]  # value = DiagCode(AssignToCHandle)
    AssignToNet: typing.ClassVar[DiagCode]  # value = DiagCode(AssignToNet)
    AssignedToLocalBodyParam: typing.ClassVar[DiagCode]  # value = DiagCode(AssignedToLocalBodyParam)
    AssignedToLocalPortParam: typing.ClassVar[DiagCode]  # value = DiagCode(AssignedToLocalPortParam)
    AssignmentNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentNotAllowed)
    AssignmentPatternAssociativeType: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentPatternAssociativeType)
    AssignmentPatternDynamicType: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentPatternDynamicType)
    AssignmentPatternKeyDupDefault: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentPatternKeyDupDefault)
    AssignmentPatternKeyDupName: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentPatternKeyDupName)
    AssignmentPatternKeyDupValue: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentPatternKeyDupValue)
    AssignmentPatternKeyExpr: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentPatternKeyExpr)
    AssignmentPatternLValueDynamic: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentPatternLValueDynamic)
    AssignmentPatternMissingElements: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentPatternMissingElements)
    AssignmentPatternNoContext: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentPatternNoContext)
    AssignmentPatternNoMember: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentPatternNoMember)
    AssignmentRequiresParens: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentRequiresParens)
    AssignmentToConstVar: typing.ClassVar[DiagCode]  # value = DiagCode(AssignmentToConstVar)
    AssociativeWildcardNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(AssociativeWildcardNotAllowed)
    AttributesNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(AttributesNotAllowed)
    AutoFromNonBlockingTiming: typing.ClassVar[DiagCode]  # value = DiagCode(AutoFromNonBlockingTiming)
    AutoFromNonProcedural: typing.ClassVar[DiagCode]  # value = DiagCode(AutoFromNonProcedural)
    AutoFromStaticInit: typing.ClassVar[DiagCode]  # value = DiagCode(AutoFromStaticInit)
    AutoVarToRefStatic: typing.ClassVar[DiagCode]  # value = DiagCode(AutoVarToRefStatic)
    AutoVarTraced: typing.ClassVar[DiagCode]  # value = DiagCode(AutoVarTraced)
    AutoVariableHierarchical: typing.ClassVar[DiagCode]  # value = DiagCode(AutoVariableHierarchical)
    AutomaticNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(AutomaticNotAllowed)
    BadAssignment: typing.ClassVar[DiagCode]  # value = DiagCode(BadAssignment)
    BadAssignmentPatternType: typing.ClassVar[DiagCode]  # value = DiagCode(BadAssignmentPatternType)
    BadBinaryDigit: typing.ClassVar[DiagCode]  # value = DiagCode(BadBinaryDigit)
    BadBinaryExpression: typing.ClassVar[DiagCode]  # value = DiagCode(BadBinaryExpression)
    BadCastType: typing.ClassVar[DiagCode]  # value = DiagCode(BadCastType)
    BadConcatExpression: typing.ClassVar[DiagCode]  # value = DiagCode(BadConcatExpression)
    BadConditionalExpression: typing.ClassVar[DiagCode]  # value = DiagCode(BadConditionalExpression)
    BadConversion: typing.ClassVar[DiagCode]  # value = DiagCode(BadConversion)
    BadDecimalDigit: typing.ClassVar[DiagCode]  # value = DiagCode(BadDecimalDigit)
    BadDisableSoft: typing.ClassVar[DiagCode]  # value = DiagCode(BadDisableSoft)
    BadFinishNum: typing.ClassVar[DiagCode]  # value = DiagCode(BadFinishNum)
    BadForceNetType: typing.ClassVar[DiagCode]  # value = DiagCode(BadForceNetType)
    BadHexDigit: typing.ClassVar[DiagCode]  # value = DiagCode(BadHexDigit)
    BadIndexExpression: typing.ClassVar[DiagCode]  # value = DiagCode(BadIndexExpression)
    BadInstanceArrayRange: typing.ClassVar[DiagCode]  # value = DiagCode(BadInstanceArrayRange)
    BadIntegerCast: typing.ClassVar[DiagCode]  # value = DiagCode(BadIntegerCast)
    BadOctalDigit: typing.ClassVar[DiagCode]  # value = DiagCode(BadOctalDigit)
    BadProceduralAssign: typing.ClassVar[DiagCode]  # value = DiagCode(BadProceduralAssign)
    BadProceduralForce: typing.ClassVar[DiagCode]  # value = DiagCode(BadProceduralForce)
    BadReplicationExpression: typing.ClassVar[DiagCode]  # value = DiagCode(BadReplicationExpression)
    BadSetMembershipType: typing.ClassVar[DiagCode]  # value = DiagCode(BadSetMembershipType)
    BadSliceType: typing.ClassVar[DiagCode]  # value = DiagCode(BadSliceType)
    BadSolveBefore: typing.ClassVar[DiagCode]  # value = DiagCode(BadSolveBefore)
    BadStreamCast: typing.ClassVar[DiagCode]  # value = DiagCode(BadStreamCast)
    BadStreamContext: typing.ClassVar[DiagCode]  # value = DiagCode(BadStreamContext)
    BadStreamExprType: typing.ClassVar[DiagCode]  # value = DiagCode(BadStreamExprType)
    BadStreamSize: typing.ClassVar[DiagCode]  # value = DiagCode(BadStreamSize)
    BadStreamSlice: typing.ClassVar[DiagCode]  # value = DiagCode(BadStreamSlice)
    BadStreamSourceType: typing.ClassVar[DiagCode]  # value = DiagCode(BadStreamSourceType)
    BadStreamTargetType: typing.ClassVar[DiagCode]  # value = DiagCode(BadStreamTargetType)
    BadStreamWithOrder: typing.ClassVar[DiagCode]  # value = DiagCode(BadStreamWithOrder)
    BadStreamWithType: typing.ClassVar[DiagCode]  # value = DiagCode(BadStreamWithType)
    BadSystemSubroutineArg: typing.ClassVar[DiagCode]  # value = DiagCode(BadSystemSubroutineArg)
    BadTypeParamExpr: typing.ClassVar[DiagCode]  # value = DiagCode(BadTypeParamExpr)
    BadUnaryExpression: typing.ClassVar[DiagCode]  # value = DiagCode(BadUnaryExpression)
    BadUniquenessType: typing.ClassVar[DiagCode]  # value = DiagCode(BadUniquenessType)
    BadValueRange: typing.ClassVar[DiagCode]  # value = DiagCode(BadValueRange)
    BareAssociativePattern: typing.ClassVar[DiagCode]  # value = DiagCode(BareAssociativePattern)
    BaseConstructorDuplicate: typing.ClassVar[DiagCode]  # value = DiagCode(BaseConstructorDuplicate)
    BaseConstructorNotCalled: typing.ClassVar[DiagCode]  # value = DiagCode(BaseConstructorNotCalled)
    BiDiSwitchNetTypes: typing.ClassVar[DiagCode]  # value = DiagCode(BiDiSwitchNetTypes)
    BindDirectiveInvalidName: typing.ClassVar[DiagCode]  # value = DiagCode(BindDirectiveInvalidName)
    BindTargetPrimitive: typing.ClassVar[DiagCode]  # value = DiagCode(BindTargetPrimitive)
    BindTypeParamMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(BindTypeParamMismatch)
    BindTypeParamNotFound: typing.ClassVar[DiagCode]  # value = DiagCode(BindTypeParamNotFound)
    BindUnderBind: typing.ClassVar[DiagCode]  # value = DiagCode(BindUnderBind)
    BitsOfIntegerConstant: typing.ClassVar[DiagCode]  # value = DiagCode(BitsOfIntegerConstant)
    BitwiseOpMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(BitwiseOpMismatch)
    BitwiseOpParentheses: typing.ClassVar[DiagCode]  # value = DiagCode(BitwiseOpParentheses)
    BitwiseRelPrecedence: typing.ClassVar[DiagCode]  # value = DiagCode(BitwiseRelPrecedence)
    BlockingAssignToFreeVar: typing.ClassVar[DiagCode]  # value = DiagCode(BlockingAssignToFreeVar)
    BlockingDelayInTask: typing.ClassVar[DiagCode]  # value = DiagCode(BlockingDelayInTask)
    BlockingInAlwaysFF: typing.ClassVar[DiagCode]  # value = DiagCode(BlockingInAlwaysFF)
    BodyForPure: typing.ClassVar[DiagCode]  # value = DiagCode(BodyForPure)
    BodyForPureConstraint: typing.ClassVar[DiagCode]  # value = DiagCode(BodyForPureConstraint)
    BodyParamNoInitializer: typing.ClassVar[DiagCode]  # value = DiagCode(BodyParamNoInitializer)
    CHandleInAssertion: typing.ClassVar[DiagCode]  # value = DiagCode(CHandleInAssertion)
    CannotCompareTwoInstances: typing.ClassVar[DiagCode]  # value = DiagCode(CannotCompareTwoInstances)
    CannotDeclareType: typing.ClassVar[DiagCode]  # value = DiagCode(CannotDeclareType)
    CannotIndexScalar: typing.ClassVar[DiagCode]  # value = DiagCode(CannotIndexScalar)
    CantDeclarePortSigned: typing.ClassVar[DiagCode]  # value = DiagCode(CantDeclarePortSigned)
    CantModifyConst: typing.ClassVar[DiagCode]  # value = DiagCode(CantModifyConst)
    CaseComplex: typing.ClassVar[DiagCode]  # value = DiagCode(CaseComplex)
    CaseDefault: typing.ClassVar[DiagCode]  # value = DiagCode(CaseDefault)
    CaseDup: typing.ClassVar[DiagCode]  # value = DiagCode(CaseDup)
    CaseEnum: typing.ClassVar[DiagCode]  # value = DiagCode(CaseEnum)
    CaseEnumExplicit: typing.ClassVar[DiagCode]  # value = DiagCode(CaseEnumExplicit)
    CaseGenerateDup: typing.ClassVar[DiagCode]  # value = DiagCode(CaseGenerateDup)
    CaseGenerateEmpty: typing.ClassVar[DiagCode]  # value = DiagCode(CaseGenerateEmpty)
    CaseGenerateNoBlock: typing.ClassVar[DiagCode]  # value = DiagCode(CaseGenerateNoBlock)
    CaseIncomplete: typing.ClassVar[DiagCode]  # value = DiagCode(CaseIncomplete)
    CaseInsideKeyword: typing.ClassVar[DiagCode]  # value = DiagCode(CaseInsideKeyword)
    CaseNone: typing.ClassVar[DiagCode]  # value = DiagCode(CaseNone)
    CaseNotWildcard: typing.ClassVar[DiagCode]  # value = DiagCode(CaseNotWildcard)
    CaseOutsideRange: typing.ClassVar[DiagCode]  # value = DiagCode(CaseOutsideRange)
    CaseOverlap: typing.ClassVar[DiagCode]  # value = DiagCode(CaseOverlap)
    CaseRedundantDefault: typing.ClassVar[DiagCode]  # value = DiagCode(CaseRedundantDefault)
    CaseStatementEmpty: typing.ClassVar[DiagCode]  # value = DiagCode(CaseStatementEmpty)
    CaseTypeMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(CaseTypeMismatch)
    CaseUnreachable: typing.ClassVar[DiagCode]  # value = DiagCode(CaseUnreachable)
    CaseWildcard2State: typing.ClassVar[DiagCode]  # value = DiagCode(CaseWildcard2State)
    CaseZWithX: typing.ClassVar[DiagCode]  # value = DiagCode(CaseZWithX)
    ChainedMethodParens: typing.ClassVar[DiagCode]  # value = DiagCode(ChainedMethodParens)
    ChargeWithTriReg: typing.ClassVar[DiagCode]  # value = DiagCode(ChargeWithTriReg)
    CheckerArgCannotBeEmpty: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerArgCannotBeEmpty)
    CheckerAutoVarRef: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerAutoVarRef)
    CheckerBlockingAssign: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerBlockingAssign)
    CheckerClassBadInstantiation: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerClassBadInstantiation)
    CheckerConstCast: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerConstCast)
    CheckerCovergroupProc: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerCovergroupProc)
    CheckerForkJoinRef: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerForkJoinRef)
    CheckerFuncArg: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerFuncArg)
    CheckerFuncBadInstantiation: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerFuncBadInstantiation)
    CheckerHierarchical: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerHierarchical)
    CheckerInCheckerProc: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerInCheckerProc)
    CheckerInForkJoin: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerInForkJoin)
    CheckerNotInProc: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerNotInProc)
    CheckerOutputBadType: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerOutputBadType)
    CheckerParameterAssign: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerParameterAssign)
    CheckerPortDirectionType: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerPortDirectionType)
    CheckerPortInout: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerPortInout)
    CheckerTimingControl: typing.ClassVar[DiagCode]  # value = DiagCode(CheckerTimingControl)
    ClassInheritanceCycle: typing.ClassVar[DiagCode]  # value = DiagCode(ClassInheritanceCycle)
    ClassMemberInAssertion: typing.ClassVar[DiagCode]  # value = DiagCode(ClassMemberInAssertion)
    ClassPrivateMembersBitstream: typing.ClassVar[DiagCode]  # value = DiagCode(ClassPrivateMembersBitstream)
    ClassSpecifierConflict: typing.ClassVar[DiagCode]  # value = DiagCode(ClassSpecifierConflict)
    ClockVarAssignConcat: typing.ClassVar[DiagCode]  # value = DiagCode(ClockVarAssignConcat)
    ClockVarBadTiming: typing.ClassVar[DiagCode]  # value = DiagCode(ClockVarBadTiming)
    ClockVarOutputRead: typing.ClassVar[DiagCode]  # value = DiagCode(ClockVarOutputRead)
    ClockVarSyncDrive: typing.ClassVar[DiagCode]  # value = DiagCode(ClockVarSyncDrive)
    ClockVarTargetAssign: typing.ClassVar[DiagCode]  # value = DiagCode(ClockVarTargetAssign)
    ClockingBlockEventEdge: typing.ClassVar[DiagCode]  # value = DiagCode(ClockingBlockEventEdge)
    ClockingNameEmpty: typing.ClassVar[DiagCode]  # value = DiagCode(ClockingNameEmpty)
    ColonPlusRange: typing.ClassVar[DiagCode]  # value = DiagCode(ColonPlusRange)
    CommandLineError: typing.ClassVar[DiagCode]  # value = DiagCode(CommandLineError)
    ComparisonMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(ComparisonMismatch)
    CompilationUnitFromPackage: typing.ClassVar[DiagCode]  # value = DiagCode(CompilationUnitFromPackage)
    ConcatWithStringInt: typing.ClassVar[DiagCode]  # value = DiagCode(ConcatWithStringInt)
    ConcurrentAssertActionBlock: typing.ClassVar[DiagCode]  # value = DiagCode(ConcurrentAssertActionBlock)
    ConcurrentAssertNotInProc: typing.ClassVar[DiagCode]  # value = DiagCode(ConcurrentAssertNotInProc)
    ConditionalPrecedence: typing.ClassVar[DiagCode]  # value = DiagCode(ConditionalPrecedence)
    ConfigDupTop: typing.ClassVar[DiagCode]  # value = DiagCode(ConfigDupTop)
    ConfigInstanceUnderOtherConfig: typing.ClassVar[DiagCode]  # value = DiagCode(ConfigInstanceUnderOtherConfig)
    ConfigInstanceWrongTop: typing.ClassVar[DiagCode]  # value = DiagCode(ConfigInstanceWrongTop)
    ConfigMissingName: typing.ClassVar[DiagCode]  # value = DiagCode(ConfigMissingName)
    ConfigOverrideTop: typing.ClassVar[DiagCode]  # value = DiagCode(ConfigOverrideTop)
    ConfigParamLiteral: typing.ClassVar[DiagCode]  # value = DiagCode(ConfigParamLiteral)
    ConfigParamsForPrimitive: typing.ClassVar[DiagCode]  # value = DiagCode(ConfigParamsForPrimitive)
    ConfigParamsIgnored: typing.ClassVar[DiagCode]  # value = DiagCode(ConfigParamsIgnored)
    ConfigParamsOrdered: typing.ClassVar[DiagCode]  # value = DiagCode(ConfigParamsOrdered)
    ConfigSpecificCellLiblist: typing.ClassVar[DiagCode]  # value = DiagCode(ConfigSpecificCellLiblist)
    ConsecutiveComparison: typing.ClassVar[DiagCode]  # value = DiagCode(ConsecutiveComparison)
    ConstEvalAssertionFailed: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalAssertionFailed)
    ConstEvalAssociativeElementNotFound: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalAssociativeElementNotFound)
    ConstEvalAssociativeIndexInvalid: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalAssociativeIndexInvalid)
    ConstEvalBitstreamCastSize: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalBitstreamCastSize)
    ConstEvalCaseItemsNotUnique: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalCaseItemsNotUnique)
    ConstEvalCheckers: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalCheckers)
    ConstEvalClassType: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalClassType)
    ConstEvalCovergroupType: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalCovergroupType)
    ConstEvalDPINotConstant: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalDPINotConstant)
    ConstEvalDisableTarget: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalDisableTarget)
    ConstEvalDynamicArrayIndex: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalDynamicArrayIndex)
    ConstEvalDynamicArrayRange: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalDynamicArrayRange)
    ConstEvalDynamicToFixedSize: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalDynamicToFixedSize)
    ConstEvalEmptyQueue: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalEmptyQueue)
    ConstEvalExceededMaxCallDepth: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalExceededMaxCallDepth)
    ConstEvalExceededMaxSize: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalExceededMaxSize)
    ConstEvalExceededMaxSteps: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalExceededMaxSteps)
    ConstEvalFunctionArgDirection: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalFunctionArgDirection)
    ConstEvalFunctionIdentifiersMustBeLocal: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalFunctionIdentifiersMustBeLocal)
    ConstEvalFunctionInsideGenerate: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalFunctionInsideGenerate)
    ConstEvalHierarchicalName: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalHierarchicalName)
    ConstEvalIdUsedInCEBeforeDecl: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalIdUsedInCEBeforeDecl)
    ConstEvalIfItemsNotUnique: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalIfItemsNotUnique)
    ConstEvalMethodNotConstant: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalMethodNotConstant)
    ConstEvalNoCaseItemsMatched: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalNoCaseItemsMatched)
    ConstEvalNoIfItemsMatched: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalNoIfItemsMatched)
    ConstEvalNonConstVariable: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalNonConstVariable)
    ConstEvalParallelBlockNotConst: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalParallelBlockNotConst)
    ConstEvalParamCycle: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalParamCycle)
    ConstEvalProceduralAssign: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalProceduralAssign)
    ConstEvalQueueRange: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalQueueRange)
    ConstEvalRandValue: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalRandValue)
    ConstEvalReplicationCountInvalid: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalReplicationCountInvalid)
    ConstEvalStaticSkipped: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalStaticSkipped)
    ConstEvalSubroutineNotConstant: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalSubroutineNotConstant)
    ConstEvalTaggedUnion: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalTaggedUnion)
    ConstEvalTaskNotConstant: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalTaskNotConstant)
    ConstEvalTimedStmtNotConst: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalTimedStmtNotConst)
    ConstEvalVifType: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalVifType)
    ConstEvalVoidNotConstant: typing.ClassVar[DiagCode]  # value = DiagCode(ConstEvalVoidNotConstant)
    ConstFunctionPortRequiresRef: typing.ClassVar[DiagCode]  # value = DiagCode(ConstFunctionPortRequiresRef)
    ConstPortNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(ConstPortNotAllowed)
    ConstSysTaskIgnored: typing.ClassVar[DiagCode]  # value = DiagCode(ConstSysTaskIgnored)
    ConstVarNoInitializer: typing.ClassVar[DiagCode]  # value = DiagCode(ConstVarNoInitializer)
    ConstVarToRef: typing.ClassVar[DiagCode]  # value = DiagCode(ConstVarToRef)
    ConstantConversion: typing.ClassVar[DiagCode]  # value = DiagCode(ConstantConversion)
    ConstraintFuncArgCycle: typing.ClassVar[DiagCode]  # value = DiagCode(ConstraintFuncArgCycle)
    ConstraintNotInClass: typing.ClassVar[DiagCode]  # value = DiagCode(ConstraintNotInClass)
    ConstraintQualOutOfBlock: typing.ClassVar[DiagCode]  # value = DiagCode(ConstraintQualOutOfBlock)
    ConstraintSolveCycle: typing.ClassVar[DiagCode]  # value = DiagCode(ConstraintSolveCycle)
    ConstructorOutsideClass: typing.ClassVar[DiagCode]  # value = DiagCode(ConstructorOutsideClass)
    ConstructorReturnType: typing.ClassVar[DiagCode]  # value = DiagCode(ConstructorReturnType)
    CopyClassTarget: typing.ClassVar[DiagCode]  # value = DiagCode(CopyClassTarget)
    CouldNotOpenIncludeFile: typing.ClassVar[DiagCode]  # value = DiagCode(CouldNotOpenIncludeFile)
    CouldNotResolveHierarchicalPath: typing.ClassVar[DiagCode]  # value = DiagCode(CouldNotResolveHierarchicalPath)
    CoverCrossItems: typing.ClassVar[DiagCode]  # value = DiagCode(CoverCrossItems)
    CoverCrossSelectNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(CoverCrossSelectNotAllowed)
    CoverOptionImmutable: typing.ClassVar[DiagCode]  # value = DiagCode(CoverOptionImmutable)
    CoverStmtNoFail: typing.ClassVar[DiagCode]  # value = DiagCode(CoverStmtNoFail)
    CoverageBinDefSeqSize: typing.ClassVar[DiagCode]  # value = DiagCode(CoverageBinDefSeqSize)
    CoverageBinDefaultIgnore: typing.ClassVar[DiagCode]  # value = DiagCode(CoverageBinDefaultIgnore)
    CoverageBinDefaultWildcard: typing.ClassVar[DiagCode]  # value = DiagCode(CoverageBinDefaultWildcard)
    CoverageBinTargetName: typing.ClassVar[DiagCode]  # value = DiagCode(CoverageBinTargetName)
    CoverageBinTransSize: typing.ClassVar[DiagCode]  # value = DiagCode(CoverageBinTransSize)
    CoverageOptionDup: typing.ClassVar[DiagCode]  # value = DiagCode(CoverageOptionDup)
    CoverageSampleFormal: typing.ClassVar[DiagCode]  # value = DiagCode(CoverageSampleFormal)
    CoverageSetType: typing.ClassVar[DiagCode]  # value = DiagCode(CoverageSetType)
    CovergroupOutArg: typing.ClassVar[DiagCode]  # value = DiagCode(CovergroupOutArg)
    CrossIdentInBinsof: typing.ClassVar[DiagCode]  # value = DiagCode(CrossIdentInBinsof)
    CycleDelayNonClock: typing.ClassVar[DiagCode]  # value = DiagCode(CycleDelayNonClock)
    DPIExportDifferentScope: typing.ClassVar[DiagCode]  # value = DiagCode(DPIExportDifferentScope)
    DPIExportDuplicate: typing.ClassVar[DiagCode]  # value = DiagCode(DPIExportDuplicate)
    DPIExportDuplicateCId: typing.ClassVar[DiagCode]  # value = DiagCode(DPIExportDuplicateCId)
    DPIExportImportedFunc: typing.ClassVar[DiagCode]  # value = DiagCode(DPIExportImportedFunc)
    DPIExportKindMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(DPIExportKindMismatch)
    DPIPureArg: typing.ClassVar[DiagCode]  # value = DiagCode(DPIPureArg)
    DPIPureReturn: typing.ClassVar[DiagCode]  # value = DiagCode(DPIPureReturn)
    DPIPureTask: typing.ClassVar[DiagCode]  # value = DiagCode(DPIPureTask)
    DPIRefArg: typing.ClassVar[DiagCode]  # value = DiagCode(DPIRefArg)
    DPISignatureMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(DPISignatureMismatch)
    DPISpecDisallowed: typing.ClassVar[DiagCode]  # value = DiagCode(DPISpecDisallowed)
    DanglingElse: typing.ClassVar[DiagCode]  # value = DiagCode(DanglingElse)
    DecimalDigitMultipleUnknown: typing.ClassVar[DiagCode]  # value = DiagCode(DecimalDigitMultipleUnknown)
    DeclModifierConflict: typing.ClassVar[DiagCode]  # value = DiagCode(DeclModifierConflict)
    DeclModifierOrdering: typing.ClassVar[DiagCode]  # value = DiagCode(DeclModifierOrdering)
    DeclarationsAtStart: typing.ClassVar[DiagCode]  # value = DiagCode(DeclarationsAtStart)
    DefParamCycle: typing.ClassVar[DiagCode]  # value = DiagCode(DefParamCycle)
    DefParamLocal: typing.ClassVar[DiagCode]  # value = DiagCode(DefParamLocal)
    DefParamTarget: typing.ClassVar[DiagCode]  # value = DiagCode(DefParamTarget)
    DefParamTargetChange: typing.ClassVar[DiagCode]  # value = DiagCode(DefParamTargetChange)
    DefaultArgNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(DefaultArgNotAllowed)
    DefaultSuperArgLocalReference: typing.ClassVar[DiagCode]  # value = DiagCode(DefaultSuperArgLocalReference)
    DeferredAssertAutoRefArg: typing.ClassVar[DiagCode]  # value = DiagCode(DeferredAssertAutoRefArg)
    DeferredAssertNonVoid: typing.ClassVar[DiagCode]  # value = DiagCode(DeferredAssertNonVoid)
    DeferredAssertOutArg: typing.ClassVar[DiagCode]  # value = DiagCode(DeferredAssertOutArg)
    DeferredDelayMustBeZero: typing.ClassVar[DiagCode]  # value = DiagCode(DeferredDelayMustBeZero)
    DefinitionUsedAsType: typing.ClassVar[DiagCode]  # value = DiagCode(DefinitionUsedAsType)
    DefinitionUsedAsValue: typing.ClassVar[DiagCode]  # value = DiagCode(DefinitionUsedAsValue)
    DefparamBadHierarchy: typing.ClassVar[DiagCode]  # value = DiagCode(DefparamBadHierarchy)
    Delay3NotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(Delay3NotAllowed)
    Delay3OnVar: typing.ClassVar[DiagCode]  # value = DiagCode(Delay3OnVar)
    Delay3UdpNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(Delay3UdpNotAllowed)
    DelayNotNumeric: typing.ClassVar[DiagCode]  # value = DiagCode(DelayNotNumeric)
    DelaysNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(DelaysNotAllowed)
    DerivedCovergroupNoBase: typing.ClassVar[DiagCode]  # value = DiagCode(DerivedCovergroupNoBase)
    DerivedCovergroupNotInClass: typing.ClassVar[DiagCode]  # value = DiagCode(DerivedCovergroupNotInClass)
    DifferentClockInClockingBlock: typing.ClassVar[DiagCode]  # value = DiagCode(DifferentClockInClockingBlock)
    DigitsLeadingUnderscore: typing.ClassVar[DiagCode]  # value = DiagCode(DigitsLeadingUnderscore)
    DimensionIndexInvalid: typing.ClassVar[DiagCode]  # value = DiagCode(DimensionIndexInvalid)
    DimensionRequiresConstRange: typing.ClassVar[DiagCode]  # value = DiagCode(DimensionRequiresConstRange)
    DirectionOnInterfacePort: typing.ClassVar[DiagCode]  # value = DiagCode(DirectionOnInterfacePort)
    DirectionWithInterfacePort: typing.ClassVar[DiagCode]  # value = DiagCode(DirectionWithInterfacePort)
    DirectiveInsideDesignElement: typing.ClassVar[DiagCode]  # value = DiagCode(DirectiveInsideDesignElement)
    DisableIffLocalVar: typing.ClassVar[DiagCode]  # value = DiagCode(DisableIffLocalVar)
    DisableIffMatched: typing.ClassVar[DiagCode]  # value = DiagCode(DisableIffMatched)
    DisallowedPortDefault: typing.ClassVar[DiagCode]  # value = DiagCode(DisallowedPortDefault)
    DistRealRangeWeight: typing.ClassVar[DiagCode]  # value = DiagCode(DistRealRangeWeight)
    DivisionByZero: typing.ClassVar[DiagCode]  # value = DiagCode(DivisionByZero)
    DotIntoInstArray: typing.ClassVar[DiagCode]  # value = DiagCode(DotIntoInstArray)
    DotOnType: typing.ClassVar[DiagCode]  # value = DiagCode(DotOnType)
    DriveStrengthHighZ: typing.ClassVar[DiagCode]  # value = DiagCode(DriveStrengthHighZ)
    DriveStrengthInvalid: typing.ClassVar[DiagCode]  # value = DiagCode(DriveStrengthInvalid)
    DriveStrengthNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(DriveStrengthNotAllowed)
    DupConfigRule: typing.ClassVar[DiagCode]  # value = DiagCode(DupConfigRule)
    DupInterfaceExternMethod: typing.ClassVar[DiagCode]  # value = DiagCode(DupInterfaceExternMethod)
    DupTimingPath: typing.ClassVar[DiagCode]  # value = DiagCode(DupTimingPath)
    DuplicateArgAssignment: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateArgAssignment)
    DuplicateAttribute: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateAttribute)
    DuplicateBind: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateBind)
    DuplicateClassSpecifier: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateClassSpecifier)
    DuplicateDeclModifier: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateDeclModifier)
    DuplicateDefinition: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateDefinition)
    DuplicateDefparam: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateDefparam)
    DuplicateImport: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateImport)
    DuplicateParamAssignment: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateParamAssignment)
    DuplicatePortConnection: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicatePortConnection)
    DuplicateQualifier: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateQualifier)
    DuplicateWildcardPortConnection: typing.ClassVar[DiagCode]  # value = DiagCode(DuplicateWildcardPortConnection)
    DynamicCastConst: typing.ClassVar[DiagCode]  # value = DiagCode(DynamicCastConst)
    DynamicDimensionIndex: typing.ClassVar[DiagCode]  # value = DiagCode(DynamicDimensionIndex)
    DynamicFromChecker: typing.ClassVar[DiagCode]  # value = DiagCode(DynamicFromChecker)
    DynamicNotProcedural: typing.ClassVar[DiagCode]  # value = DiagCode(DynamicNotProcedural)
    EdgeDescWrongKeyword: typing.ClassVar[DiagCode]  # value = DiagCode(EdgeDescWrongKeyword)
    EmbeddedNull: typing.ClassVar[DiagCode]  # value = DiagCode(EmbeddedNull)
    EmptyArgNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyArgNotAllowed)
    EmptyAssignmentPattern: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyAssignmentPattern)
    EmptyBody: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyBody)
    EmptyConcatNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyConcatNotAllowed)
    EmptyInOutPortConn: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyInOutPortConn)
    EmptyInputPortConn: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyInputPortConn)
    EmptyInputPortConnDefault: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyInputPortConnDefault)
    EmptyMember: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyMember)
    EmptyOutputPortConn: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyOutputPortConn)
    EmptyStatement: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyStatement)
    EmptyUdpPort: typing.ClassVar[DiagCode]  # value = DiagCode(EmptyUdpPort)
    EndNameMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(EndNameMismatch)
    EndNameNotEmpty: typing.ClassVar[DiagCode]  # value = DiagCode(EndNameNotEmpty)
    EnumCircularBaseType: typing.ClassVar[DiagCode]  # value = DiagCode(EnumCircularBaseType)
    EnumIncrementUnknown: typing.ClassVar[DiagCode]  # value = DiagCode(EnumIncrementUnknown)
    EnumRangeLiteral: typing.ClassVar[DiagCode]  # value = DiagCode(EnumRangeLiteral)
    EnumRangeMultiDimensional: typing.ClassVar[DiagCode]  # value = DiagCode(EnumRangeMultiDimensional)
    EnumValueCountExceeded: typing.ClassVar[DiagCode]  # value = DiagCode(EnumValueCountExceeded)
    EnumValueDuplicate: typing.ClassVar[DiagCode]  # value = DiagCode(EnumValueDuplicate)
    EnumValueOutOfRange: typing.ClassVar[DiagCode]  # value = DiagCode(EnumValueOutOfRange)
    EnumValueOverflow: typing.ClassVar[DiagCode]  # value = DiagCode(EnumValueOverflow)
    EnumValueSizeMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(EnumValueSizeMismatch)
    EnumValueUnknownBits: typing.ClassVar[DiagCode]  # value = DiagCode(EnumValueUnknownBits)
    ErrorTask: typing.ClassVar[DiagCode]  # value = DiagCode(ErrorTask)
    EscapedWhitespace: typing.ClassVar[DiagCode]  # value = DiagCode(EscapedWhitespace)
    EventExprAssertionArg: typing.ClassVar[DiagCode]  # value = DiagCode(EventExprAssertionArg)
    EventExpressionConstant: typing.ClassVar[DiagCode]  # value = DiagCode(EventExpressionConstant)
    EventExpressionFuncArg: typing.ClassVar[DiagCode]  # value = DiagCode(EventExpressionFuncArg)
    EventTriggerCycleDelay: typing.ClassVar[DiagCode]  # value = DiagCode(EventTriggerCycleDelay)
    ExceededMaxIncludeDepth: typing.ClassVar[DiagCode]  # value = DiagCode(ExceededMaxIncludeDepth)
    ExpectedAnsiPort: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedAnsiPort)
    ExpectedArgument: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedArgument)
    ExpectedAssertionItemPort: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedAssertionItemPort)
    ExpectedAssignmentKey: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedAssignmentKey)
    ExpectedAttribute: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedAttribute)
    ExpectedCaseItem: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedCaseItem)
    ExpectedClassPropertyName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedClassPropertyName)
    ExpectedClassSpecifier: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedClassSpecifier)
    ExpectedClockingSkew: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedClockingSkew)
    ExpectedClosingQuote: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedClosingQuote)
    ExpectedConditionalPattern: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedConditionalPattern)
    ExpectedConstraintName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedConstraintName)
    ExpectedContinuousAssignment: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedContinuousAssignment)
    ExpectedDPISpecString: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedDPISpecString)
    ExpectedDeclarator: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedDeclarator)
    ExpectedDiagPragmaArg: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedDiagPragmaArg)
    ExpectedDiagPragmaLevel: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedDiagPragmaLevel)
    ExpectedDistItem: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedDistItem)
    ExpectedDriveStrength: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedDriveStrength)
    ExpectedEdgeDescriptor: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedEdgeDescriptor)
    ExpectedEnumBase: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedEnumBase)
    ExpectedExpression: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedExpression)
    ExpectedForInitializer: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedForInitializer)
    ExpectedFunctionPort: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedFunctionPort)
    ExpectedFunctionPortList: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedFunctionPortList)
    ExpectedGenvarIterVar: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedGenvarIterVar)
    ExpectedHierarchicalInstantiation: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedHierarchicalInstantiation)
    ExpectedIdentifier: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedIdentifier)
    ExpectedIfOrCase: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedIfOrCase)
    ExpectedImportExport: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedImportExport)
    ExpectedIncludeFileName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedIncludeFileName)
    ExpectedIntegerBaseAfterSigned: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedIntegerBaseAfterSigned)
    ExpectedIntegerLiteral: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedIntegerLiteral)
    ExpectedInterfaceClassName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedInterfaceClassName)
    ExpectedIterationExpression: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedIterationExpression)
    ExpectedIteratorName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedIteratorName)
    ExpectedMacroArgs: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedMacroArgs)
    ExpectedMacroCommentEnd: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedMacroCommentEnd)
    ExpectedMacroStringifyEnd: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedMacroStringifyEnd)
    ExpectedMember: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedMember)
    ExpectedModOrVarName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedModOrVarName)
    ExpectedModportPort: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedModportPort)
    ExpectedModuleInstance: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedModuleInstance)
    ExpectedModuleName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedModuleName)
    ExpectedNetDelay: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedNetDelay)
    ExpectedNetRef: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedNetRef)
    ExpectedNetStrength: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedNetStrength)
    ExpectedNetType: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedNetType)
    ExpectedNonAnsiPort: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedNonAnsiPort)
    ExpectedPackageImport: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedPackageImport)
    ExpectedParameterPort: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedParameterPort)
    ExpectedPathOp: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedPathOp)
    ExpectedPattern: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedPattern)
    ExpectedPortConnection: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedPortConnection)
    ExpectedPortList: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedPortList)
    ExpectedPragmaExpression: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedPragmaExpression)
    ExpectedPragmaName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedPragmaName)
    ExpectedProtectArg: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedProtectArg)
    ExpectedProtectKeyword: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedProtectKeyword)
    ExpectedRsRule: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedRsRule)
    ExpectedSampleKeyword: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedSampleKeyword)
    ExpectedScopeName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedScopeName)
    ExpectedScopeOrAssert: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedScopeOrAssert)
    ExpectedStatement: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedStatement)
    ExpectedStreamExpression: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedStreamExpression)
    ExpectedStringLiteral: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedStringLiteral)
    ExpectedSubroutineName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedSubroutineName)
    ExpectedTimeLiteral: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedTimeLiteral)
    ExpectedToken: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedToken)
    ExpectedUdpPort: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedUdpPort)
    ExpectedUdpSymbol: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedUdpSymbol)
    ExpectedValueRangeElement: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedValueRangeElement)
    ExpectedVariableAssignment: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedVariableAssignment)
    ExpectedVariableName: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedVariableName)
    ExpectedVectorDigits: typing.ClassVar[DiagCode]  # value = DiagCode(ExpectedVectorDigits)
    ExplicitClockInClockingBlock: typing.ClassVar[DiagCode]  # value = DiagCode(ExplicitClockInClockingBlock)
    ExprMustBeIntegral: typing.ClassVar[DiagCode]  # value = DiagCode(ExprMustBeIntegral)
    ExprNotConstraint: typing.ClassVar[DiagCode]  # value = DiagCode(ExprNotConstraint)
    ExprNotStatement: typing.ClassVar[DiagCode]  # value = DiagCode(ExprNotStatement)
    ExpressionNotAssignable: typing.ClassVar[DiagCode]  # value = DiagCode(ExpressionNotAssignable)
    ExpressionNotCallable: typing.ClassVar[DiagCode]  # value = DiagCode(ExpressionNotCallable)
    ExtendClassFromIface: typing.ClassVar[DiagCode]  # value = DiagCode(ExtendClassFromIface)
    ExtendFromFinal: typing.ClassVar[DiagCode]  # value = DiagCode(ExtendFromFinal)
    ExtendIfaceFromClass: typing.ClassVar[DiagCode]  # value = DiagCode(ExtendIfaceFromClass)
    ExternDeclMismatchImpl: typing.ClassVar[DiagCode]  # value = DiagCode(ExternDeclMismatchImpl)
    ExternDeclMismatchPrev: typing.ClassVar[DiagCode]  # value = DiagCode(ExternDeclMismatchPrev)
    ExternFuncForkJoin: typing.ClassVar[DiagCode]  # value = DiagCode(ExternFuncForkJoin)
    ExternIfaceArrayMethod: typing.ClassVar[DiagCode]  # value = DiagCode(ExternIfaceArrayMethod)
    ExternWildcardPortList: typing.ClassVar[DiagCode]  # value = DiagCode(ExternWildcardPortList)
    ExtraPragmaArgs: typing.ClassVar[DiagCode]  # value = DiagCode(ExtraPragmaArgs)
    ExtraProtectEnd: typing.ClassVar[DiagCode]  # value = DiagCode(ExtraProtectEnd)
    FatalTask: typing.ClassVar[DiagCode]  # value = DiagCode(FatalTask)
    FinalSpecifierLast: typing.ClassVar[DiagCode]  # value = DiagCode(FinalSpecifierLast)
    FinalWithPure: typing.ClassVar[DiagCode]  # value = DiagCode(FinalWithPure)
    FloatBoolConv: typing.ClassVar[DiagCode]  # value = DiagCode(FloatBoolConv)
    FloatIntConv: typing.ClassVar[DiagCode]  # value = DiagCode(FloatIntConv)
    FloatNarrow: typing.ClassVar[DiagCode]  # value = DiagCode(FloatNarrow)
    FloatWiden: typing.ClassVar[DiagCode]  # value = DiagCode(FloatWiden)
    ForeachCallExpr: typing.ClassVar[DiagCode]  # value = DiagCode(ForeachCallExpr)
    ForeachDynamicDimAfterSkipped: typing.ClassVar[DiagCode]  # value = DiagCode(ForeachDynamicDimAfterSkipped)
    ForeachWildcardIndex: typing.ClassVar[DiagCode]  # value = DiagCode(ForeachWildcardIndex)
    ForkJoinAlwaysComb: typing.ClassVar[DiagCode]  # value = DiagCode(ForkJoinAlwaysComb)
    ForkLoopVar: typing.ClassVar[DiagCode]  # value = DiagCode(ForkLoopVar)
    FormatEmptyArg: typing.ClassVar[DiagCode]  # value = DiagCode(FormatEmptyArg)
    FormatMismatchedType: typing.ClassVar[DiagCode]  # value = DiagCode(FormatMismatchedType)
    FormatMultibitStrength: typing.ClassVar[DiagCode]  # value = DiagCode(FormatMultibitStrength)
    FormatNoArgument: typing.ClassVar[DiagCode]  # value = DiagCode(FormatNoArgument)
    FormatRealInt: typing.ClassVar[DiagCode]  # value = DiagCode(FormatRealInt)
    FormatSpecifierInvalidWidth: typing.ClassVar[DiagCode]  # value = DiagCode(FormatSpecifierInvalidWidth)
    FormatSpecifierNotFloat: typing.ClassVar[DiagCode]  # value = DiagCode(FormatSpecifierNotFloat)
    FormatSpecifierWidthNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(FormatSpecifierWidthNotAllowed)
    FormatTooManyArgs: typing.ClassVar[DiagCode]  # value = DiagCode(FormatTooManyArgs)
    FormatUnspecifiedType: typing.ClassVar[DiagCode]  # value = DiagCode(FormatUnspecifiedType)
    ForwardTypedefDoesNotMatch: typing.ClassVar[DiagCode]  # value = DiagCode(ForwardTypedefDoesNotMatch)
    ForwardTypedefVisibility: typing.ClassVar[DiagCode]  # value = DiagCode(ForwardTypedefVisibility)
    GFSVMatchItems: typing.ClassVar[DiagCode]  # value = DiagCode(GFSVMatchItems)
    GateUDNTConn: typing.ClassVar[DiagCode]  # value = DiagCode(GateUDNTConn)
    GenericClassScopeResolution: typing.ClassVar[DiagCode]  # value = DiagCode(GenericClassScopeResolution)
    GenvarDuplicate: typing.ClassVar[DiagCode]  # value = DiagCode(GenvarDuplicate)
    GenvarUnknownBits: typing.ClassVar[DiagCode]  # value = DiagCode(GenvarUnknownBits)
    GlobalClockEventExpr: typing.ClassVar[DiagCode]  # value = DiagCode(GlobalClockEventExpr)
    GlobalClockingEmpty: typing.ClassVar[DiagCode]  # value = DiagCode(GlobalClockingEmpty)
    GlobalClockingGenerate: typing.ClassVar[DiagCode]  # value = DiagCode(GlobalClockingGenerate)
    GlobalSampledValueAssertionExpr: typing.ClassVar[DiagCode]  # value = DiagCode(GlobalSampledValueAssertionExpr)
    GlobalSampledValueNested: typing.ClassVar[DiagCode]  # value = DiagCode(GlobalSampledValueNested)
    HeaderGuardMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(HeaderGuardMismatch)
    HierarchicalFromPackage: typing.ClassVar[DiagCode]  # value = DiagCode(HierarchicalFromPackage)
    HierarchicalRefUnknownModule: typing.ClassVar[DiagCode]  # value = DiagCode(HierarchicalRefUnknownModule)
    IfNoneEdgeSensitive: typing.ClassVar[DiagCode]  # value = DiagCode(IfNoneEdgeSensitive)
    IfaceExtendIncomplete: typing.ClassVar[DiagCode]  # value = DiagCode(IfaceExtendIncomplete)
    IfaceExtendTypeParam: typing.ClassVar[DiagCode]  # value = DiagCode(IfaceExtendTypeParam)
    IfaceImportExportTarget: typing.ClassVar[DiagCode]  # value = DiagCode(IfaceImportExportTarget)
    IfaceMethodHidden: typing.ClassVar[DiagCode]  # value = DiagCode(IfaceMethodHidden)
    IfaceMethodNoImpl: typing.ClassVar[DiagCode]  # value = DiagCode(IfaceMethodNoImpl)
    IfaceMethodNotExtern: typing.ClassVar[DiagCode]  # value = DiagCode(IfaceMethodNotExtern)
    IfaceMethodNotVirtual: typing.ClassVar[DiagCode]  # value = DiagCode(IfaceMethodNotVirtual)
    IfaceMethodPure: typing.ClassVar[DiagCode]  # value = DiagCode(IfaceMethodPure)
    IfaceNameConflict: typing.ClassVar[DiagCode]  # value = DiagCode(IfaceNameConflict)
    IfacePortInExpr: typing.ClassVar[DiagCode]  # value = DiagCode(IfacePortInExpr)
    IgnoredMacroPaste: typing.ClassVar[DiagCode]  # value = DiagCode(IgnoredMacroPaste)
    IgnoredSlice: typing.ClassVar[DiagCode]  # value = DiagCode(IgnoredSlice)
    IllegalReferenceToProgramItem: typing.ClassVar[DiagCode]  # value = DiagCode(IllegalReferenceToProgramItem)
    ImmediateAssertNotInProc: typing.ClassVar[DiagCode]  # value = DiagCode(ImmediateAssertNotInProc)
    ImplementNonIface: typing.ClassVar[DiagCode]  # value = DiagCode(ImplementNonIface)
    ImplicitConnNetInconsistent: typing.ClassVar[DiagCode]  # value = DiagCode(ImplicitConnNetInconsistent)
    ImplicitConvert: typing.ClassVar[DiagCode]  # value = DiagCode(ImplicitConvert)
    ImplicitEventInAssertion: typing.ClassVar[DiagCode]  # value = DiagCode(ImplicitEventInAssertion)
    ImplicitNamedPortNotFound: typing.ClassVar[DiagCode]  # value = DiagCode(ImplicitNamedPortNotFound)
    ImplicitNamedPortTypeMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(ImplicitNamedPortTypeMismatch)
    ImplicitNetPortNoDefault: typing.ClassVar[DiagCode]  # value = DiagCode(ImplicitNetPortNoDefault)
    ImplicitNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(ImplicitNotAllowed)
    ImplicitParamTypeKeyword: typing.ClassVar[DiagCode]  # value = DiagCode(ImplicitParamTypeKeyword)
    ImportNameCollision: typing.ClassVar[DiagCode]  # value = DiagCode(ImportNameCollision)
    InOutDefaultSkew: typing.ClassVar[DiagCode]  # value = DiagCode(InOutDefaultSkew)
    InOutPortCannotBeVariable: typing.ClassVar[DiagCode]  # value = DiagCode(InOutPortCannotBeVariable)
    InOutUWireConn: typing.ClassVar[DiagCode]  # value = DiagCode(InOutUWireConn)
    InOutUWirePort: typing.ClassVar[DiagCode]  # value = DiagCode(InOutUWirePort)
    InOutVarPortConn: typing.ClassVar[DiagCode]  # value = DiagCode(InOutVarPortConn)
    IncDecBit: typing.ClassVar[DiagCode]  # value = DiagCode(IncDecBit)
    IncDecNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(IncDecNotAllowed)
    IncompleteReturn: typing.ClassVar[DiagCode]  # value = DiagCode(IncompleteReturn)
    IndexOOB: typing.ClassVar[DiagCode]  # value = DiagCode(IndexOOB)
    IndexValueInvalid: typing.ClassVar[DiagCode]  # value = DiagCode(IndexValueInvalid)
    InequivalentUniquenessTypes: typing.ClassVar[DiagCode]  # value = DiagCode(InequivalentUniquenessTypes)
    InferredComb: typing.ClassVar[DiagCode]  # value = DiagCode(InferredComb)
    InferredLatch: typing.ClassVar[DiagCode]  # value = DiagCode(InferredLatch)
    InferredValDefArg: typing.ClassVar[DiagCode]  # value = DiagCode(InferredValDefArg)
    InfinitelyRecursiveHierarchy: typing.ClassVar[DiagCode]  # value = DiagCode(InfinitelyRecursiveHierarchy)
    InfoTask: typing.ClassVar[DiagCode]  # value = DiagCode(InfoTask)
    InheritFromAbstract: typing.ClassVar[DiagCode]  # value = DiagCode(InheritFromAbstract)
    InheritFromAbstractConstraint: typing.ClassVar[DiagCode]  # value = DiagCode(InheritFromAbstractConstraint)
    InitSelf: typing.ClassVar[DiagCode]  # value = DiagCode(InitSelf)
    InitializerRequired: typing.ClassVar[DiagCode]  # value = DiagCode(InitializerRequired)
    InputPortAssign: typing.ClassVar[DiagCode]  # value = DiagCode(InputPortAssign)
    InputPortCoercion: typing.ClassVar[DiagCode]  # value = DiagCode(InputPortCoercion)
    InstanceArrayOrderMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(InstanceArrayOrderMismatch)
    InstanceMissingParens: typing.ClassVar[DiagCode]  # value = DiagCode(InstanceMissingParens)
    InstanceNameRequired: typing.ClassVar[DiagCode]  # value = DiagCode(InstanceNameRequired)
    InstanceWithDelay: typing.ClassVar[DiagCode]  # value = DiagCode(InstanceWithDelay)
    InstanceWithStrength: typing.ClassVar[DiagCode]  # value = DiagCode(InstanceWithStrength)
    IntBoolConv: typing.ClassVar[DiagCode]  # value = DiagCode(IntBoolConv)
    IntFloatConv: typing.ClassVar[DiagCode]  # value = DiagCode(IntFloatConv)
    InterconnectDelaySyntax: typing.ClassVar[DiagCode]  # value = DiagCode(InterconnectDelaySyntax)
    InterconnectInitializer: typing.ClassVar[DiagCode]  # value = DiagCode(InterconnectInitializer)
    InterconnectMultiPort: typing.ClassVar[DiagCode]  # value = DiagCode(InterconnectMultiPort)
    InterconnectPortVar: typing.ClassVar[DiagCode]  # value = DiagCode(InterconnectPortVar)
    InterconnectReference: typing.ClassVar[DiagCode]  # value = DiagCode(InterconnectReference)
    InterconnectTypeSyntax: typing.ClassVar[DiagCode]  # value = DiagCode(InterconnectTypeSyntax)
    InterfacePortInvalidExpression: typing.ClassVar[DiagCode]  # value = DiagCode(InterfacePortInvalidExpression)
    InterfacePortNotConnected: typing.ClassVar[DiagCode]  # value = DiagCode(InterfacePortNotConnected)
    InterfacePortTypeMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(InterfacePortTypeMismatch)
    InvalidAccessDotColon: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidAccessDotColon)
    InvalidArgumentExpr: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidArgumentExpr)
    InvalidArrayElemType: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidArrayElemType)
    InvalidArraySize: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidArraySize)
    InvalidAssociativeIndexType: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidAssociativeIndexType)
    InvalidBindTarget: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidBindTarget)
    InvalidBinsMatches: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidBinsMatches)
    InvalidBinsTarget: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidBinsTarget)
    InvalidBlockEventTarget: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidBlockEventTarget)
    InvalidClassAccess: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidClassAccess)
    InvalidClockingSignal: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidClockingSignal)
    InvalidCommaInPropExpr: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidCommaInPropExpr)
    InvalidConstraintExpr: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidConstraintExpr)
    InvalidConstraintQualifier: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidConstraintQualifier)
    InvalidConstructorAccess: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidConstructorAccess)
    InvalidCoverageExpr: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidCoverageExpr)
    InvalidCoverageOption: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidCoverageOption)
    InvalidDPIArgType: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidDPIArgType)
    InvalidDPICIdentifier: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidDPICIdentifier)
    InvalidDPIReturnType: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidDPIReturnType)
    InvalidDeferredAssertAction: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidDeferredAssertAction)
    InvalidDelayValue: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidDelayValue)
    InvalidDimensionRange: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidDimensionRange)
    InvalidDisableTarget: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidDisableTarget)
    InvalidDistExpression: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidDistExpression)
    InvalidEdgeDescriptor: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidEdgeDescriptor)
    InvalidEncodingByte: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidEncodingByte)
    InvalidEnumBase: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidEnumBase)
    InvalidEventExpression: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidEventExpression)
    InvalidExtendsDefault: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidExtendsDefault)
    InvalidForInitializer: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidForInitializer)
    InvalidForStepExpression: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidForStepExpression)
    InvalidGenvarIterExpression: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidGenvarIterExpression)
    InvalidHexEscapeCode: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidHexEscapeCode)
    InvalidHierarchicalIfacePortConn: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidHierarchicalIfacePortConn)
    InvalidInferredTimeScale: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidInferredTimeScale)
    InvalidInstanceForParent: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidInstanceForParent)
    InvalidLineDirectiveLevel: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidLineDirectiveLevel)
    InvalidMacroName: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidMacroName)
    InvalidMatchItem: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidMatchItem)
    InvalidMemberAccess: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidMemberAccess)
    InvalidMethodOverride: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidMethodOverride)
    InvalidMethodQualifier: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidMethodQualifier)
    InvalidModportAccess: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidModportAccess)
    InvalidMulticlockedSeqOp: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidMulticlockedSeqOp)
    InvalidNGateCount: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidNGateCount)
    InvalidNetType: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidNetType)
    InvalidPackageDecl: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPackageDecl)
    InvalidParamOverrideOpt: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidParamOverrideOpt)
    InvalidPortSubType: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPortSubType)
    InvalidPortType: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPortType)
    InvalidPragmaNumber: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPragmaNumber)
    InvalidPragmaViewport: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPragmaViewport)
    InvalidPrimInstanceForParent: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPrimInstanceForParent)
    InvalidPrimitivePortConn: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPrimitivePortConn)
    InvalidPropertyIndex: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPropertyIndex)
    InvalidPropertyQualifier: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPropertyQualifier)
    InvalidPropertyRange: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPropertyRange)
    InvalidPullStrength: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPullStrength)
    InvalidPulseStyle: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidPulseStyle)
    InvalidQualifierForConstructor: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidQualifierForConstructor)
    InvalidQualifierForIfaceMember: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidQualifierForIfaceMember)
    InvalidQualifierForMember: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidQualifierForMember)
    InvalidRandType: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidRandType)
    InvalidRandomizeOverride: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidRandomizeOverride)
    InvalidRefArg: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidRefArg)
    InvalidRepeatRange: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidRepeatRange)
    InvalidScopeIndexExpression: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidScopeIndexExpression)
    InvalidSelectExpression: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidSelectExpression)
    InvalidSignalEventInSeq: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidSignalEventInSeq)
    InvalidSpecifyDest: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidSpecifyDest)
    InvalidSpecifyPath: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidSpecifyPath)
    InvalidSpecifySource: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidSpecifySource)
    InvalidSpecifyType: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidSpecifyType)
    InvalidStmtInChecker: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidStmtInChecker)
    InvalidStringArg: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidStringArg)
    InvalidSuperNew: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidSuperNew)
    InvalidSuperNewDefault: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidSuperNewDefault)
    InvalidSyntaxInEventExpr: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidSyntaxInEventExpr)
    InvalidThisHandle: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidThisHandle)
    InvalidTimeScalePrecision: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidTimeScalePrecision)
    InvalidTimeScaleSpecifier: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidTimeScaleSpecifier)
    InvalidTimingCheckNotifierArg: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidTimingCheckNotifierArg)
    InvalidTopModule: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidTopModule)
    InvalidUTF8Seq: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidUTF8Seq)
    InvalidUnionMember: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidUnionMember)
    InvalidUniquenessExpr: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidUniquenessExpr)
    InvalidUserDefinedNetType: typing.ClassVar[DiagCode]  # value = DiagCode(InvalidUserDefinedNetType)
    IsUnboundedParamArg: typing.ClassVar[DiagCode]  # value = DiagCode(IsUnboundedParamArg)
    IteratorArgsWithoutWithClause: typing.ClassVar[DiagCode]  # value = DiagCode(IteratorArgsWithoutWithClause)
    LabelAndName: typing.ClassVar[DiagCode]  # value = DiagCode(LabelAndName)
    LetHierarchical: typing.ClassVar[DiagCode]  # value = DiagCode(LetHierarchical)
    LifetimeForPrototype: typing.ClassVar[DiagCode]  # value = DiagCode(LifetimeForPrototype)
    LiteralSizeIsZero: typing.ClassVar[DiagCode]  # value = DiagCode(LiteralSizeIsZero)
    LiteralSizeTooLarge: typing.ClassVar[DiagCode]  # value = DiagCode(LiteralSizeTooLarge)
    LocalMemberAccess: typing.ClassVar[DiagCode]  # value = DiagCode(LocalMemberAccess)
    LocalNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(LocalNotAllowed)
    LocalParamNoInitializer: typing.ClassVar[DiagCode]  # value = DiagCode(LocalParamNoInitializer)
    LocalVarEventExpr: typing.ClassVar[DiagCode]  # value = DiagCode(LocalVarEventExpr)
    LocalVarMatchItem: typing.ClassVar[DiagCode]  # value = DiagCode(LocalVarMatchItem)
    LocalVarOutputEmptyMatch: typing.ClassVar[DiagCode]  # value = DiagCode(LocalVarOutputEmptyMatch)
    LocalVarTypeRequired: typing.ClassVar[DiagCode]  # value = DiagCode(LocalVarTypeRequired)
    LogicalNotParentheses: typing.ClassVar[DiagCode]  # value = DiagCode(LogicalNotParentheses)
    LogicalOpParentheses: typing.ClassVar[DiagCode]  # value = DiagCode(LogicalOpParentheses)
    LoopCondNotModified: typing.ClassVar[DiagCode]  # value = DiagCode(LoopCondNotModified)
    LoopVarModify: typing.ClassVar[DiagCode]  # value = DiagCode(LoopVarModify)
    LoopVarShadowsArray: typing.ClassVar[DiagCode]  # value = DiagCode(LoopVarShadowsArray)
    MacroOpsOutsideDefinition: typing.ClassVar[DiagCode]  # value = DiagCode(MacroOpsOutsideDefinition)
    MacroTokensAfterPragmaProtect: typing.ClassVar[DiagCode]  # value = DiagCode(MacroTokensAfterPragmaProtect)
    MatchItemsAdmitEmpty: typing.ClassVar[DiagCode]  # value = DiagCode(MatchItemsAdmitEmpty)
    MaxGenerateStepsExceeded: typing.ClassVar[DiagCode]  # value = DiagCode(MaxGenerateStepsExceeded)
    MaxInstanceArrayExceeded: typing.ClassVar[DiagCode]  # value = DiagCode(MaxInstanceArrayExceeded)
    MaxInstanceDepthExceeded: typing.ClassVar[DiagCode]  # value = DiagCode(MaxInstanceDepthExceeded)
    MemberDefinitionBeforeClass: typing.ClassVar[DiagCode]  # value = DiagCode(MemberDefinitionBeforeClass)
    MemberImplNotFound: typing.ClassVar[DiagCode]  # value = DiagCode(MemberImplNotFound)
    MethodArgCountMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(MethodArgCountMismatch)
    MethodArgDefaultMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(MethodArgDefaultMismatch)
    MethodArgDirectionMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(MethodArgDirectionMismatch)
    MethodArgNameMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(MethodArgNameMismatch)
    MethodArgNoDefault: typing.ClassVar[DiagCode]  # value = DiagCode(MethodArgNoDefault)
    MethodArgTypeMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(MethodArgTypeMismatch)
    MethodKindMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(MethodKindMismatch)
    MethodReturnMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(MethodReturnMismatch)
    MethodReturnTypeScoped: typing.ClassVar[DiagCode]  # value = DiagCode(MethodReturnTypeScoped)
    MethodStaticLifetime: typing.ClassVar[DiagCode]  # value = DiagCode(MethodStaticLifetime)
    MisleadingIndentation: typing.ClassVar[DiagCode]  # value = DiagCode(MisleadingIndentation)
    MismatchConstraintSpecifiers: typing.ClassVar[DiagCode]  # value = DiagCode(MismatchConstraintSpecifiers)
    MismatchStaticConstraint: typing.ClassVar[DiagCode]  # value = DiagCode(MismatchStaticConstraint)
    MismatchedEndKeywordsDirective: typing.ClassVar[DiagCode]  # value = DiagCode(MismatchedEndKeywordsDirective)
    MismatchedTimeScales: typing.ClassVar[DiagCode]  # value = DiagCode(MismatchedTimeScales)
    MismatchedUserDefPortConn: typing.ClassVar[DiagCode]  # value = DiagCode(MismatchedUserDefPortConn)
    MismatchedUserDefPortDir: typing.ClassVar[DiagCode]  # value = DiagCode(MismatchedUserDefPortDir)
    MisplacedDirectiveChar: typing.ClassVar[DiagCode]  # value = DiagCode(MisplacedDirectiveChar)
    MisplacedTrailingSeparator: typing.ClassVar[DiagCode]  # value = DiagCode(MisplacedTrailingSeparator)
    MissingConstraintBlock: typing.ClassVar[DiagCode]  # value = DiagCode(MissingConstraintBlock)
    MissingEndIfDirective: typing.ClassVar[DiagCode]  # value = DiagCode(MissingEndIfDirective)
    MissingExponentDigits: typing.ClassVar[DiagCode]  # value = DiagCode(MissingExponentDigits)
    MissingExportImpl: typing.ClassVar[DiagCode]  # value = DiagCode(MissingExportImpl)
    MissingExternImpl: typing.ClassVar[DiagCode]  # value = DiagCode(MissingExternImpl)
    MissingExternModuleImpl: typing.ClassVar[DiagCode]  # value = DiagCode(MissingExternModuleImpl)
    MissingExternWildcardPorts: typing.ClassVar[DiagCode]  # value = DiagCode(MissingExternWildcardPorts)
    MissingFormatSpecifier: typing.ClassVar[DiagCode]  # value = DiagCode(MissingFormatSpecifier)
    MissingFractionalDigits: typing.ClassVar[DiagCode]  # value = DiagCode(MissingFractionalDigits)
    MissingInvocationParens: typing.ClassVar[DiagCode]  # value = DiagCode(MissingInvocationParens)
    MissingModportPortDirection: typing.ClassVar[DiagCode]  # value = DiagCode(MissingModportPortDirection)
    MissingPortIODeclaration: typing.ClassVar[DiagCode]  # value = DiagCode(MissingPortIODeclaration)
    MissingReturn: typing.ClassVar[DiagCode]  # value = DiagCode(MissingReturn)
    MissingReturnValue: typing.ClassVar[DiagCode]  # value = DiagCode(MissingReturnValue)
    MissingReturnValueProd: typing.ClassVar[DiagCode]  # value = DiagCode(MissingReturnValueProd)
    MissingTimeScale: typing.ClassVar[DiagCode]  # value = DiagCode(MissingTimeScale)
    MixedVarAssigns: typing.ClassVar[DiagCode]  # value = DiagCode(MixedVarAssigns)
    MixingOrderedAndNamedArgs: typing.ClassVar[DiagCode]  # value = DiagCode(MixingOrderedAndNamedArgs)
    MixingOrderedAndNamedParams: typing.ClassVar[DiagCode]  # value = DiagCode(MixingOrderedAndNamedParams)
    MixingOrderedAndNamedPorts: typing.ClassVar[DiagCode]  # value = DiagCode(MixingOrderedAndNamedPorts)
    MixingSubroutinePortKinds: typing.ClassVar[DiagCode]  # value = DiagCode(MixingSubroutinePortKinds)
    ModportConnMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(ModportConnMismatch)
    ModportMemberParent: typing.ClassVar[DiagCode]  # value = DiagCode(ModportMemberParent)
    MultiBitEdge: typing.ClassVar[DiagCode]  # value = DiagCode(MultiBitEdge)
    MultiWriteExpr: typing.ClassVar[DiagCode]  # value = DiagCode(MultiWriteExpr)
    MulticlockedInClockingBlock: typing.ClassVar[DiagCode]  # value = DiagCode(MulticlockedInClockingBlock)
    MulticlockedSeqEmptyMatch: typing.ClassVar[DiagCode]  # value = DiagCode(MulticlockedSeqEmptyMatch)
    MultipleAlwaysAssigns: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleAlwaysAssigns)
    MultipleContAssigns: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleContAssigns)
    MultipleDefaultCases: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleDefaultCases)
    MultipleDefaultClocking: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleDefaultClocking)
    MultipleDefaultConstructorArg: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleDefaultConstructorArg)
    MultipleDefaultDisable: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleDefaultDisable)
    MultipleDefaultDistWeight: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleDefaultDistWeight)
    MultipleDefaultInputSkew: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleDefaultInputSkew)
    MultipleDefaultOutputSkew: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleDefaultOutputSkew)
    MultipleDefaultRules: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleDefaultRules)
    MultipleGenerateDefaultCases: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleGenerateDefaultCases)
    MultipleGlobalClocking: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleGlobalClocking)
    MultipleNetAlias: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleNetAlias)
    MultiplePackedOpenArrays: typing.ClassVar[DiagCode]  # value = DiagCode(MultiplePackedOpenArrays)
    MultipleParallelTerminals: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleParallelTerminals)
    MultipleTopDupName: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleTopDupName)
    MultipleUDNTDrivers: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleUDNTDrivers)
    MultipleUWireDrivers: typing.ClassVar[DiagCode]  # value = DiagCode(MultipleUWireDrivers)
    NTResolveArgModify: typing.ClassVar[DiagCode]  # value = DiagCode(NTResolveArgModify)
    NTResolveClass: typing.ClassVar[DiagCode]  # value = DiagCode(NTResolveClass)
    NTResolveReturn: typing.ClassVar[DiagCode]  # value = DiagCode(NTResolveReturn)
    NTResolveSingleArg: typing.ClassVar[DiagCode]  # value = DiagCode(NTResolveSingleArg)
    NTResolveTask: typing.ClassVar[DiagCode]  # value = DiagCode(NTResolveTask)
    NTResolveUserDef: typing.ClassVar[DiagCode]  # value = DiagCode(NTResolveUserDef)
    NameListWithScopeRandomize: typing.ClassVar[DiagCode]  # value = DiagCode(NameListWithScopeRandomize)
    NamedArgNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(NamedArgNotAllowed)
    NegativeTimingLimit: typing.ClassVar[DiagCode]  # value = DiagCode(NegativeTimingLimit)
    NestedBlockComment: typing.ClassVar[DiagCode]  # value = DiagCode(NestedBlockComment)
    NestedConfigMultipleTops: typing.ClassVar[DiagCode]  # value = DiagCode(NestedConfigMultipleTops)
    NestedDisableIff: typing.ClassVar[DiagCode]  # value = DiagCode(NestedDisableIff)
    NestedIface: typing.ClassVar[DiagCode]  # value = DiagCode(NestedIface)
    NestedNonStaticClassMethod: typing.ClassVar[DiagCode]  # value = DiagCode(NestedNonStaticClassMethod)
    NestedNonStaticClassProperty: typing.ClassVar[DiagCode]  # value = DiagCode(NestedNonStaticClassProperty)
    NestedProtectBegin: typing.ClassVar[DiagCode]  # value = DiagCode(NestedProtectBegin)
    NetAliasCommonNetType: typing.ClassVar[DiagCode]  # value = DiagCode(NetAliasCommonNetType)
    NetAliasHierarchical: typing.ClassVar[DiagCode]  # value = DiagCode(NetAliasHierarchical)
    NetAliasNotANet: typing.ClassVar[DiagCode]  # value = DiagCode(NetAliasNotANet)
    NetAliasSelf: typing.ClassVar[DiagCode]  # value = DiagCode(NetAliasSelf)
    NetAliasWidthMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(NetAliasWidthMismatch)
    NetInconsistent: typing.ClassVar[DiagCode]  # value = DiagCode(NetInconsistent)
    NetRangeInconsistent: typing.ClassVar[DiagCode]  # value = DiagCode(NetRangeInconsistent)
    NewArrayTarget: typing.ClassVar[DiagCode]  # value = DiagCode(NewArrayTarget)
    NewClassTarget: typing.ClassVar[DiagCode]  # value = DiagCode(NewClassTarget)
    NewInterfaceClass: typing.ClassVar[DiagCode]  # value = DiagCode(NewInterfaceClass)
    NewKeywordQualified: typing.ClassVar[DiagCode]  # value = DiagCode(NewKeywordQualified)
    NewVirtualClass: typing.ClassVar[DiagCode]  # value = DiagCode(NewVirtualClass)
    NewlineEOF: typing.ClassVar[DiagCode]  # value = DiagCode(NewlineEOF)
    NoChangeEdgeRequired: typing.ClassVar[DiagCode]  # value = DiagCode(NoChangeEdgeRequired)
    NoCommaInList: typing.ClassVar[DiagCode]  # value = DiagCode(NoCommaInList)
    NoCommonComparisonType: typing.ClassVar[DiagCode]  # value = DiagCode(NoCommonComparisonType)
    NoConstraintBody: typing.ClassVar[DiagCode]  # value = DiagCode(NoConstraintBody)
    NoDeclInClass: typing.ClassVar[DiagCode]  # value = DiagCode(NoDeclInClass)
    NoDefaultClocking: typing.ClassVar[DiagCode]  # value = DiagCode(NoDefaultClocking)
    NoDefaultSpecialization: typing.ClassVar[DiagCode]  # value = DiagCode(NoDefaultSpecialization)
    NoGlobalClocking: typing.ClassVar[DiagCode]  # value = DiagCode(NoGlobalClocking)
    NoImplicitConversion: typing.ClassVar[DiagCode]  # value = DiagCode(NoImplicitConversion)
    NoInferredClock: typing.ClassVar[DiagCode]  # value = DiagCode(NoInferredClock)
    NoLabelOnSemicolon: typing.ClassVar[DiagCode]  # value = DiagCode(NoLabelOnSemicolon)
    NoTopModules: typing.ClassVar[DiagCode]  # value = DiagCode(NoTopModules)
    NoUniqueClock: typing.ClassVar[DiagCode]  # value = DiagCode(NoUniqueClock)
    NonIntegralConstraintLiteral: typing.ClassVar[DiagCode]  # value = DiagCode(NonIntegralConstraintLiteral)
    NonPrintableChar: typing.ClassVar[DiagCode]  # value = DiagCode(NonPrintableChar)
    NonProceduralFuncArg: typing.ClassVar[DiagCode]  # value = DiagCode(NonProceduralFuncArg)
    NonStandardGenBlock: typing.ClassVar[DiagCode]  # value = DiagCode(NonStandardGenBlock)
    NonStaticClassMethod: typing.ClassVar[DiagCode]  # value = DiagCode(NonStaticClassMethod)
    NonStaticClassProperty: typing.ClassVar[DiagCode]  # value = DiagCode(NonStaticClassProperty)
    NonblockingAssignmentToAuto: typing.ClassVar[DiagCode]  # value = DiagCode(NonblockingAssignmentToAuto)
    NonblockingDynamicAssign: typing.ClassVar[DiagCode]  # value = DiagCode(NonblockingDynamicAssign)
    NonblockingInFinal: typing.ClassVar[DiagCode]  # value = DiagCode(NonblockingInFinal)
    NonstandardConstraintBlock: typing.ClassVar[DiagCode]  # value = DiagCode(NonstandardConstraintBlock)
    NonstandardDist: typing.ClassVar[DiagCode]  # value = DiagCode(NonstandardDist)
    NonstandardEscapeCode: typing.ClassVar[DiagCode]  # value = DiagCode(NonstandardEscapeCode)
    NonstandardForeach: typing.ClassVar[DiagCode]  # value = DiagCode(NonstandardForeach)
    NonstandardHierarchicalCross: typing.ClassVar[DiagCode]  # value = DiagCode(NonstandardHierarchicalCross)
    NonstandardInside: typing.ClassVar[DiagCode]  # value = DiagCode(NonstandardInside)
    NonstandardScopeRandomize: typing.ClassVar[DiagCode]  # value = DiagCode(NonstandardScopeRandomize)
    NonstandardStringConcat: typing.ClassVar[DiagCode]  # value = DiagCode(NonstandardStringConcat)
    NonstandardSysFunc: typing.ClassVar[DiagCode]  # value = DiagCode(NonstandardSysFunc)
    NotAChecker: typing.ClassVar[DiagCode]  # value = DiagCode(NotAChecker)
    NotAClass: typing.ClassVar[DiagCode]  # value = DiagCode(NotAClass)
    NotAClockingBlock: typing.ClassVar[DiagCode]  # value = DiagCode(NotAClockingBlock)
    NotAGenericClass: typing.ClassVar[DiagCode]  # value = DiagCode(NotAGenericClass)
    NotAGenvar: typing.ClassVar[DiagCode]  # value = DiagCode(NotAGenvar)
    NotAHierarchicalScope: typing.ClassVar[DiagCode]  # value = DiagCode(NotAHierarchicalScope)
    NotAModport: typing.ClassVar[DiagCode]  # value = DiagCode(NotAModport)
    NotAProduction: typing.ClassVar[DiagCode]  # value = DiagCode(NotAProduction)
    NotASubroutine: typing.ClassVar[DiagCode]  # value = DiagCode(NotASubroutine)
    NotAType: typing.ClassVar[DiagCode]  # value = DiagCode(NotAType)
    NotAValue: typing.ClassVar[DiagCode]  # value = DiagCode(NotAValue)
    NotAllowedInAnonymousProgram: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInAnonymousProgram)
    NotAllowedInCU: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInCU)
    NotAllowedInChecker: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInChecker)
    NotAllowedInClass: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInClass)
    NotAllowedInClocking: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInClocking)
    NotAllowedInGenerate: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInGenerate)
    NotAllowedInIfaceClass: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInIfaceClass)
    NotAllowedInInterface: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInInterface)
    NotAllowedInModport: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInModport)
    NotAllowedInModule: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInModule)
    NotAllowedInPackage: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInPackage)
    NotAllowedInProgram: typing.ClassVar[DiagCode]  # value = DiagCode(NotAllowedInProgram)
    NotAnArray: typing.ClassVar[DiagCode]  # value = DiagCode(NotAnArray)
    NotAnEvent: typing.ClassVar[DiagCode]  # value = DiagCode(NotAnEvent)
    NotAnInterface: typing.ClassVar[DiagCode]  # value = DiagCode(NotAnInterface)
    NotAnInterfaceOrPort: typing.ClassVar[DiagCode]  # value = DiagCode(NotAnInterfaceOrPort)
    NotBooleanConvertible: typing.ClassVar[DiagCode]  # value = DiagCode(NotBooleanConvertible)
    NotEnoughMacroArgs: typing.ClassVar[DiagCode]  # value = DiagCode(NotEnoughMacroArgs)
    NoteAliasDeclaration: typing.ClassVar[DiagCode]  # value = DiagCode(NoteAliasDeclaration)
    NoteAliasedTo: typing.ClassVar[DiagCode]  # value = DiagCode(NoteAliasedTo)
    NoteAlwaysFalse: typing.ClassVar[DiagCode]  # value = DiagCode(NoteAlwaysFalse)
    NoteAssignedHere: typing.ClassVar[DiagCode]  # value = DiagCode(NoteAssignedHere)
    NoteCalledHere: typing.ClassVar[DiagCode]  # value = DiagCode(NoteCalledHere)
    NoteClockHere: typing.ClassVar[DiagCode]  # value = DiagCode(NoteClockHere)
    NoteCommonAncestor: typing.ClassVar[DiagCode]  # value = DiagCode(NoteCommonAncestor)
    NoteComparisonReduces: typing.ClassVar[DiagCode]  # value = DiagCode(NoteComparisonReduces)
    NoteConditionalPrecedenceFix: typing.ClassVar[DiagCode]  # value = DiagCode(NoteConditionalPrecedenceFix)
    NoteConfigRule: typing.ClassVar[DiagCode]  # value = DiagCode(NoteConfigRule)
    NoteConstraintFuncArgOrder: typing.ClassVar[DiagCode]  # value = DiagCode(NoteConstraintFuncArgOrder)
    NoteConstraintSolveBeforeEdge: typing.ClassVar[DiagCode]  # value = DiagCode(NoteConstraintSolveBeforeEdge)
    NoteDeclarationHere: typing.ClassVar[DiagCode]  # value = DiagCode(NoteDeclarationHere)
    NoteDidYouMean: typing.ClassVar[DiagCode]  # value = DiagCode(NoteDidYouMean)
    NoteDirectiveHere: typing.ClassVar[DiagCode]  # value = DiagCode(NoteDirectiveHere)
    NoteDrivenHere: typing.ClassVar[DiagCode]  # value = DiagCode(NoteDrivenHere)
    NoteExpandedHere: typing.ClassVar[DiagCode]  # value = DiagCode(NoteExpandedHere)
    NoteForPortConn: typing.ClassVar[DiagCode]  # value = DiagCode(NoteForPortConn)
    NoteFromHere2: typing.ClassVar[DiagCode]  # value = DiagCode(NoteFromHere2)
    NoteHierarchicalRef: typing.ClassVar[DiagCode]  # value = DiagCode(NoteHierarchicalRef)
    NoteImportedFrom: typing.ClassVar[DiagCode]  # value = DiagCode(NoteImportedFrom)
    NoteInCallTo: typing.ClassVar[DiagCode]  # value = DiagCode(NoteInCallTo)
    NoteLastBlockEnded: typing.ClassVar[DiagCode]  # value = DiagCode(NoteLastBlockEnded)
    NoteLastBlockStarted: typing.ClassVar[DiagCode]  # value = DiagCode(NoteLastBlockStarted)
    NoteLogicalNotFix: typing.ClassVar[DiagCode]  # value = DiagCode(NoteLogicalNotFix)
    NoteLogicalNotSilence: typing.ClassVar[DiagCode]  # value = DiagCode(NoteLogicalNotSilence)
    NoteLoopVarStep: typing.ClassVar[DiagCode]  # value = DiagCode(NoteLoopVarStep)
    NoteMatchingIf: typing.ClassVar[DiagCode]  # value = DiagCode(NoteMatchingIf)
    NoteOriginalAssign: typing.ClassVar[DiagCode]  # value = DiagCode(NoteOriginalAssign)
    NotePortConnHere: typing.ClassVar[DiagCode]  # value = DiagCode(NotePortConnHere)
    NotePrecedenceBitwiseFirst: typing.ClassVar[DiagCode]  # value = DiagCode(NotePrecedenceBitwiseFirst)
    NotePrecedenceSilence: typing.ClassVar[DiagCode]  # value = DiagCode(NotePrecedenceSilence)
    NotePreviousDefinition: typing.ClassVar[DiagCode]  # value = DiagCode(NotePreviousDefinition)
    NotePreviousMatch: typing.ClassVar[DiagCode]  # value = DiagCode(NotePreviousMatch)
    NotePreviousUsage: typing.ClassVar[DiagCode]  # value = DiagCode(NotePreviousUsage)
    NoteReferencedHere: typing.ClassVar[DiagCode]  # value = DiagCode(NoteReferencedHere)
    NoteRequiredHere: typing.ClassVar[DiagCode]  # value = DiagCode(NoteRequiredHere)
    NoteSkippingFrames: typing.ClassVar[DiagCode]  # value = DiagCode(NoteSkippingFrames)
    NoteToMatchThis: typing.ClassVar[DiagCode]  # value = DiagCode(NoteToMatchThis)
    NoteUdpCoverage: typing.ClassVar[DiagCode]  # value = DiagCode(NoteUdpCoverage)
    NoteWhileExpanding: typing.ClassVar[DiagCode]  # value = DiagCode(NoteWhileExpanding)
    NullPort: typing.ClassVar[DiagCode]  # value = DiagCode(NullPort)
    NullPortExpression: typing.ClassVar[DiagCode]  # value = DiagCode(NullPortExpression)
    ObjectTooLarge: typing.ClassVar[DiagCode]  # value = DiagCode(ObjectTooLarge)
    OctalEscapeCodeTooBig: typing.ClassVar[DiagCode]  # value = DiagCode(OctalEscapeCodeTooBig)
    OutRefFuncConstraint: typing.ClassVar[DiagCode]  # value = DiagCode(OutRefFuncConstraint)
    OutputPortCoercion: typing.ClassVar[DiagCode]  # value = DiagCode(OutputPortCoercion)
    OverridingExtends: typing.ClassVar[DiagCode]  # value = DiagCode(OverridingExtends)
    OverridingFinal: typing.ClassVar[DiagCode]  # value = DiagCode(OverridingFinal)
    OverridingInitial: typing.ClassVar[DiagCode]  # value = DiagCode(OverridingInitial)
    PackageExportNotImported: typing.ClassVar[DiagCode]  # value = DiagCode(PackageExportNotImported)
    PackageExportSelf: typing.ClassVar[DiagCode]  # value = DiagCode(PackageExportSelf)
    PackageImportInClass: typing.ClassVar[DiagCode]  # value = DiagCode(PackageImportInClass)
    PackageImportSelf: typing.ClassVar[DiagCode]  # value = DiagCode(PackageImportSelf)
    PackageNetInit: typing.ClassVar[DiagCode]  # value = DiagCode(PackageNetInit)
    PackedArrayConv: typing.ClassVar[DiagCode]  # value = DiagCode(PackedArrayConv)
    PackedArrayNotIntegral: typing.ClassVar[DiagCode]  # value = DiagCode(PackedArrayNotIntegral)
    PackedDimsOnPredefinedType: typing.ClassVar[DiagCode]  # value = DiagCode(PackedDimsOnPredefinedType)
    PackedDimsOnUnpacked: typing.ClassVar[DiagCode]  # value = DiagCode(PackedDimsOnUnpacked)
    PackedDimsRequireFullRange: typing.ClassVar[DiagCode]  # value = DiagCode(PackedDimsRequireFullRange)
    PackedMemberHasInitializer: typing.ClassVar[DiagCode]  # value = DiagCode(PackedMemberHasInitializer)
    PackedMemberNotIntegral: typing.ClassVar[DiagCode]  # value = DiagCode(PackedMemberNotIntegral)
    PackedTypeTooLarge: typing.ClassVar[DiagCode]  # value = DiagCode(PackedTypeTooLarge)
    PackedUnionWidthMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(PackedUnionWidthMismatch)
    ParallelPathWidth: typing.ClassVar[DiagCode]  # value = DiagCode(ParallelPathWidth)
    ParamHasNoValue: typing.ClassVar[DiagCode]  # value = DiagCode(ParamHasNoValue)
    ParameterDoesNotExist: typing.ClassVar[DiagCode]  # value = DiagCode(ParameterDoesNotExist)
    ParseTreeTooDeep: typing.ClassVar[DiagCode]  # value = DiagCode(ParseTreeTooDeep)
    PastNumTicksInvalid: typing.ClassVar[DiagCode]  # value = DiagCode(PastNumTicksInvalid)
    PathPulseInExpr: typing.ClassVar[DiagCode]  # value = DiagCode(PathPulseInExpr)
    PathPulseInvalidPathName: typing.ClassVar[DiagCode]  # value = DiagCode(PathPulseInvalidPathName)
    PatternStructTooFew: typing.ClassVar[DiagCode]  # value = DiagCode(PatternStructTooFew)
    PatternStructTooMany: typing.ClassVar[DiagCode]  # value = DiagCode(PatternStructTooMany)
    PatternStructType: typing.ClassVar[DiagCode]  # value = DiagCode(PatternStructType)
    PatternTaggedType: typing.ClassVar[DiagCode]  # value = DiagCode(PatternTaggedType)
    PlaRangeInAscendingOrder: typing.ClassVar[DiagCode]  # value = DiagCode(PlaRangeInAscendingOrder)
    PointlessVoidCast: typing.ClassVar[DiagCode]  # value = DiagCode(PointlessVoidCast)
    PortConcatInOut: typing.ClassVar[DiagCode]  # value = DiagCode(PortConcatInOut)
    PortConcatRef: typing.ClassVar[DiagCode]  # value = DiagCode(PortConcatRef)
    PortConnArrayMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(PortConnArrayMismatch)
    PortConnDimensionsMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(PortConnDimensionsMismatch)
    PortDeclDimensionsMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(PortDeclDimensionsMismatch)
    PortDeclInANSIModule: typing.ClassVar[DiagCode]  # value = DiagCode(PortDeclInANSIModule)
    PortDoesNotExist: typing.ClassVar[DiagCode]  # value = DiagCode(PortDoesNotExist)
    PortExprMemberParent: typing.ClassVar[DiagCode]  # value = DiagCode(PortExprMemberParent)
    PortTypeNotInterfaceOrData: typing.ClassVar[DiagCode]  # value = DiagCode(PortTypeNotInterfaceOrData)
    PortWidthExpand: typing.ClassVar[DiagCode]  # value = DiagCode(PortWidthExpand)
    PortWidthTruncate: typing.ClassVar[DiagCode]  # value = DiagCode(PortWidthTruncate)
    PrimitiveAnsiMix: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitiveAnsiMix)
    PrimitiveDupInitial: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitiveDupInitial)
    PrimitiveDupOutput: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitiveDupOutput)
    PrimitiveInitVal: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitiveInitVal)
    PrimitiveInitialInComb: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitiveInitialInComb)
    PrimitiveOutputFirst: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitiveOutputFirst)
    PrimitivePortCountWrong: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitivePortCountWrong)
    PrimitivePortDup: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitivePortDup)
    PrimitivePortMissing: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitivePortMissing)
    PrimitivePortUnknown: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitivePortUnknown)
    PrimitiveRegDup: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitiveRegDup)
    PrimitiveRegInput: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitiveRegInput)
    PrimitiveTwoPorts: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitiveTwoPorts)
    PrimitiveWrongInitial: typing.ClassVar[DiagCode]  # value = DiagCode(PrimitiveWrongInitial)
    PropAbortLocalVar: typing.ClassVar[DiagCode]  # value = DiagCode(PropAbortLocalVar)
    PropAbortMatched: typing.ClassVar[DiagCode]  # value = DiagCode(PropAbortMatched)
    PropExprInSequence: typing.ClassVar[DiagCode]  # value = DiagCode(PropExprInSequence)
    PropInstanceRepetition: typing.ClassVar[DiagCode]  # value = DiagCode(PropInstanceRepetition)
    PropertyLhsInvalid: typing.ClassVar[DiagCode]  # value = DiagCode(PropertyLhsInvalid)
    PropertyPortInLet: typing.ClassVar[DiagCode]  # value = DiagCode(PropertyPortInLet)
    PropertyPortInSeq: typing.ClassVar[DiagCode]  # value = DiagCode(PropertyPortInSeq)
    ProtectArgList: typing.ClassVar[DiagCode]  # value = DiagCode(ProtectArgList)
    ProtectEncodingBytes: typing.ClassVar[DiagCode]  # value = DiagCode(ProtectEncodingBytes)
    ProtectedEnvelope: typing.ClassVar[DiagCode]  # value = DiagCode(ProtectedEnvelope)
    ProtectedMemberAccess: typing.ClassVar[DiagCode]  # value = DiagCode(ProtectedMemberAccess)
    PullStrengthHighZ: typing.ClassVar[DiagCode]  # value = DiagCode(PullStrengthHighZ)
    PulseControlPATHPULSE: typing.ClassVar[DiagCode]  # value = DiagCode(PulseControlPATHPULSE)
    PulseControlSpecifyParent: typing.ClassVar[DiagCode]  # value = DiagCode(PulseControlSpecifyParent)
    PureConstraintInAbstract: typing.ClassVar[DiagCode]  # value = DiagCode(PureConstraintInAbstract)
    PureInAbstract: typing.ClassVar[DiagCode]  # value = DiagCode(PureInAbstract)
    PureRequiresVirtual: typing.ClassVar[DiagCode]  # value = DiagCode(PureRequiresVirtual)
    QualifierConflict: typing.ClassVar[DiagCode]  # value = DiagCode(QualifierConflict)
    QualifierNotFirst: typing.ClassVar[DiagCode]  # value = DiagCode(QualifierNotFirst)
    QualifiersOnOutOfBlock: typing.ClassVar[DiagCode]  # value = DiagCode(QualifiersOnOutOfBlock)
    QueryOnAssociativeNonIntegral: typing.ClassVar[DiagCode]  # value = DiagCode(QueryOnAssociativeNonIntegral)
    QueryOnAssociativeWildcard: typing.ClassVar[DiagCode]  # value = DiagCode(QueryOnAssociativeWildcard)
    QueryOnDynamicType: typing.ClassVar[DiagCode]  # value = DiagCode(QueryOnDynamicType)
    RandCInDist: typing.ClassVar[DiagCode]  # value = DiagCode(RandCInDist)
    RandCInSoft: typing.ClassVar[DiagCode]  # value = DiagCode(RandCInSoft)
    RandCInSolveBefore: typing.ClassVar[DiagCode]  # value = DiagCode(RandCInSolveBefore)
    RandCInUnique: typing.ClassVar[DiagCode]  # value = DiagCode(RandCInUnique)
    RandJoinNotEnough: typing.ClassVar[DiagCode]  # value = DiagCode(RandJoinNotEnough)
    RandJoinNotNumeric: typing.ClassVar[DiagCode]  # value = DiagCode(RandJoinNotNumeric)
    RandJoinProdItem: typing.ClassVar[DiagCode]  # value = DiagCode(RandJoinProdItem)
    RandNeededInDist: typing.ClassVar[DiagCode]  # value = DiagCode(RandNeededInDist)
    RandOnPackedMember: typing.ClassVar[DiagCode]  # value = DiagCode(RandOnPackedMember)
    RandOnUnionMember: typing.ClassVar[DiagCode]  # value = DiagCode(RandOnUnionMember)
    RandomizeConstraintShadow: typing.ClassVar[DiagCode]  # value = DiagCode(RandomizeConstraintShadow)
    RangeOOB: typing.ClassVar[DiagCode]  # value = DiagCode(RangeOOB)
    RangeSelectAssociative: typing.ClassVar[DiagCode]  # value = DiagCode(RangeSelectAssociative)
    RangeSelectReversed: typing.ClassVar[DiagCode]  # value = DiagCode(RangeSelectReversed)
    RangeWidthOOB: typing.ClassVar[DiagCode]  # value = DiagCode(RangeWidthOOB)
    RangeWidthOverflow: typing.ClassVar[DiagCode]  # value = DiagCode(RangeWidthOverflow)
    RawProtectEOF: typing.ClassVar[DiagCode]  # value = DiagCode(RawProtectEOF)
    ReadWriteExpr: typing.ClassVar[DiagCode]  # value = DiagCode(ReadWriteExpr)
    RealCoverpointBins: typing.ClassVar[DiagCode]  # value = DiagCode(RealCoverpointBins)
    RealCoverpointDefaultArray: typing.ClassVar[DiagCode]  # value = DiagCode(RealCoverpointDefaultArray)
    RealCoverpointImplicit: typing.ClassVar[DiagCode]  # value = DiagCode(RealCoverpointImplicit)
    RealCoverpointTransBins: typing.ClassVar[DiagCode]  # value = DiagCode(RealCoverpointTransBins)
    RealCoverpointWildcardBins: typing.ClassVar[DiagCode]  # value = DiagCode(RealCoverpointWildcardBins)
    RealCoverpointWithExpr: typing.ClassVar[DiagCode]  # value = DiagCode(RealCoverpointWithExpr)
    RealLiteralOverflow: typing.ClassVar[DiagCode]  # value = DiagCode(RealLiteralOverflow)
    RealLiteralUnderflow: typing.ClassVar[DiagCode]  # value = DiagCode(RealLiteralUnderflow)
    RecursiveClassSpecialization: typing.ClassVar[DiagCode]  # value = DiagCode(RecursiveClassSpecialization)
    RecursiveDefinition: typing.ClassVar[DiagCode]  # value = DiagCode(RecursiveDefinition)
    RecursiveLet: typing.ClassVar[DiagCode]  # value = DiagCode(RecursiveLet)
    RecursiveMacro: typing.ClassVar[DiagCode]  # value = DiagCode(RecursiveMacro)
    RecursivePropArgExpr: typing.ClassVar[DiagCode]  # value = DiagCode(RecursivePropArgExpr)
    RecursivePropDisableIff: typing.ClassVar[DiagCode]  # value = DiagCode(RecursivePropDisableIff)
    RecursivePropNegation: typing.ClassVar[DiagCode]  # value = DiagCode(RecursivePropNegation)
    RecursivePropTimeAdvance: typing.ClassVar[DiagCode]  # value = DiagCode(RecursivePropTimeAdvance)
    RecursiveSequence: typing.ClassVar[DiagCode]  # value = DiagCode(RecursiveSequence)
    RedefiningMacro: typing.ClassVar[DiagCode]  # value = DiagCode(RedefiningMacro)
    Redefinition: typing.ClassVar[DiagCode]  # value = DiagCode(Redefinition)
    RedefinitionDifferentType: typing.ClassVar[DiagCode]  # value = DiagCode(RedefinitionDifferentType)
    RefArgAutomaticFunc: typing.ClassVar[DiagCode]  # value = DiagCode(RefArgAutomaticFunc)
    RefArgForkJoin: typing.ClassVar[DiagCode]  # value = DiagCode(RefArgForkJoin)
    RefPortMustBeVariable: typing.ClassVar[DiagCode]  # value = DiagCode(RefPortMustBeVariable)
    RefPortUnconnected: typing.ClassVar[DiagCode]  # value = DiagCode(RefPortUnconnected)
    RefPortUnnamedUnconnected: typing.ClassVar[DiagCode]  # value = DiagCode(RefPortUnnamedUnconnected)
    RefTypeMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(RefTypeMismatch)
    RegAfterNettype: typing.ClassVar[DiagCode]  # value = DiagCode(RegAfterNettype)
    RepeatControlNotEvent: typing.ClassVar[DiagCode]  # value = DiagCode(RepeatControlNotEvent)
    RepeatNotNumeric: typing.ClassVar[DiagCode]  # value = DiagCode(RepeatNotNumeric)
    ReplicationZeroOutsideConcat: typing.ClassVar[DiagCode]  # value = DiagCode(ReplicationZeroOutsideConcat)
    RestrictStmtNoFail: typing.ClassVar[DiagCode]  # value = DiagCode(RestrictStmtNoFail)
    ReturnInParallel: typing.ClassVar[DiagCode]  # value = DiagCode(ReturnInParallel)
    ReturnNotInSubroutine: typing.ClassVar[DiagCode]  # value = DiagCode(ReturnNotInSubroutine)
    ReversedValueRange: typing.ClassVar[DiagCode]  # value = DiagCode(ReversedValueRange)
    SampledValueFuncClock: typing.ClassVar[DiagCode]  # value = DiagCode(SampledValueFuncClock)
    SampledValueLocalVar: typing.ClassVar[DiagCode]  # value = DiagCode(SampledValueLocalVar)
    SampledValueMatched: typing.ClassVar[DiagCode]  # value = DiagCode(SampledValueMatched)
    ScopeIncompleteTypedef: typing.ClassVar[DiagCode]  # value = DiagCode(ScopeIncompleteTypedef)
    ScopeIndexOutOfRange: typing.ClassVar[DiagCode]  # value = DiagCode(ScopeIndexOutOfRange)
    ScopeNotIndexable: typing.ClassVar[DiagCode]  # value = DiagCode(ScopeNotIndexable)
    ScopedClassCopy: typing.ClassVar[DiagCode]  # value = DiagCode(ScopedClassCopy)
    SelectAfterRangeSelect: typing.ClassVar[DiagCode]  # value = DiagCode(SelectAfterRangeSelect)
    SelectOfVectoredNet: typing.ClassVar[DiagCode]  # value = DiagCode(SelectOfVectoredNet)
    SeqEmptyMatch: typing.ClassVar[DiagCode]  # value = DiagCode(SeqEmptyMatch)
    SeqInstanceRepetition: typing.ClassVar[DiagCode]  # value = DiagCode(SeqInstanceRepetition)
    SeqMethodEndClock: typing.ClassVar[DiagCode]  # value = DiagCode(SeqMethodEndClock)
    SeqMethodInputLocalVar: typing.ClassVar[DiagCode]  # value = DiagCode(SeqMethodInputLocalVar)
    SeqNoMatch: typing.ClassVar[DiagCode]  # value = DiagCode(SeqNoMatch)
    SeqOnlyEmpty: typing.ClassVar[DiagCode]  # value = DiagCode(SeqOnlyEmpty)
    SeqRangeMinMax: typing.ClassVar[DiagCode]  # value = DiagCode(SeqRangeMinMax)
    SequenceMatchedOutsideAssertion: typing.ClassVar[DiagCode]  # value = DiagCode(SequenceMatchedOutsideAssertion)
    SequenceMethodLocalVar: typing.ClassVar[DiagCode]  # value = DiagCode(SequenceMethodLocalVar)
    ShadowHierarchy: typing.ClassVar[DiagCode]  # value = DiagCode(ShadowHierarchy)
    ShadowProperty: typing.ClassVar[DiagCode]  # value = DiagCode(ShadowProperty)
    ShadowValue: typing.ClassVar[DiagCode]  # value = DiagCode(ShadowValue)
    ShiftCountNegative: typing.ClassVar[DiagCode]  # value = DiagCode(ShiftCountNegative)
    ShiftCountOverflow: typing.ClassVar[DiagCode]  # value = DiagCode(ShiftCountOverflow)
    SignCompare: typing.ClassVar[DiagCode]  # value = DiagCode(SignCompare)
    SignConversion: typing.ClassVar[DiagCode]  # value = DiagCode(SignConversion)
    SignedIntegerOverflow: typing.ClassVar[DiagCode]  # value = DiagCode(SignedIntegerOverflow)
    SignedLogicalShift: typing.ClassVar[DiagCode]  # value = DiagCode(SignedLogicalShift)
    SignednessNoEffect: typing.ClassVar[DiagCode]  # value = DiagCode(SignednessNoEffect)
    SingleBitVectored: typing.ClassVar[DiagCode]  # value = DiagCode(SingleBitVectored)
    SolveBeforeDisallowed: typing.ClassVar[DiagCode]  # value = DiagCode(SolveBeforeDisallowed)
    SpecifiersNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(SpecifiersNotAllowed)
    SpecifyBlockParam: typing.ClassVar[DiagCode]  # value = DiagCode(SpecifyBlockParam)
    SpecifyPathBadReference: typing.ClassVar[DiagCode]  # value = DiagCode(SpecifyPathBadReference)
    SpecifyPathConditionExpr: typing.ClassVar[DiagCode]  # value = DiagCode(SpecifyPathConditionExpr)
    SpecifyPathMultiDim: typing.ClassVar[DiagCode]  # value = DiagCode(SpecifyPathMultiDim)
    SpecparamInConstant: typing.ClassVar[DiagCode]  # value = DiagCode(SpecparamInConstant)
    SplitDistWeightOp: typing.ClassVar[DiagCode]  # value = DiagCode(SplitDistWeightOp)
    StatementNotInLoop: typing.ClassVar[DiagCode]  # value = DiagCode(StatementNotInLoop)
    StaticAssert: typing.ClassVar[DiagCode]  # value = DiagCode(StaticAssert)
    StaticConstNoInitializer: typing.ClassVar[DiagCode]  # value = DiagCode(StaticConstNoInitializer)
    StaticFuncSpecifier: typing.ClassVar[DiagCode]  # value = DiagCode(StaticFuncSpecifier)
    StaticInitOrder: typing.ClassVar[DiagCode]  # value = DiagCode(StaticInitOrder)
    StaticInitValue: typing.ClassVar[DiagCode]  # value = DiagCode(StaticInitValue)
    StaticInitializerMustBeExplicit: typing.ClassVar[DiagCode]  # value = DiagCode(StaticInitializerMustBeExplicit)
    StringConstraintExpr: typing.ClassVar[DiagCode]  # value = DiagCode(StringConstraintExpr)
    SubroutineMatchAutoRefArg: typing.ClassVar[DiagCode]  # value = DiagCode(SubroutineMatchAutoRefArg)
    SubroutineMatchNonVoid: typing.ClassVar[DiagCode]  # value = DiagCode(SubroutineMatchNonVoid)
    SubroutineMatchOutArg: typing.ClassVar[DiagCode]  # value = DiagCode(SubroutineMatchOutArg)
    SubroutinePortInitializer: typing.ClassVar[DiagCode]  # value = DiagCode(SubroutinePortInitializer)
    SubroutinePrototypeScoped: typing.ClassVar[DiagCode]  # value = DiagCode(SubroutinePrototypeScoped)
    SuperNoBase: typing.ClassVar[DiagCode]  # value = DiagCode(SuperNoBase)
    SuperOutsideClass: typing.ClassVar[DiagCode]  # value = DiagCode(SuperOutsideClass)
    SysFuncHierarchicalNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(SysFuncHierarchicalNotAllowed)
    SysFuncNotConst: typing.ClassVar[DiagCode]  # value = DiagCode(SysFuncNotConst)
    TaggedStruct: typing.ClassVar[DiagCode]  # value = DiagCode(TaggedStruct)
    TaggedUnionMissingInit: typing.ClassVar[DiagCode]  # value = DiagCode(TaggedUnionMissingInit)
    TaggedUnionTarget: typing.ClassVar[DiagCode]  # value = DiagCode(TaggedUnionTarget)
    TaskConstructor: typing.ClassVar[DiagCode]  # value = DiagCode(TaskConstructor)
    TaskFromFinal: typing.ClassVar[DiagCode]  # value = DiagCode(TaskFromFinal)
    TaskFromFunction: typing.ClassVar[DiagCode]  # value = DiagCode(TaskFromFunction)
    TaskInConstraint: typing.ClassVar[DiagCode]  # value = DiagCode(TaskInConstraint)
    TaskReturnType: typing.ClassVar[DiagCode]  # value = DiagCode(TaskReturnType)
    ThroughoutLhsInvalid: typing.ClassVar[DiagCode]  # value = DiagCode(ThroughoutLhsInvalid)
    TimeScaleFirstInScope: typing.ClassVar[DiagCode]  # value = DiagCode(TimeScaleFirstInScope)
    TimingCheckEventEdgeRequired: typing.ClassVar[DiagCode]  # value = DiagCode(TimingCheckEventEdgeRequired)
    TimingCheckEventNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(TimingCheckEventNotAllowed)
    TimingControlNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(TimingControlNotAllowed)
    TimingInFuncNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(TimingInFuncNotAllowed)
    TooFewArguments: typing.ClassVar[DiagCode]  # value = DiagCode(TooFewArguments)
    TooManyActualMacroArgs: typing.ClassVar[DiagCode]  # value = DiagCode(TooManyActualMacroArgs)
    TooManyArguments: typing.ClassVar[DiagCode]  # value = DiagCode(TooManyArguments)
    TooManyEdgeDescriptors: typing.ClassVar[DiagCode]  # value = DiagCode(TooManyEdgeDescriptors)
    TooManyErrors: typing.ClassVar[DiagCode]  # value = DiagCode(TooManyErrors)
    TooManyForeachVars: typing.ClassVar[DiagCode]  # value = DiagCode(TooManyForeachVars)
    TooManyLexerErrors: typing.ClassVar[DiagCode]  # value = DiagCode(TooManyLexerErrors)
    TooManyParamAssignments: typing.ClassVar[DiagCode]  # value = DiagCode(TooManyParamAssignments)
    TooManyPortConnections: typing.ClassVar[DiagCode]  # value = DiagCode(TooManyPortConnections)
    TopModuleIfacePort: typing.ClassVar[DiagCode]  # value = DiagCode(TopModuleIfacePort)
    TopModuleRefPort: typing.ClassVar[DiagCode]  # value = DiagCode(TopModuleRefPort)
    TopModuleUnnamedRefPort: typing.ClassVar[DiagCode]  # value = DiagCode(TopModuleUnnamedRefPort)
    TypeHierarchical: typing.ClassVar[DiagCode]  # value = DiagCode(TypeHierarchical)
    TypeIsNotAClass: typing.ClassVar[DiagCode]  # value = DiagCode(TypeIsNotAClass)
    TypeRefDeclVar: typing.ClassVar[DiagCode]  # value = DiagCode(TypeRefDeclVar)
    TypeRefHierarchical: typing.ClassVar[DiagCode]  # value = DiagCode(TypeRefHierarchical)
    TypeRefVoid: typing.ClassVar[DiagCode]  # value = DiagCode(TypeRefVoid)
    TypeRestrictionMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(TypeRestrictionMismatch)
    TypoIdentifier: typing.ClassVar[DiagCode]  # value = DiagCode(TypoIdentifier)
    TypoKeyword: typing.ClassVar[DiagCode]  # value = DiagCode(TypoKeyword)
    UTF8Char: typing.ClassVar[DiagCode]  # value = DiagCode(UTF8Char)
    UdpAllX: typing.ClassVar[DiagCode]  # value = DiagCode(UdpAllX)
    UdpCombState: typing.ClassVar[DiagCode]  # value = DiagCode(UdpCombState)
    UdpCoverage: typing.ClassVar[DiagCode]  # value = DiagCode(UdpCoverage)
    UdpDupDiffOutput: typing.ClassVar[DiagCode]  # value = DiagCode(UdpDupDiffOutput)
    UdpDupTransition: typing.ClassVar[DiagCode]  # value = DiagCode(UdpDupTransition)
    UdpEdgeInComb: typing.ClassVar[DiagCode]  # value = DiagCode(UdpEdgeInComb)
    UdpInvalidEdgeSymbol: typing.ClassVar[DiagCode]  # value = DiagCode(UdpInvalidEdgeSymbol)
    UdpInvalidInputOnly: typing.ClassVar[DiagCode]  # value = DiagCode(UdpInvalidInputOnly)
    UdpInvalidMinus: typing.ClassVar[DiagCode]  # value = DiagCode(UdpInvalidMinus)
    UdpInvalidOutput: typing.ClassVar[DiagCode]  # value = DiagCode(UdpInvalidOutput)
    UdpInvalidSymbol: typing.ClassVar[DiagCode]  # value = DiagCode(UdpInvalidSymbol)
    UdpInvalidTransition: typing.ClassVar[DiagCode]  # value = DiagCode(UdpInvalidTransition)
    UdpSequentialState: typing.ClassVar[DiagCode]  # value = DiagCode(UdpSequentialState)
    UdpSingleChar: typing.ClassVar[DiagCode]  # value = DiagCode(UdpSingleChar)
    UdpTransSameChar: typing.ClassVar[DiagCode]  # value = DiagCode(UdpTransSameChar)
    UdpTransitionLength: typing.ClassVar[DiagCode]  # value = DiagCode(UdpTransitionLength)
    UdpWrongInputCount: typing.ClassVar[DiagCode]  # value = DiagCode(UdpWrongInputCount)
    UnassignedLocalProperty: typing.ClassVar[DiagCode]  # value = DiagCode(UnassignedLocalProperty)
    UnassignedProperty: typing.ClassVar[DiagCode]  # value = DiagCode(UnassignedProperty)
    UnassignedVariable: typing.ClassVar[DiagCode]  # value = DiagCode(UnassignedVariable)
    UnbalancedMacroArgDims: typing.ClassVar[DiagCode]  # value = DiagCode(UnbalancedMacroArgDims)
    UnboundedNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(UnboundedNotAllowed)
    UnclosedTranslateOff: typing.ClassVar[DiagCode]  # value = DiagCode(UnclosedTranslateOff)
    UnconnectedArg: typing.ClassVar[DiagCode]  # value = DiagCode(UnconnectedArg)
    UnconnectedInOutPort: typing.ClassVar[DiagCode]  # value = DiagCode(UnconnectedInOutPort)
    UnconnectedInputPort: typing.ClassVar[DiagCode]  # value = DiagCode(UnconnectedInputPort)
    UnconnectedOutputPort: typing.ClassVar[DiagCode]  # value = DiagCode(UnconnectedOutputPort)
    UnconnectedUnnamedPort: typing.ClassVar[DiagCode]  # value = DiagCode(UnconnectedUnnamedPort)
    UndeclaredButFoundPackage: typing.ClassVar[DiagCode]  # value = DiagCode(UndeclaredButFoundPackage)
    UndeclaredIdentifier: typing.ClassVar[DiagCode]  # value = DiagCode(UndeclaredIdentifier)
    UndefineBuiltinDirective: typing.ClassVar[DiagCode]  # value = DiagCode(UndefineBuiltinDirective)
    UndrivenNet: typing.ClassVar[DiagCode]  # value = DiagCode(UndrivenNet)
    UndrivenPort: typing.ClassVar[DiagCode]  # value = DiagCode(UndrivenPort)
    UnexpectedClockingExpr: typing.ClassVar[DiagCode]  # value = DiagCode(UnexpectedClockingExpr)
    UnexpectedConditionalDirective: typing.ClassVar[DiagCode]  # value = DiagCode(UnexpectedConditionalDirective)
    UnexpectedConstraintBlock: typing.ClassVar[DiagCode]  # value = DiagCode(UnexpectedConstraintBlock)
    UnexpectedEndDelim: typing.ClassVar[DiagCode]  # value = DiagCode(UnexpectedEndDelim)
    UnexpectedLetPortKeyword: typing.ClassVar[DiagCode]  # value = DiagCode(UnexpectedLetPortKeyword)
    UnexpectedNameToken: typing.ClassVar[DiagCode]  # value = DiagCode(UnexpectedNameToken)
    UnexpectedPortDecl: typing.ClassVar[DiagCode]  # value = DiagCode(UnexpectedPortDecl)
    UnexpectedQualifiers: typing.ClassVar[DiagCode]  # value = DiagCode(UnexpectedQualifiers)
    UnexpectedSelection: typing.ClassVar[DiagCode]  # value = DiagCode(UnexpectedSelection)
    UnexpectedWithClause: typing.ClassVar[DiagCode]  # value = DiagCode(UnexpectedWithClause)
    UnicodeBOM: typing.ClassVar[DiagCode]  # value = DiagCode(UnicodeBOM)
    UniquePriorityAfterElse: typing.ClassVar[DiagCode]  # value = DiagCode(UniquePriorityAfterElse)
    UnknownClassMember: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownClassMember)
    UnknownClassOrPackage: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownClassOrPackage)
    UnknownConstraintLiteral: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownConstraintLiteral)
    UnknownCovergroupBase: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownCovergroupBase)
    UnknownCovergroupMember: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownCovergroupMember)
    UnknownDiagPragmaArg: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownDiagPragmaArg)
    UnknownDirective: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownDirective)
    UnknownEscapeCode: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownEscapeCode)
    UnknownFormatSpecifier: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownFormatSpecifier)
    UnknownInterface: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownInterface)
    UnknownLibrary: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownLibrary)
    UnknownMember: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownMember)
    UnknownModule: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownModule)
    UnknownPackage: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownPackage)
    UnknownPackageMember: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownPackageMember)
    UnknownPragma: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownPragma)
    UnknownPrimitive: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownPrimitive)
    UnknownProtectEncoding: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownProtectEncoding)
    UnknownProtectKeyword: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownProtectKeyword)
    UnknownProtectOption: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownProtectOption)
    UnknownSystemMethod: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownSystemMethod)
    UnknownSystemName: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownSystemName)
    UnknownSystemTimingCheck: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownSystemTimingCheck)
    UnknownWarningOption: typing.ClassVar[DiagCode]  # value = DiagCode(UnknownWarningOption)
    UnnamedGenerate: typing.ClassVar[DiagCode]  # value = DiagCode(UnnamedGenerate)
    UnnamedGenerateReference: typing.ClassVar[DiagCode]  # value = DiagCode(UnnamedGenerateReference)
    UnpackedArrayParamType: typing.ClassVar[DiagCode]  # value = DiagCode(UnpackedArrayParamType)
    UnpackedConcatAssociative: typing.ClassVar[DiagCode]  # value = DiagCode(UnpackedConcatAssociative)
    UnpackedConcatSize: typing.ClassVar[DiagCode]  # value = DiagCode(UnpackedConcatSize)
    UnpackedSigned: typing.ClassVar[DiagCode]  # value = DiagCode(UnpackedSigned)
    UnrecognizedKeywordVersion: typing.ClassVar[DiagCode]  # value = DiagCode(UnrecognizedKeywordVersion)
    UnresolvedForwardTypedef: typing.ClassVar[DiagCode]  # value = DiagCode(UnresolvedForwardTypedef)
    UnsignedArithShift: typing.ClassVar[DiagCode]  # value = DiagCode(UnsignedArithShift)
    UnsizedInConcat: typing.ClassVar[DiagCode]  # value = DiagCode(UnsizedInConcat)
    UnterminatedBlockComment: typing.ClassVar[DiagCode]  # value = DiagCode(UnterminatedBlockComment)
    UnusedArgument: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedArgument)
    UnusedAssertionDecl: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedAssertionDecl)
    UnusedButSetLocalProperty: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedButSetLocalProperty)
    UnusedButSetNet: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedButSetNet)
    UnusedButSetPort: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedButSetPort)
    UnusedButSetProperty: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedButSetProperty)
    UnusedButSetVariable: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedButSetVariable)
    UnusedClassMethod: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedClassMethod)
    UnusedClassProperty: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedClassProperty)
    UnusedConfigCell: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedConfigCell)
    UnusedConfigInstance: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedConfigInstance)
    UnusedConstructor: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedConstructor)
    UnusedDPIImport: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedDPIImport)
    UnusedDefinition: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedDefinition)
    UnusedGenvar: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedGenvar)
    UnusedImplicitNet: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedImplicitNet)
    UnusedImport: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedImport)
    UnusedLocalClassMethod: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedLocalClassMethod)
    UnusedLocalClassProperty: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedLocalClassProperty)
    UnusedNet: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedNet)
    UnusedPackageAssertionDecl: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedPackageAssertionDecl)
    UnusedPackageParameter: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedPackageParameter)
    UnusedPackageSubroutine: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedPackageSubroutine)
    UnusedPackageTypeParameter: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedPackageTypeParameter)
    UnusedPackageTypedef: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedPackageTypedef)
    UnusedPackageVar: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedPackageVar)
    UnusedParameter: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedParameter)
    UnusedPort: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedPort)
    UnusedPortDecl: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedPortDecl)
    UnusedResult: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedResult)
    UnusedSubroutine: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedSubroutine)
    UnusedTypeParameter: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedTypeParameter)
    UnusedTypedef: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedTypedef)
    UnusedVariable: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedVariable)
    UnusedWildcardImport: typing.ClassVar[DiagCode]  # value = DiagCode(UnusedWildcardImport)
    UpwardHierarchicalName: typing.ClassVar[DiagCode]  # value = DiagCode(UpwardHierarchicalName)
    UsedBeforeDeclared: typing.ClassVar[DiagCode]  # value = DiagCode(UsedBeforeDeclared)
    UselessCast: typing.ClassVar[DiagCode]  # value = DiagCode(UselessCast)
    UserDefPartialDriver: typing.ClassVar[DiagCode]  # value = DiagCode(UserDefPartialDriver)
    UserDefPortMixedConcat: typing.ClassVar[DiagCode]  # value = DiagCode(UserDefPortMixedConcat)
    UserDefPortTwoSided: typing.ClassVar[DiagCode]  # value = DiagCode(UserDefPortTwoSided)
    VacuousCover: typing.ClassVar[DiagCode]  # value = DiagCode(VacuousCover)
    ValueExceedsMaxBitWidth: typing.ClassVar[DiagCode]  # value = DiagCode(ValueExceedsMaxBitWidth)
    ValueMustBeIntegral: typing.ClassVar[DiagCode]  # value = DiagCode(ValueMustBeIntegral)
    ValueMustBePositive: typing.ClassVar[DiagCode]  # value = DiagCode(ValueMustBePositive)
    ValueMustNotBeUnknown: typing.ClassVar[DiagCode]  # value = DiagCode(ValueMustNotBeUnknown)
    ValueOutOfRange: typing.ClassVar[DiagCode]  # value = DiagCode(ValueOutOfRange)
    ValueRangeUnbounded: typing.ClassVar[DiagCode]  # value = DiagCode(ValueRangeUnbounded)
    VarDeclWithDelay: typing.ClassVar[DiagCode]  # value = DiagCode(VarDeclWithDelay)
    VarWithInterfacePort: typing.ClassVar[DiagCode]  # value = DiagCode(VarWithInterfacePort)
    VectorLiteralOverflow: typing.ClassVar[DiagCode]  # value = DiagCode(VectorLiteralOverflow)
    VirtualArgCountMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualArgCountMismatch)
    VirtualArgDirectionMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualArgDirectionMismatch)
    VirtualArgNameMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualArgNameMismatch)
    VirtualArgNoDerivedDefault: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualArgNoDerivedDefault)
    VirtualArgNoParentDefault: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualArgNoParentDefault)
    VirtualArgTypeMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualArgTypeMismatch)
    VirtualIfaceConfigRule: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualIfaceConfigRule)
    VirtualIfaceDefparam: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualIfaceDefparam)
    VirtualIfaceHierRef: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualIfaceHierRef)
    VirtualIfaceIfacePort: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualIfaceIfacePort)
    VirtualInterfaceIfaceMember: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualInterfaceIfaceMember)
    VirtualInterfaceUnionMember: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualInterfaceUnionMember)
    VirtualKindMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualKindMismatch)
    VirtualReturnMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualReturnMismatch)
    VirtualVisibilityMismatch: typing.ClassVar[DiagCode]  # value = DiagCode(VirtualVisibilityMismatch)
    VoidAssignment: typing.ClassVar[DiagCode]  # value = DiagCode(VoidAssignment)
    VoidCastFuncCall: typing.ClassVar[DiagCode]  # value = DiagCode(VoidCastFuncCall)
    VoidNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(VoidNotAllowed)
    WarnUnknownLibrary: typing.ClassVar[DiagCode]  # value = DiagCode(WarnUnknownLibrary)
    WarningTask: typing.ClassVar[DiagCode]  # value = DiagCode(WarningTask)
    WidthExpand: typing.ClassVar[DiagCode]  # value = DiagCode(WidthExpand)
    WidthTruncate: typing.ClassVar[DiagCode]  # value = DiagCode(WidthTruncate)
    WildcardPortGenericIface: typing.ClassVar[DiagCode]  # value = DiagCode(WildcardPortGenericIface)
    WireDataType: typing.ClassVar[DiagCode]  # value = DiagCode(WireDataType)
    WithClauseNotAllowed: typing.ClassVar[DiagCode]  # value = DiagCode(WithClauseNotAllowed)
    WriteToInputClockVar: typing.ClassVar[DiagCode]  # value = DiagCode(WriteToInputClockVar)
    WrongBindTargetDef: typing.ClassVar[DiagCode]  # value = DiagCode(WrongBindTargetDef)
    WrongLanguageVersion: typing.ClassVar[DiagCode]  # value = DiagCode(WrongLanguageVersion)
    WrongNumberAssignmentPatterns: typing.ClassVar[DiagCode]  # value = DiagCode(WrongNumberAssignmentPatterns)
    WrongSpecifyDelayCount: typing.ClassVar[DiagCode]  # value = DiagCode(WrongSpecifyDelayCount)
class LanguageVersion(enum.Enum):
    v1364_2005: typing.ClassVar[LanguageVersion]  # value = <LanguageVersion.v1364_2005: 0>
    v1800_2017: typing.ClassVar[LanguageVersion]  # value = <LanguageVersion.v1800_2017: 1>
    v1800_2023: typing.ClassVar[LanguageVersion]  # value = <LanguageVersion.v1800_2023: 2>
class LiteralBase(enum.Enum):
    Binary: typing.ClassVar[LiteralBase]  # value = <LiteralBase.Binary: 0>
    Decimal: typing.ClassVar[LiteralBase]  # value = <LiteralBase.Decimal: 2>
    Hex: typing.ClassVar[LiteralBase]  # value = <LiteralBase.Hex: 3>
    Octal: typing.ClassVar[LiteralBase]  # value = <LiteralBase.Octal: 1>
class Null:
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
class PreprocessOutputFlags(enum.Flag):
    IncludeComments: typing.ClassVar[PreprocessOutputFlags]  # value = <PreprocessOutputFlags.IncludeComments: 1>
    IncludeDirectives: typing.ClassVar[PreprocessOutputFlags]  # value = <PreprocessOutputFlags.IncludeDirectives: 2>
    IncludeSourceInfo: typing.ClassVar[PreprocessOutputFlags]  # value = <PreprocessOutputFlags.IncludeSourceInfo: 16>
    ObfuscateIds: typing.ClassVar[PreprocessOutputFlags]  # value = <PreprocessOutputFlags.ObfuscateIds: 4>
    UseFixedObfuscationSeed: typing.ClassVar[PreprocessOutputFlags]  # value = <PreprocessOutputFlags.UseFixedObfuscationSeed: 8>
class ReportedDiagnostic:
    @property
    def expansionLocs(self) -> span[...]:
        ...
    @property
    def formattedMessage(self) -> str:
        ...
    @property
    def location(self) -> ...:
        ...
    @property
    def originalDiagnostic(self) -> Diagnostic:
        ...
    @property
    def ranges(self) -> span[...]:
        ...
    @property
    def severity(self) -> DiagnosticSeverity:
        ...
    @property
    def shouldShowIncludeStack(self) -> bool:
        ...
class SVInt:
    @staticmethod
    def concat(arg0: span[SVInt]) -> SVInt:
        ...
    @staticmethod
    def conditional(condition: SVInt, lhs: SVInt, rhs: SVInt) -> SVInt:
        ...
    @staticmethod
    def createFillX(bitWidth: typing.SupportsInt | typing.SupportsIndex, isSigned: bool) -> SVInt:
        ...
    @staticmethod
    def createFillZ(bitWidth: typing.SupportsInt | typing.SupportsIndex, isSigned: bool) -> SVInt:
        ...
    @staticmethod
    def fromDigits(bits: typing.SupportsInt | typing.SupportsIndex, base: LiteralBase, isSigned: bool, anyUnknown: bool, digits: span[logic_t]) -> SVInt:
        ...
    @staticmethod
    def fromDouble(bits: typing.SupportsInt | typing.SupportsIndex, value: typing.SupportsFloat | typing.SupportsIndex, isSigned: bool, round: bool = True) -> SVInt:
        ...
    @staticmethod
    def fromFloat(bits: typing.SupportsInt | typing.SupportsIndex, value: typing.SupportsFloat | typing.SupportsIndex, isSigned: bool, round: bool = True) -> SVInt:
        ...
    @staticmethod
    def logicalEquiv(lhs: SVInt, rhs: SVInt) -> logic_t:
        ...
    @staticmethod
    def logicalImpl(lhs: SVInt, rhs: SVInt) -> logic_t:
        ...
    @typing.overload
    def __add__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __add__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __and__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __and__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def __bool__(self) -> bool:
        ...
    @typing.overload
    def __eq__(self, arg0: SVInt) -> logic_t:
        ...
    @typing.overload
    def __eq__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> logic_t:
        ...
    def __float__(self) -> float:
        ...
    @typing.overload
    def __ge__(self, arg0: SVInt) -> logic_t:
        ...
    @typing.overload
    def __ge__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> logic_t:
        ...
    def __getitem__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> logic_t:
        ...
    @typing.overload
    def __gt__(self, arg0: SVInt) -> logic_t:
        ...
    @typing.overload
    def __gt__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> logic_t:
        ...
    def __hash__(self) -> int:
        ...
    @typing.overload
    def __iadd__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __iadd__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __iand__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __iand__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __imod__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __imod__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __imul__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __imul__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, bit: logic_t) -> None:
        ...
    @typing.overload
    def __init__(self, bits: typing.SupportsInt | typing.SupportsIndex, value: typing.SupportsInt | typing.SupportsIndex, isSigned: bool) -> None:
        ...
    @typing.overload
    def __init__(self, bits: typing.SupportsInt | typing.SupportsIndex, bytes: span[...], isSigned: bool) -> None:
        ...
    @typing.overload
    def __init__(self, str: str) -> None:
        ...
    @typing.overload
    def __init__(self, value: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @typing.overload
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __invert__(self) -> SVInt:
        ...
    @typing.overload
    def __ior__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __ior__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __isub__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __isub__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __itruediv__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __itruediv__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __ixor__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __ixor__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __le__(self, arg0: SVInt) -> logic_t:
        ...
    @typing.overload
    def __le__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> logic_t:
        ...
    @typing.overload
    def __lt__(self, arg0: SVInt) -> logic_t:
        ...
    @typing.overload
    def __lt__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> logic_t:
        ...
    @typing.overload
    def __mod__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __mod__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __mul__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __mul__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __ne__(self, arg0: SVInt) -> logic_t:
        ...
    @typing.overload
    def __ne__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> logic_t:
        ...
    def __neg__(self) -> SVInt:
        ...
    @typing.overload
    def __or__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __or__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def __pow__(self, arg0: SVInt) -> SVInt:
        ...
    def __radd__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def __rand__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def __rdiv__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def __repr__(self) -> str:
        ...
    def __rmod__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def __rmul__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def __ror__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def __rsub__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def __rxor__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __sub__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __sub__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __truediv__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __truediv__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @typing.overload
    def __xor__(self, arg0: SVInt) -> SVInt:
        ...
    @typing.overload
    def __xor__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def ashr(self, rhs: SVInt) -> SVInt:
        ...
    def countLeadingOnes(self) -> int:
        ...
    def countLeadingUnknowns(self) -> int:
        ...
    def countLeadingZeros(self) -> int:
        ...
    def countLeadingZs(self) -> int:
        ...
    def countOnes(self) -> int:
        ...
    def countXs(self) -> int:
        ...
    def countZeros(self) -> int:
        ...
    def countZs(self) -> int:
        ...
    def extend(self, bits: typing.SupportsInt | typing.SupportsIndex, isSigned: bool) -> SVInt:
        ...
    def flattenUnknowns(self) -> None:
        ...
    def getActiveBits(self) -> int:
        ...
    def getMinRepresentedBits(self) -> int:
        ...
    def isEven(self) -> bool:
        ...
    def isNegative(self) -> bool:
        ...
    def isOdd(self) -> bool:
        ...
    def isSignExtendedFrom(self, msb: typing.SupportsInt | typing.SupportsIndex) -> bool:
        ...
    def lshr(self, rhs: SVInt) -> SVInt:
        ...
    def reductionAnd(self) -> logic_t:
        ...
    def reductionOr(self) -> logic_t:
        ...
    def reductionXor(self) -> logic_t:
        ...
    def replicate(self, times: SVInt) -> SVInt:
        ...
    def resize(self, bits: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def reverse(self) -> SVInt:
        ...
    def set(self, msb: typing.SupportsInt | typing.SupportsIndex, lsb: typing.SupportsInt | typing.SupportsIndex, value: SVInt) -> None:
        ...
    def setAllOnes(self) -> None:
        ...
    def setAllX(self) -> None:
        ...
    def setAllZ(self) -> None:
        ...
    def setAllZeros(self) -> None:
        ...
    def setSigned(self, isSigned: bool) -> None:
        ...
    def sext(self, bits: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def shl(self, rhs: SVInt) -> SVInt:
        ...
    def shrinkToFit(self) -> None:
        ...
    def signExtendFrom(self, msb: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def slice(self, msb: typing.SupportsInt | typing.SupportsIndex, lsb: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def toString(self, base: LiteralBase, includeBase: bool, abbreviateThresholdBits: typing.SupportsInt | typing.SupportsIndex = 16777215) -> str:
        ...
    def trunc(self, bits: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    def xnor(self, rhs: SVInt) -> SVInt:
        ...
    def zext(self, bits: typing.SupportsInt | typing.SupportsIndex) -> SVInt:
        ...
    @property
    def bitWidth(self) -> int:
        ...
    @property
    def hasUnknown(self) -> bool:
        ...
    @property
    def isSigned(self) -> bool:
        ...
class SourceBuffer:
    def __bool__(self) -> bool:
        ...
    def __init__(self) -> None:
        ...
    @property
    def data(self) -> str:
        ...
    @property
    def id(self) -> BufferID:
        ...
    @property
    def library(self) -> SourceLibrary:
        ...
class SourceLibrary:
    def __init__(self) -> None:
        ...
    @property
    def name(self) -> str:
        ...
class SourceLocation:
    NoLocation: typing.ClassVar[SourceLocation]  # value = SourceLocation(268435455, 68719476735)
    def __bool__(self) -> bool:
        ...
    def __eq__(self, arg0: SourceLocation) -> bool:
        ...
    def __ge__(self, arg0: SourceLocation) -> bool:
        ...
    def __gt__(self, arg0: SourceLocation) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, buffer: BufferID, offset: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __le__(self, arg0: SourceLocation) -> bool:
        ...
    def __lt__(self, arg0: SourceLocation) -> bool:
        ...
    def __ne__(self, arg0: SourceLocation) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def buffer(self) -> BufferID:
        ...
    @property
    def offset(self) -> int:
        ...
class SourceManager:
    def __init__(self) -> None:
        ...
    def addDiagnosticDirective(self, location: SourceLocation, name: str, severity: DiagnosticSeverity) -> None:
        ...
    def addLineDirective(self, location: SourceLocation, lineNum: typing.SupportsInt | typing.SupportsIndex, name: str, level: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def addSystemDirectories(self, path: str) -> None:
        ...
    def addUserDirectories(self, path: str) -> None:
        ...
    @typing.overload
    def assignText(self, text: str, includedFrom: SourceLocation = ..., library: SourceLibrary = None) -> SourceBuffer:
        ...
    @typing.overload
    def assignText(self, path: str, text: str, includedFrom: SourceLocation = ..., library: SourceLibrary = None) -> SourceBuffer:
        ...
    def getAllBuffers(self) -> list[BufferID]:
        ...
    def getBufferKind(self, buffer: BufferID) -> BufferKind:
        ...
    def getColumnNumber(self, location: SourceLocation) -> int:
        ...
    def getDisplayColumnNumber(self, location: SourceLocation) -> int:
        ...
    def getExpansionLoc(self, location: SourceLocation) -> SourceLocation:
        ...
    def getExpansionRange(self, location: SourceLocation) -> SourceRange:
        ...
    def getFileName(self, location: SourceLocation) -> str:
        ...
    def getFullPath(self, buffer: BufferID) -> pathlib.Path:
        ...
    def getFullyExpandedLoc(self, location: SourceLocation) -> SourceLocation:
        ...
    def getFullyOriginalLoc(self, location: SourceLocation) -> SourceLocation:
        ...
    def getFullyOriginalRange(self, range: SourceRange) -> SourceRange:
        ...
    def getIncludedFrom(self, buffer: BufferID) -> SourceLocation:
        ...
    def getLineNumber(self, location: SourceLocation) -> int:
        ...
    def getMacroName(self, location: SourceLocation) -> str:
        ...
    def getOriginalLoc(self, location: SourceLocation) -> SourceLocation:
        ...
    def getRawFileName(self, buffer: BufferID) -> str:
        ...
    def getSourceText(self, buffer: BufferID) -> str:
        ...
    def isBeforeInCompilationUnit(self, left: SourceLocation, right: SourceLocation) -> bool | None:
        ...
    def isCached(self, path: os.PathLike | str | bytes) -> bool:
        ...
    def isFileLoc(self, location: SourceLocation) -> bool:
        ...
    def isIncludedFileLoc(self, location: SourceLocation) -> bool:
        ...
    def isMacroArgLoc(self, location: SourceLocation) -> bool:
        ...
    def isMacroLoc(self, location: SourceLocation) -> bool:
        ...
    def isPreprocessedLoc(self, location: SourceLocation) -> bool:
        ...
    def readHeader(self, path: str, includedFrom: SourceLocation, library: SourceLibrary, isSystemPath: bool) -> SourceBuffer:
        ...
    def readSource(self, path: os.PathLike | str | bytes, library: SourceLibrary = None) -> SourceBuffer:
        ...
    def setBufferKind(self, buffer: BufferID, kind: BufferKind) -> None:
        ...
    def setDisableLocalIncludes(self, set: bool) -> None:
        ...
    def setDisableProximatePaths(self, set: bool) -> None:
        ...
class SourceRange:
    __hash__: typing.ClassVar[None] = None
    def __eq__(self, arg0: SourceRange) -> bool:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, startLoc: SourceLocation, endLoc: SourceLocation) -> None:
        ...
    def __ne__(self, arg0: SourceRange) -> bool:
        ...
    @property
    def end(self) -> SourceLocation:
        ...
    @property
    def start(self) -> SourceLocation:
        ...
class TextDiagnosticClient(DiagnosticClient):
    def __init__(self) -> None:
        ...
    def clear(self) -> None:
        ...
    def getString(self) -> str:
        ...
    def report(self, diag: ReportedDiagnostic) -> None:
        ...
    def setColumnUnit(self, unit: ColumnUnit) -> None:
        ...
    def showColors(self, show: bool) -> None:
        ...
    def showColumn(self, show: bool) -> None:
        ...
    def showHierarchyInstance(self, show: ...) -> None:
        ...
    def showIncludeStack(self, show: bool) -> None:
        ...
    def showLocation(self, show: bool) -> None:
        ...
    def showMacroExpansion(self, show: bool) -> None:
        ...
    def showOptionName(self, show: bool) -> None:
        ...
    def showSourceLine(self, show: bool) -> None:
        ...
class TimeScale:
    __hash__: typing.ClassVar[None] = None
    base: TimeScaleValue
    precision: TimeScaleValue
    @staticmethod
    def fromString(str: str) -> pyslang.TimeScale | None:
        ...
    def __eq__(self, arg0: TimeScale) -> bool:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, base: TimeScaleValue, precision: TimeScaleValue) -> None:
        ...
    def __ne__(self, arg0: TimeScale) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def apply(self, value: typing.SupportsFloat | typing.SupportsIndex, unit: TimeUnit, roundToPrecision: bool) -> float:
        ...
class TimeScaleMagnitude(enum.Enum):
    Hundred: typing.ClassVar[TimeScaleMagnitude]  # value = <TimeScaleMagnitude.Hundred: 100>
    One: typing.ClassVar[TimeScaleMagnitude]  # value = <TimeScaleMagnitude.One: 1>
    Ten: typing.ClassVar[TimeScaleMagnitude]  # value = <TimeScaleMagnitude.Ten: 10>
class TimeScaleValue:
    __hash__: typing.ClassVar[None] = None
    magnitude: TimeScaleMagnitude
    unit: TimeUnit
    @staticmethod
    def fromLiteral(value: typing.SupportsFloat | typing.SupportsIndex, unit: TimeUnit) -> pyslang.TimeScaleValue | None:
        ...
    @staticmethod
    def fromString(str: str) -> pyslang.TimeScaleValue | None:
        ...
    def __eq__(self, arg0: TimeScaleValue) -> bool:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, unit: TimeUnit, magnitude: TimeScaleMagnitude) -> None:
        ...
    def __ne__(self, arg0: TimeScaleValue) -> bool:
        ...
    def __repr__(self) -> str:
        ...
class TimeUnit(enum.Enum):
    Femtoseconds: typing.ClassVar[TimeUnit]  # value = <TimeUnit.Femtoseconds: 5>
    Microseconds: typing.ClassVar[TimeUnit]  # value = <TimeUnit.Microseconds: 2>
    Milliseconds: typing.ClassVar[TimeUnit]  # value = <TimeUnit.Milliseconds: 1>
    Nanoseconds: typing.ClassVar[TimeUnit]  # value = <TimeUnit.Nanoseconds: 3>
    Picoseconds: typing.ClassVar[TimeUnit]  # value = <TimeUnit.Picoseconds: 4>
    Seconds: typing.ClassVar[TimeUnit]  # value = <TimeUnit.Seconds: 0>
class Unbounded:
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
class VersionInfo:
    @staticmethod
    def getHash() -> str:
        ...
    @staticmethod
    def getMajor() -> int:
        ...
    @staticmethod
    def getMinor() -> int:
        ...
    @staticmethod
    def getPatch() -> int:
        ...
    @staticmethod
    def getPrerelease() -> str:
        ...
    @staticmethod
    def getVersionString() -> str:
        ...
class logic_t:
    __hash__: typing.ClassVar[None] = None
    x: typing.ClassVar[logic_t]  # value = x
    z: typing.ClassVar[logic_t]  # value = z
    def __and__(self, arg0: logic_t) -> logic_t:
        ...
    def __bool__(self) -> bool:
        ...
    def __eq__(self, arg0: logic_t) -> logic_t:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __invert__(self) -> logic_t:
        ...
    def __ne__(self, arg0: logic_t) -> logic_t:
        ...
    def __or__(self, arg0: logic_t) -> logic_t:
        ...
    def __repr__(self) -> str:
        ...
    def __xor__(self, arg0: logic_t) -> logic_t:
        ...
    @property
    def isUnknown(self) -> bool:
        ...
    @property
    def value(self) -> int:
        ...
    @value.setter
    def value(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
def clog2(value: ...) -> int:
    ...
def literalBaseFromChar(base: str, result: LiteralBase) -> bool:
    ...
__version__: str = '11.0.0'
